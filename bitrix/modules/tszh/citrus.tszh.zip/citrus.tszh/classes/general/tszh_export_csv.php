<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

IncludeModuleLangFile(__FILE__);

class CTszhExportCSV
{
	
	public static function num($number)
	{
		return str_replace('.', ',', $number);
	}

	public static function DoExport($orgName, $orgINN, $filename, $arFilter = Array(), $step_time = 0, $lastID = 0, $arValueFilter = Array()) {

		global $DB, $USER, $APPLICATION, $cnt, $total;

		$startTime = microtime(1);
		
		@set_time_limit(0);
		@ignore_user_abort(true);

		if (!is_array($arFilter))
			$arFilter = Array();

		require_once($_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/classes/general/csv_data.php');
		$obCSV = new CCSVData();

		$rsMeters = CTszhMeter::GetList(
			Array("ACCOUNT_ID" => "ASC", "SORT" => "ASC"),
			$arFilter
		);
		$arFields = Array(
			GetMessage("TSZH_EXPORT_FIO"),
			GetMessage("TSZH_EXPORT_ACCOUNT"),
			GetMessage("TSZH_EXPORT_ADDRESS"),
		);
		$arMetersIdx = Array(
			GetMessage("TSZH_EXPORT_FIO") => 0,
			GetMessage("TSZH_EXPORT_ACCOUNT") => 1,
			GetMessage("TSZH_EXPORT_ADDRESS") => 2,
		);
		$arUserFields = Array();
		$rsUserFields = CUserTypeEntity::GetList(Array("SORT" => "ASC", "ID" => "ASC"), Array("ENTITY_ID" => "TSZH_ACCOUNT", "LANG" => LANGUAGE_ID));
		while ($arUserField = $rsUserFields->Fetch())
		{
			if (is_set($arUserField, "LIST_COLUMN_LABEL") && !empty($arUserField["LIST_COLUMN_LABEL"]))
			{
				$arFields[] = $arUserField["LIST_COLUMN_LABEL"];
				$arMetersIdx[$arUserField["LIST_COLUMN_LABEL"]] = count($arFields)-1;
				$arUserFields[$arUserField["FIELD_NAME"]] = $arUserField;
			}
		}
		$arCurTitles = array();
		$curAccountID = false;
		while ($arMeter = $rsMeters->Fetch())
		{
			for ($i = 0; $i < $arMeter["VALUES_COUNT"]; $i++)
			{
				if ($i == 0)
					$title = strlen($arMeter['SERVICE_NAME']) > 0 ? $arMeter['SERVICE_NAME'] : $arMeter['NAME'];
				else
					$title = (strlen($arMeter['SERVICE_NAME']) > 0 ? $arMeter['SERVICE_NAME'] : $arMeter['NAME']) . GetMessage("TSZH_EXPORT_TARIFF", Array("#N#" => $i+1));

				if ($curAccountID === $arMeter["ACCOUNT_ID"])
				{
					$newTitle = $title;
					$j = 1;
					while (in_array($newTitle, $arCurTitles))
					{
						$newTitle = $title . "(" . ++$j . ")";
					}
					$title = $newTitle;
				}
				else
				{
					$curAccountID = $arMeter["ACCOUNT_ID"];
					$arCurTitles = array();
				}
				$arCurTitles[] = $title;

				if (!array_key_exists($title, $arMetersIdx))
				{
					$arFields[] = $title;
					$arMetersIdx[$title] = count($arFields)-1;
				}
			}
		}
		
		// $bNextStep === false �� ������ ����
		$bNextStep = $lastID > 0;
		
		$rsAccounts = CTszhAccount::GetList(Array("ID" => "ASC"), array_merge($arFilter, Array(">ID" => $lastID)), false, false, Array("*", "UF_*"));

		// ���������� �� ������� ���
		$cnt = 0;
		// ����� ���-�� �/� �� ������� ����
		$total = $rsAccounts->SelectedRowsCount();
		
		if (!$bNextStep && $total == 0)
		{
			$APPLICATION->ThrowException(GetMessage("TSZH_ERROR_EXPORT_NO_DATA"), "TSZH_EXPORT_NO_DATA");
			return false;
		}

		// ������ ������ � ������� ��������
		if (!$bNextStep)
		{
			if (SITE_CHARSET !== 'windows-1251')
				$arFields = $APPLICATION->ConvertCharsetArray($arFields, SITE_CHARSET, 'windows-1251');
			$obCSV->SaveFile($filename, $arFields);
		}
		
		while ($arAccount = $rsAccounts->Fetch())
		{
			$lastID = $arAccount['ID'];
			
			$arValues = Array(
				CTszhAccount::GetFullName($arAccount['USER_ID']),
				$arAccount["EXTERNAL_ID"],
				CTszhAccount::GetFullAddress($arAccount)
			);
			// fill user fields, that there added to column headers
			foreach ($arUserFields as $fieldName => $fieldAttr)
				$arValues[] = $arAccount[$fieldName];
			for ($i = count($arValues); $i <= count($arMetersIdx); $i++)
				$arValues[$i] = '';
			$rsMeterValues = CTszhMeterValue::GetList(
				Array("TIMESTAMP_X" => "ASC"),
				array_merge($arValueFilter, Array("ACCOUNT_ID" => $arAccount['ID'])),
				false,
				false,
				array("ID", "METER_ID", "VALUE1", "VALUE2", "VALUE3", "MODIFIED_BY", "TIMESTAMP_X", "MODIFIED_BY_OWNER", "MONTH", "NAME", "SERVICE_NAME", "VALUES_COUNT", "DEC_PLACES")
			);
			$valuesFilled = 0;
			$arCurTitles = array();
			while ($arMeterValue = $rsMeterValues->Fetch())
			{
				for ($i = 0; $i < $arMeterValue["VALUES_COUNT"]; $i++)
				{
					if ($i == 0)
						$title = strlen($arMeterValue['SERVICE_NAME']) > 0 ? $arMeterValue['SERVICE_NAME'] : $arMeterValue['NAME'];
					else
						$title = (strlen($arMeterValue['SERVICE_NAME']) > 0 ? $arMeterValue['SERVICE_NAME'] : $arMeterValue['NAME']) . GetMessage("TSZH_EXPORT_TARIFF", Array("#N#" => $i+1));

					$valueKey = "{$arMeterValue["METER_ID"]}_{$i}";
					if (array_key_exists($valueKey, $arCurTitles))
					{
						$title = $arCurTitles[$valueKey];
					}
					else
					{
						$newTitle = $title;
						$j = 1;
						while (in_array($newTitle, $arCurTitles))
						{
							$newTitle = $title . "(" . ++$j . ")";
						}
						$title = $newTitle;
						$arCurTitles[$valueKey] = $title;
					}

					if (array_key_exists($title, $arMetersIdx))
					{
						$idx = $arMetersIdx[$title];
						$arValues[$idx] = self::num($arMeterValue["VALUE" . ($i + 1)]);
						
						$valuesFilled++;
					}
				}
			}
			if ($valuesFilled > 0)
			{
				if (SITE_CHARSET !== 'windows-1251')
					$arValues = $APPLICATION->ConvertCharsetArray($arValues, SITE_CHARSET, 'windows-1251');
				$obCSV->SaveFile($filename, $arValues);
			}
			
			$cnt++;
			
			if ($step_time && microtime(1) - $startTime >= $step_time)
				break;
		}

		if ($cnt == $total)
			return true;
		else
		  	return $lastID;
	}

}

?>