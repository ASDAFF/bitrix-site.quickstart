<?

IncludeModuleLangFile(__FILE__);

$GLOBALS["TSZH_METER"] = Array();

// �������� ������� ������ / ��������� ���������
/**
 * CTszhMeter
 * ����� ��� ������ �� ����������
 *
 * ����:
 * ----
 *
 * ID			- ID ������
 * ACTIVE		- ���� ���������� (��������� � 1� �������� ����� ��������������?)
 * HOUSE_METER  - ��������� �� ����������� ���������
 * XML_ID		- ������� ��� �������� (�� 1�)
 * NAME			- ������ �������� ��������
 * NUM			- ��������� �����
 * ACCOUNT_ID	- ID �������� �����, �������� ����������� �������
 * SERVICE_NAME - ������������ ������
 * SERVICE_ID	- ID ������
 * VALUES_COUNT - ���������� �������
 * SORT			- ������� ����������
 *
 * @package
 * @author
 * @copyright nook.yo
 * @version 2010
 * @access public
 */
class CTszhMeter {

	// ������� ��, ���������� ������
	const TABLE_NAME = 'b_tszh_meters';
	// ������� ��, ���������� �������� ��������� � ������� ������
	const TABLE_NAME_METERS_ACCOUNTS = 'b_tszh_meters_accounts';
	// �������� ������ � ��������� ��������, ���� ������������ ���������������� ���� �������� ������; false, ���� �� ������������
	const USER_FIELD_ENTITY = 'TSZH_METER';

	public static $arGetListFields = array(
		"ID" => Array("FIELD" => "TM.ID", "TYPE" => "int"),
		"ACTIVE" => Array("FIELD" => "TM.ACTIVE", "TYPE" => "char"),
		"HOUSE_METER" => Array("FIELD" => "TM.HOUSE_METER", "TYPE" => "char"),
		"XML_ID" => Array("FIELD" => "TM.XML_ID", "TYPE" => "string"),
		"NAME" => Array("FIELD" => "TM.NAME", "TYPE" => "string"),
		"NUM" => Array("FIELD" => "TM.NUM", "TYPE" => "string"),
		"SERVICE_ID" => Array("FIELD" => "TM.SERVICE_ID", "TYPE" => "int"),
		"SERVICE_NAME" => Array("FIELD" => "TM.SERVICE_NAME", "TYPE" => "string"),
		"VALUES_COUNT" => Array("FIELD" => "TM.VALUES_COUNT", "TYPE" => "int"),
		"DEC_PLACES" => Array("FIELD" => "TM.DEC_PLACES", "TYPE" => "int"),
		"CAPACITY" => Array("FIELD" => "TM.CAPACITY", "TYPE" => "int"),
		"SORT" => Array("FIELD" => "TM.SORT", "TYPE" => "int"),
		"VERIFICATION_DATE" => Array("FIELD" => "TM.VERIFICATION_DATE", "TYPE" => "date"),

		"ACCOUNT_ID" => Array(
			"FIELD" => "_TMA.ACCOUNT_ID", 
			"FIELD_SELECT" => "(SELECT GROUP_CONCAT(TMAS.ACCOUNT_ID ORDER BY TMAS.ACCOUNT_ID SEPARATOR '|') FROM b_tszh_meters_accounts TMAS WHERE TM.ID = TMAS.METER_ID)", 
			"TYPE" => "int", 
			"FROM" => "INNER JOIN b_tszh_meters_accounts _TMA ON (_TMA.METER_ID = TM.ID)",
			/*"BINDING_TABLE" => "b_tszh_meters_accounts TMAW", 
			"BINDING_EXTERNAL_FIELD" => "TM.ID", 
			"BINDING_SELECT_FIELD" => "TMAW.METER_ID", 
			"BINDING_WHERE_FIELD" => "TMAW.ACCOUNT_ID"*/
		),
		"TSZH_ID" => Array(
			"FIELD" => "TA.TSZH_ID", 
			"FIELD_SELECT" => "(SELECT GROUP_CONCAT(TAS.TSZH_ID ORDER BY TAS.ID SEPARATOR '|') FROM b_tszh_accounts TAS INNER JOIN b_tszh_meters_accounts TMAS ON TMAS.ACCOUNT_ID = TAS.ID WHERE TM.ID = TMAS.METER_ID)", 
			"TYPE" => "int", 
			"FROM" => "INNER JOIN b_tszh_meters_accounts TMA ON (TMA.METER_ID = TM.ID) INNER JOIN b_tszh_accounts TA ON (TA.ID = TMA.ACCOUNT_ID)", 
			/*"BINDING_TABLE" => "b_tszh_accounts TAW INNER JOIN b_tszh_meters_accounts TMAW ON TMAW.ACCOUNT_ID = TAW.ID", 
			"BINDING_EXTERNAL_FIELD" => "TM.ID", 
			"BINDING_SELECT_FIELD" => "TMAW.METER_ID", 
			"BINDING_WHERE_FIELD" => "TAW.TSZH_ID"*/
		),
		"USER_ID" => Array(
			"FIELD" => "TA.USER_ID", 
			"FIELD_SELECT" => "(SELECT GROUP_CONCAT(TAS.USER_ID ORDER BY TAS.ID SEPARATOR '|') FROM b_tszh_accounts TAS INNER JOIN b_tszh_meters_accounts TMAS ON TMAS.ACCOUNT_ID = TAS.ID WHERE TM.ID = TMAS.METER_ID)", 
			"TYPE" => "int", 
			"FROM" => "INNER JOIN b_tszh_meters_accounts TMA ON (TMA.METER_ID = TM.ID) INNER JOIN b_tszh_accounts TA ON (TA.ID = TMA.ACCOUNT_ID)", 
			/*"BINDING_TABLE" => "b_tszh_accounts TAW INNER JOIN b_tszh_meters_accounts TMAW ON TMAW.ACCOUNT_ID = TAW.ID", 
			"BINDING_EXTERNAL_FIELD" => "TM.ID", 
			"BINDING_SELECT_FIELD" => "TMAW.METER_ID", 
			"BINDING_WHERE_FIELD" => "TAW.USER_ID"*/
		),
		"ACCOUNT_XML_ID" => Array(
			"FIELD" => "TA.XML_ID", 
			"FIELD_SELECT" => "(SELECT GROUP_CONCAT(TAS.XML_ID ORDER BY TAS.ID SEPARATOR '|') FROM b_tszh_accounts TAS INNER JOIN b_tszh_meters_accounts TMAS ON TMAS.ACCOUNT_ID = TAS.ID WHERE TM.ID = TMAS.METER_ID)", 
			"TYPE" => "string", 
			"FROM" => "INNER JOIN b_tszh_meters_accounts TMA ON (TMA.METER_ID = TM.ID) INNER JOIN b_tszh_accounts TA ON (TA.ID = TMA.ACCOUNT_ID)", 
			/*"BINDING_TABLE" => "b_tszh_accounts TAW INNER JOIN b_tszh_meters_accounts TMAW ON TMAW.ACCOUNT_ID = TAW.ID", 
			"BINDING_EXTERNAL_FIELD" => "TM.ID", 
			"BINDING_SELECT_FIELD" => "TMAW.METER_ID", 
			"BINDING_WHERE_FIELD" => "TAW.XML_ID"*/
		),
		"ACCOUNT_EXTERNAL_ID" => Array(
			"FIELD" => "TA.EXTERNAL_ID", 
			"FIELD_SELECT" => "(SELECT GROUP_CONCAT(TAS.EXTERNAL_ID ORDER BY TAS.ID SEPARATOR '|') FROM b_tszh_accounts TAS INNER JOIN b_tszh_meters_accounts TMAS ON TMAS.ACCOUNT_ID = TAS.ID WHERE TM.ID = TMAS.METER_ID)", 
			"TYPE" => "string", 
			"FROM" => "INNER JOIN b_tszh_meters_accounts TMA ON (TMA.METER_ID = TM.ID) INNER JOIN b_tszh_accounts TA ON (TA.ID = TMA.ACCOUNT_ID)", 
			/*"BINDING_TABLE" => "b_tszh_accounts TAW INNER JOIN b_tszh_meters_accounts TMAW ON TMAW.ACCOUNT_ID = TAW.ID", 
			"BINDING_EXTERNAL_FIELD" => "TM.ID", 
			"BINDING_SELECT_FIELD" => "TMAW.METER_ID", 
			"BINDING_WHERE_FIELD" => "TAW.EXTERNAL_ID"*/
		),
		"ACCOUNT_NAME" => Array(
			"FIELD" => "TA.NAME", 
			"FIELD_SELECT" => "(SELECT GROUP_CONCAT(TAS.NAME ORDER BY TAS.ID SEPARATOR '|') FROM b_tszh_accounts TAS INNER JOIN b_tszh_meters_accounts TMAS ON TMAS.ACCOUNT_ID = TAS.ID WHERE TM.ID = TMAS.METER_ID)", 
			"TYPE" => "string", 
			"FROM" => "INNER JOIN b_tszh_meters_accounts TMA ON (TMA.METER_ID = TM.ID) INNER JOIN b_tszh_accounts TA ON (TA.ID = TMA.ACCOUNT_ID)", 
			/*"BINDING_TABLE" => "b_tszh_accounts TAW INNER JOIN b_tszh_meters_accounts TMAW ON TMAW.ACCOUNT_ID = TAW.ID", 
			"BINDING_EXTERNAL_FIELD" => "TM.ID", 
			"BINDING_SELECT_FIELD" => "TMAW.METER_ID", 
			"BINDING_WHERE_FIELD" => "TAW.NAME"*/
		),
		"ACCOUNT_CITY" => Array(
   			"FIELD" => "TA.CITY", 
			"FIELD_SELECT" => "(SELECT GROUP_CONCAT(TAS.CITY ORDER BY TAS.ID SEPARATOR '|') FROM b_tszh_accounts TAS INNER JOIN b_tszh_meters_accounts TMAS ON TMAS.ACCOUNT_ID = TAS.ID WHERE TM.ID = TMAS.METER_ID)", 
			"TYPE" => "string", 
			"FROM" => "INNER JOIN b_tszh_meters_accounts TMA ON (TMA.METER_ID = TM.ID) INNER JOIN b_tszh_accounts TA ON (TA.ID = TMA.ACCOUNT_ID)", 
			/*"BINDING_TABLE" => "b_tszh_accounts TAW INNER JOIN b_tszh_meters_accounts TMAW ON TMAW.ACCOUNT_ID = TAW.ID", 
			"BINDING_EXTERNAL_FIELD" => "TM.ID", 
			"BINDING_SELECT_FIELD" => "TMAW.METER_ID", 
			"BINDING_WHERE_FIELD" => "TAW.CITY"*/
		),
		"ACCOUNT_DISTRICT" => Array(
   			"FIELD" => "TA.DISTRICT", 
			"FIELD_SELECT" => "(SELECT GROUP_CONCAT(TAS.DISTRICT ORDER BY TAS.ID SEPARATOR '|') FROM b_tszh_accounts TAS INNER JOIN b_tszh_meters_accounts TMAS ON TMAS.ACCOUNT_ID = TAS.ID WHERE TM.ID = TMAS.METER_ID)", 
			"TYPE" => "string", 
			"FROM" => "INNER JOIN b_tszh_meters_accounts TMA ON (TMA.METER_ID = TM.ID) INNER JOIN b_tszh_accounts TA ON (TA.ID = TMA.ACCOUNT_ID)", 
			/*"BINDING_TABLE" => "b_tszh_accounts TAW INNER JOIN b_tszh_meters_accounts TMAW ON TMAW.ACCOUNT_ID = TAW.ID", 
			"BINDING_EXTERNAL_FIELD" => "TM.ID", 
			"BINDING_SELECT_FIELD" => "TMAW.METER_ID", 
			"BINDING_WHERE_FIELD" => "TAW.DISTRICT"*/
		),
		"ACCOUNT_REGION" => Array(
			"FIELD" => "TA.REGION", 
			"FIELD_SELECT" => "(SELECT GROUP_CONCAT(TAS.REGION ORDER BY TAS.ID SEPARATOR '|') FROM b_tszh_accounts TAS INNER JOIN b_tszh_meters_accounts TMAS ON TMAS.ACCOUNT_ID = TAS.ID WHERE TM.ID = TMAS.METER_ID)", 
			"TYPE" => "string", 
			"FROM" => "INNER JOIN b_tszh_meters_accounts TMA ON (TMA.METER_ID = TM.ID) INNER JOIN b_tszh_accounts TA ON (TA.ID = TMA.ACCOUNT_ID)", 
			/*"BINDING_TABLE" => "b_tszh_accounts TAW INNER JOIN b_tszh_meters_accounts TMAW ON TMAW.ACCOUNT_ID = TAW.ID", 
			"BINDING_EXTERNAL_FIELD" => "TM.ID", 
			"BINDING_SELECT_FIELD" => "TMAW.METER_ID", 
			"BINDING_WHERE_FIELD" => "TAW.REGION"*/
		),
		"ACCOUNT_SETTLEMENT" => Array(
			"FIELD" => "TA.SETTLEMENT", 
			"FIELD_SELECT" => "(SELECT GROUP_CONCAT(TAS.SETTLEMENT ORDER BY TAS.ID SEPARATOR '|') FROM b_tszh_meters_accounts TMAS INNER JOIN b_tszh_accounts TAS ON TMAS.ACCOUNT_ID = TAS.ID WHERE TM.ID = TMAS.METER_ID)", 
			"TYPE" => "string", 
			"FROM" => "INNER JOIN b_tszh_meters_accounts TMA ON (TMA.METER_ID = TM.ID) INNER JOIN b_tszh_accounts TA ON (TA.ID = TMA.ACCOUNT_ID)", 
			/*"BINDING_TABLE" => "b_tszh_accounts TAW INNER JOIN b_tszh_meters_accounts TMAW ON TMAW.ACCOUNT_ID = TAW.ID", 
			"BINDING_EXTERNAL_FIELD" => "TM.ID", 
			"BINDING_SELECT_FIELD" => "TMAW.METER_ID", 
			"BINDING_WHERE_FIELD" => "TAW.SETTLEMENT"*/
		),
		"ACCOUNT_STREET" => Array(
			"FIELD" => "TA.STREET", 
			"FIELD_SELECT" => "(SELECT GROUP_CONCAT(TAS.STREET ORDER BY TAS.ID SEPARATOR '|') FROM b_tszh_accounts TAS INNER JOIN b_tszh_meters_accounts TMAS ON TMAS.ACCOUNT_ID = TAS.ID WHERE TM.ID = TMAS.METER_ID)", 
			"TYPE" => "string", 
			"FROM" => "INNER JOIN b_tszh_meters_accounts TMA ON (TMA.METER_ID = TM.ID) INNER JOIN b_tszh_accounts TA ON (TA.ID = TMA.ACCOUNT_ID)", 
			/*"BINDING_TABLE" => "b_tszh_accounts TAW INNER JOIN b_tszh_meters_accounts TMAW ON TMAW.ACCOUNT_ID = TAW.ID", 
			"BINDING_EXTERNAL_FIELD" => "TM.ID", 
			"BINDING_SELECT_FIELD" => "TMAW.METER_ID", 
			"BINDING_WHERE_FIELD" => "TAW.STREET"*/
		),
		"ACCOUNT_HOUSE" => Array(
			"FIELD" => "TA.HOUSE", 
			"FIELD_SELECT" => "(SELECT GROUP_CONCAT(TAS.HOUSE ORDER BY TAS.ID SEPARATOR '|') FROM b_tszh_accounts TAS INNER JOIN b_tszh_meters_accounts TMAS ON TMAS.ACCOUNT_ID = TAS.ID WHERE TM.ID = TMAS.METER_ID)", 
			"TYPE" => "string", 
			"FROM" => "INNER JOIN b_tszh_meters_accounts TMA ON (TMA.METER_ID = TM.ID) INNER JOIN b_tszh_accounts TA ON (TA.ID = TMA.ACCOUNT_ID)", 
			/*"BINDING_TABLE" => "b_tszh_accounts TAW INNER JOIN b_tszh_meters_accounts TMAW ON TMAW.ACCOUNT_ID = TAW.ID", 
			"BINDING_EXTERNAL_FIELD" => "TM.ID", 
			"BINDING_SELECT_FIELD" => "TMAW.METER_ID", 
			"BINDING_WHERE_FIELD" => "TAW.HOUSE"*/
		),
		"ACCOUNT_FLAT" => Array(
			"FIELD" => "TA.FLAT", 
			"FIELD_SELECT" => "(SELECT GROUP_CONCAT(TAS.FLAT ORDER BY TAS.ID SEPARATOR '|') FROM b_tszh_accounts TAS INNER JOIN b_tszh_meters_accounts TMAS ON TMAS.ACCOUNT_ID = TAS.ID WHERE TM.ID = TMAS.METER_ID)", 
			"TYPE" => "string", 
			"FROM" => "INNER JOIN b_tszh_meters_accounts TMA ON (TMA.METER_ID = TM.ID) INNER JOIN b_tszh_accounts TA ON (TA.ID = TMA.ACCOUNT_ID)", 
			/*"BINDING_TABLE" => "b_tszh_accounts TAW INNER JOIN b_tszh_meters_accounts TMAW ON TMAW.ACCOUNT_ID = TAW.ID", 
			"BINDING_EXTERNAL_FIELD" => "TM.ID", 
			"BINDING_SELECT_FIELD" => "TMAW.METER_ID", 
			"BINDING_WHERE_FIELD" => "TAW.FLAT"*/
		),
		"ACCOUNT_AREA" => Array(
		    "FIELD" => "TA.AREA", 
			"FIELD_SELECT" => "(SELECT GROUP_CONCAT(TAS.AREA ORDER BY TAS.ID SEPARATOR '|') FROM b_tszh_accounts TAS INNER JOIN b_tszh_meters_accounts TMAS ON TMAS.ACCOUNT_ID = TAS.ID WHERE TM.ID = TMAS.METER_ID)", 
			"TYPE" => "double", 
			"FROM" => "INNER JOIN b_tszh_meters_accounts TMA ON (TMA.METER_ID = TM.ID) INNER JOIN b_tszh_accounts TA ON (TA.ID = TMA.ACCOUNT_ID)", 
			/*"BINDING_TABLE" => "b_tszh_accounts TAW INNER JOIN b_tszh_meters_accounts TMAW ON TMAW.ACCOUNT_ID = TAW.ID", 
			"BINDING_EXTERNAL_FIELD" => "TM.ID", 
			"BINDING_SELECT_FIELD" => "TMAW.METER_ID", 
			"BINDING_WHERE_FIELD" => "TAW.AREA"*/
		),
		"ACCOUNT_LIVING_AREA" => Array(
		    "FIELD" => "TA.LIVING_AREA", 
			"FIELD_SELECT" => "(SELECT GROUP_CONCAT(TAS.LIVING_AREA ORDER BY TAS.ID SEPARATOR '|') FROM b_tszh_accounts TAS INNER JOIN b_tszh_meters_accounts TMAS ON TMAS.ACCOUNT_ID = TAS.ID WHERE TM.ID = TMAS.METER_ID)", 
			"TYPE" => "double", 
			"FROM" => "INNER JOIN b_tszh_meters_accounts TMA ON (TMA.METER_ID = TM.ID) INNER JOIN b_tszh_accounts TA ON (TA.ID = TMA.ACCOUNT_ID)", 
			/*"BINDING_TABLE" => "b_tszh_accounts TAW INNER JOIN b_tszh_meters_accounts TMAW ON TMAW.ACCOUNT_ID = TAW.ID", 
			"BINDING_EXTERNAL_FIELD" => "TM.ID", 
			"BINDING_SELECT_FIELD" => "TMAW.METER_ID", 
			"BINDING_WHERE_FIELD" => "TAW.LIVING_AREA"*/
		),
		"ACCOUNT_PEOPLE" => Array(
		    "FIELD" => "TA.PEOPLE", 
			"FIELD_SELECT" => "(SELECT GROUP_CONCAT(TAS.PEOPLE ORDER BY TAS.ID SEPARATOR '|') FROM b_tszh_accounts TAS INNER JOIN b_tszh_meters_accounts TMAS ON TMAS.ACCOUNT_ID = TAS.ID WHERE TM.ID = TMAS.METER_ID)", 
			"TYPE" => "int", 
			"FROM" => "INNER JOIN b_tszh_meters_accounts TMA ON (TMA.METER_ID = TM.ID) INNER JOIN b_tszh_accounts TA ON (TA.ID = TMA.ACCOUNT_ID)", 
			/*"BINDING_TABLE" => "b_tszh_accounts TAW INNER JOIN b_tszh_meters_accounts TMAW ON TMAW.ACCOUNT_ID = TAW.ID", 
			"BINDING_EXTERNAL_FIELD" => "TM.ID", 
			"BINDING_SELECT_FIELD" => "TMAW.METER_ID", 
			"BINDING_WHERE_FIELD" => "TAW.PEOPLE"*/
		),
		"ACCOUNT_ADDRESS_FULL" => Array(
		    "FIELD" => "CONCAT(TA.CITY,' ',TA.STREET,' ',TA.HOUSE,' ',TA.FLAT)", 
			"FIELD_SELECT" => "(SELECT GROUP_CONCAT(CONCAT(TAS.CITY,' ',TAS.STREET,' ',TAS.HOUSE,' ',TAS.FLAT) ORDER BY TAS.ID SEPARATOR '|') FROM b_tszh_accounts TAS INNER JOIN b_tszh_meters_accounts TMAS ON TMAS.ACCOUNT_ID = TAS.ID WHERE TM.ID = TMAS.METER_ID)", 
			"TYPE" => "string", 
			"FROM" => "INNER JOIN b_tszh_meters_accounts TMA ON (TMA.METER_ID = TM.ID) INNER JOIN b_tszh_accounts TA ON (TA.ID = TMA.ACCOUNT_ID)", 
			"CONCAT" => true, 
			/*"BINDING_TABLE" => "b_tszh_accounts TAW INNER JOIN b_tszh_meters_accounts TMAW ON TMAW.ACCOUNT_ID = TAW.ID", 
			"BINDING_EXTERNAL_FIELD" => "TM.ID", 
			"BINDING_SELECT_FIELD" => "TMAW.METER_ID", 
			"BINDING_WHERE_FIELD" => "CONCAT(TAW.CITY,' ',TAW.STREET,' ',TAW.HOUSE,' ',TAW.FLAT)"*/
		),
	);

	/**
	 * CTszhMeter::GetByID()
	 * ����� ���������� ���� �������� � ����� ID
	 *
	 * @param int $ID ��� ��������
	 * @return
	 */
	public static function GetByID($ID)
	{
		$ID = IntVal($ID);
		if ($ID <= 0)
			throw new \Bitrix\Main\ArgumentOutOfRangeException("ID", 1);

		if (isset($GLOBALS["TSZH_METER"]["CACHE_".$ID]) && is_array($GLOBALS["TSZH_METER"]["CACHE_".$ID]) && is_set($GLOBALS["TSZH_METER"]["CACHE_".$ID], "ID"))
		{
			return $GLOBALS["TSZH_METER"]["CACHE_".$ID];
		}
		else
		{
			$arMeter = self::GetList(array(), array("ID" => $ID), false, array("nTopCount" => 1))->GetNext();
			if (is_array($arMeter) && !empty($arMeter))
			{
				$GLOBALS["TSZH_METER"]["CACHE_".$arMeter['ID']] = $arMeter;
				$GLOBALS["TSZH_METER"]["XML_ID_CACHE_".$arMeter['XML_ID']] = $arMeter;
				return $arMeter;
			}
		}

		return false;
	}

	/**
	 * CTszhMeter::GetByXmlID()
	 * ����� ���������� ���� �������� � ������� ����� ID (��� �� 1�)
	 *
	 * @param string $ID ������� ��� ��������
	 * @return
	 */
	public static function GetByXmlID($ID)
	{
		$ID = trim($ID);
		if (strlen($ID) <= 0)
			throw new \Bitrix\Main\ArgumentException("Empty XML_ID given", "ID");

		if (isset($GLOBALS["TSZH_METER"]["XML_ID_CACHE_".$ID]) && is_array($GLOBALS["TSZH_METER"]["XML_ID_CACHE_".$ID]) && is_set($GLOBALS["TSZH_METER"]["XML_ID_CACHE_".$ID], "ID"))
		{
			return $GLOBALS["TSZH_METER"]["XML_ID_CACHE_".$ID];
		}
		else
		{
			$arMeter = self::GetList(array(), array("XML_ID" => $ID), false, array("nTopCount" => 1))->GetNext();
			if (is_array($arMeter) && !empty($arMeter))
			{
				$GLOBALS["TSZH_METER"]["CACHE_".$arMeter['ID']] = $arMeter;
				$GLOBALS["TSZH_METER"]["XML_ID_CACHE_".$arMeter['XML_ID']] = $arMeter;
				return $arMeter;
			}
		}

		return false;
	}

	/**
	 * CTszhMeter::CheckFields()
	 * �������� ����� (Add � Update)
	 *
	 * @param array $arFields ���� ��������
	 * @param string $strOperation �������� (ADD ��� UPDATE)
	 * @param int $ID ��� ��������
	 * @return
	 */
	protected static function CheckFields(&$arFields, $strOperation = 'ADD', $ID = 0) {
		global $APPLICATION;

		if (array_key_exists('SERVICE_ID', $arFields) || $strOperation == "ADD")
			$arFields['SERVICE_ID'] = IntVal($arFields['SERVICE_ID']);

		if (isset($arFields['HOUSE_METER']))
			$arFields['HOUSE_METER'] = $arFields['HOUSE_METER'] == 'Y' ? 'Y' : 'N';
		elseif ($strOperation == 'ADD')
			$arFields["HOUSE_METER"] = "N";
			
		if ($arFields["HOUSE_METER"] == "Y")
		{
			$arFields['ACCOUNT_ID'] = false;
		}
		/*else
		{
			if (array_key_exists('ACCOUNT_ID', $arFields) || $strOperation == "ADD")
			{
				$arFields['ACCOUNT_ID'] = IntVal($arFields['ACCOUNT_ID']);
				if ($arFields['ACCOUNT_ID'] <= 0)
				{
					$APPLICATION->ThrowException(GetMessage("ERROR_TSZH_METER_WRONG_ACCOUNT"));
					return false;
				}
			}
		}*/

		if (isset($arFields['VALUES_COUNT']) || $strOperation == 'ADD')
		{
			$arFields['VALUES_COUNT'] = IntVal($arFields['VALUES_COUNT']);
			if ($arFields['VALUES_COUNT'] <= 0 || $arFields["VALUES_COUNT"] > 3)
				$arFields['VALUES_COUNT'] = 1;
		}

		if (isset($arFields['DEC_PLACES']) || $strOperation == 'ADD')
		{
			$arFields['DEC_PLACES'] = IntVal($arFields['DEC_PLACES']);
			if ($arFields['DEC_PLACES'] <= 0)
				$arFields['DEC_PLACES'] = 2;
			if ($arFields['DEC_PLACES'] > 8)
			{
				$APPLICATION->ThrowException(GetMessage("ERROR_TSZH_METER_LARGE_DEC_PLACES"));
				return false;
			}
		}

		if (isset($arFields['CAPACITY']) || $strOperation == 'ADD')
		{
			$arFields['CAPACITY'] = IntVal($arFields['CAPACITY']);
			if ($arFields['CAPACITY'] <= 0)
				$arFields['CAPACITY'] = false;
			if ($arFields['CAPACITY'] > 9)
			{
				$APPLICATION->ThrowException(GetMessage("ERROR_TSZH_METER_LARGE_CAPACITY"));
				return false;
			}
		}

		if (isset($arFields["VERIFICATION_DATE"]) && strlen($arFields["VERIFICATION_DATE"]))
		{
			$ts = MakeTimeStamp($arFields["VERIFICATION_DATE"]);
			if ($ts <= 0)
			{
				$APPLICATION->ThrowException(GetMessage("ERROR_TSZH_METER_INVALID_VERIFICATION_DATE"));
				return false;
			}
		}

		if (isset($arFields['ACTIVE']))
			$arFields['ACTIVE'] = $arFields['ACTIVE'] == 'Y' ? 'Y' : 'N';
		elseif ($strOperation == 'ADD')
			$arFields["ACTIVE"] = "Y";

		if (self::USER_FIELD_ENTITY && !$GLOBALS['USER_FIELD_MANAGER']->CheckFields(self::USER_FIELD_ENTITY, $ID, $arFields))
			return false;

		unset($arFields['ID']);

		return true;
	}

	/**
	 * CTszhMeter::Add()
	 * ����� ��������� ����� ������� � ������ $arFields
	 *
	 * @param array $arFields ���� ��������
	 * @return
	 */
	public static function Add($arFields)
	{
		if(!CTszhMeter::CheckFields($arFields, 'ADD'))
			return false;

		$ID = CDatabase::Add(self::TABLE_NAME, $arFields);
		if (self::USER_FIELD_ENTITY && $ID > 0 && CTszh::hasUserFields($arFields))
			$GLOBALS['USER_FIELD_MANAGER']->Update(self::USER_FIELD_ENTITY, $ID, $arFields);

		if ($ID > 0 && isset($arFields["ACCOUNT_ID"]) && !empty($arFields["ACCOUNT_ID"]))
			self::bindAccount($ID, $arFields["ACCOUNT_ID"]);

		return $ID;
	}

	/**
	 * CTszhMeter::Update()
	 * ����� �������� ������� � ����� $ID
	 *
	 * @param int $ID ��� ��������
	 * @param array $arFields ���� ��������
	 * @return
	 */
	public static function Update($ID, $arFields)
	{
		global $DB;

		$ID = IntVal($ID);
		if ($ID <= 0)
			throw new \Bitrix\Main\ArgumentOutOfRangeException("ID", 1);

		if(!CTszhMeter::CheckFields($arFields, 'UPDATE', $ID))
			return false;

		$bSuccess = true;
		$strUpdate = $DB->PrepareUpdate(self::TABLE_NAME, $arFields);
		if (strlen($strUpdate))
		{
			$strSql =
				"UPDATE " . self::TABLE_NAME . " SET ".
					$strUpdate.
				" WHERE ID=".$ID;
			$bSuccess = $DB->Query($strSql, false, "File: ".__FILE__."<br>Line: ".__LINE__);
		}
		if (self::USER_FIELD_ENTITY && $bSuccess && CTszh::hasUserFields($arFields))
			$GLOBALS['USER_FIELD_MANAGER']->Update(self::USER_FIELD_ENTITY, $ID, $arFields);

		if ($bSuccess && ($arFields["HOUSE_METER"] == "Y" || is_set($arFields, "ACCOUNT_ID")))
			self::unbindAccount($ID);

		if ($bSuccess && isset($arFields["ACCOUNT_ID"]) && !empty($arFields["ACCOUNT_ID"]))
			self::bindAccount($ID, $arFields["ACCOUNT_ID"]);

		return $bSuccess;
	}

	/**
	 * CTszhMeter::Delete()
	 * ����� ������� �������
	 * ���� ����� $accountID, � ���������, ��� ������� �������� �� ������ � ����� �/�, �� ������� ����� �� �����, � ������� �� ����� �/�
	 *
	 * @param int $ID ��� ��������
	 * @param int|bool $accountID ��� �������� �����, � �������� �������� �������
	 * @return
	 */
	public static function Delete($ID, $accountID = false) {
		global $DB;
		$ID = intval($ID);
		if ($ID <= 0)
			throw new \Bitrix\Main\ArgumentOutOfRangeException("ID", 1);

		$isNeedDelete = true;

		$accountID = intval($accountID);
		if ($accountID > 0)
		{
			$arMeter = self::GetList(Array(), Array("ID" => $ID), false, Array("nTopCount" => 1), Array("ID", "ACCOUNT_ID"))->getNext();
			if (is_array($arMeter) && !empty($arMeter) && is_array($arMeter["ACCOUNT_ID"]) && !empty($arMeter["ACCOUNT_ID"]))
			{
				foreach ($arMeter["ACCOUNT_ID"] as $meterAccountID)
				{
					if ($meterAccountID != $accountID)
					{
						$isNeedDelete = false;
						break;
					}
				}
			}
		}

		if ($isNeedDelete)
		{
			$rsMeterValue = CTszhMeterValue::GetList(Array(), Array("METER_ID" => $ID), false, false, Array("ID"));
			while ($arMeterValue = $rsMeterValue->Fetch())
				CTszhMeterValue::Delete($arMeterValue['ID']);
	    
			self::unbindAccount($ID);
	    
			$strSql = "DELETE FROM " . self::TABLE_NAME . " WHERE ID=".$ID;
			$res = $DB->Query($strSql, false, "FILE: ".__FILE__."<br> LINE: ".__LINE__);
	    
			if (self::USER_FIELD_ENTITY && $res)
				$GLOBALS['USER_FIELD_MANAGER']->Delete(self::USER_FIELD_ENTITY, $ID);
		}
		else
			$res = self::unbindAccount($ID, $accountID);

		return $res;
	}

	/**
	 * CTszhMeter::GetList()
	 * ��������� ������ ��������� �������� ����� �� �������
	 *
	 * @param array $arOrder
	 * @param array $arFilter
	 * @return
	 */
	public static function GetList($arOrder = array(), $arFilter = array(), $arGroupBy = false, $arNavStartParams = false, $arSelectFields = array())
	{
		if (count($arSelectFields) <= 0)
			$arSelectFields = Array(
				"ID", "ACTIVE", "HOUSE_METER", "XML_ID", "NAME", "NUM", "ACCOUNT_ID", "SERVICE_ID", "SERVICE_NAME", "VALUES_COUNT", "DEC_PLACES", "CAPACITY", "VERIFICATION_DATE", "SORT"
			);
		elseif (array_key_exists('*', $arSelectFields))
			$arSelectFields = array_keys(self::$arGetListFields);

		if (self::USER_FIELD_ENTITY)
		{
			$obUserFieldsSql = new CUserTypeSQL;
			$obUserFieldsSql->SetEntity(self::USER_FIELD_ENTITY, "TM.ID");
			$obUserFieldsSql->SetSelect($arSelectFields);
			$obUserFieldsSql->SetFilter($arFilter);
			$obUserFieldsSql->SetOrder($arOrder);
			
			$dbRes = CTszh::GetListMakeQuery(self::TABLE_NAME . " TM", self::$arGetListFields, $arOrder, $arFilter, $arGroupBy, $arNavStartParams, $arSelectFields, $obUserFieldsSql, $strUserFieldsID = "TM.ID");
		}
		else
			$dbRes = CTszh::GetListMakeQuery(self::TABLE_NAME . " TM", self::$arGetListFields, $arOrder, $arFilter, $arGroupBy, $arNavStartParams, $arSelectFields);
		
		if (self::USER_FIELD_ENTITY && is_object($dbRes))
			$dbRes->SetUserFields($GLOBALS['USER_FIELD_MANAGER']->GetUserFields(self::USER_FIELD_ENTITY));

		return new CTszhMultiValuesResult($dbRes, self::$arGetListFields);
	}

	/**
	 * CTszhMeter::CanPostMeterValues()
	 * ��������� �� � ������ ������ ������������� ������� ��������� ���������
	 *
	 * @return true, ���� � ������ ������ ��������� ������� ��������� ���������, ����� false
	 */
	public static function CanPostMeterValues() {
		return COption::GetOptionString(TSZH_MODULE_ID, "meters_block_edit") != "Y";
	}

	/**
	 * CTszhMeter::SetCanPostMeterValues()
	 * ������������� ���� ���������� �������� ��������� ���������
	 *
	 * @param bool $bValue
	 * @return
	 */
	public static function SetCanPostMeterValues($bValue) {
		$strBlock = $bValue ? 'N' : 'Y';
		COption::SetOptionString(TSZH_MODULE_ID, 'meters_block_edit', $strBlock);
	}

	/**
	 * CTszhMeter::bindAccount()
	 * ����������� ������� � ������� ������
	 *
	 * @param int $meterID ID �������� 
	 * @param int|array $accountID ID �������� ����� | ������ ID ������� ������
	 * @return true � ������ ������, ����� false
	 */
	public static function bindAccount($meterID, $accountID)
	{
		global $DB; 

		$meterID = intval($meterID);
		if ($meterID <= 0)
			return false;

		if (!is_array($accountID))
			$accountID = array(intval($accountID));

		if (empty($accountID))
			return false;

		foreach ($accountID as $key => $value)
		{
			$accountID[$key] = intval($value);
			if ($accountID[$key] <= 0)
				return false;
		}

		$res = true;

		$DB->StartTransaction();
		foreach ($accountID as $key => $value)
		{
			$strSql = "SELECT METER_ID, ACCOUNT_ID FROM " . self::TABLE_NAME_METERS_ACCOUNTS . " WHERE METER_ID={$meterID} AND ACCOUNT_ID={$value}";
			$dbBindig = $DB->Query($strSql, false, "File: ".__FILE__."<br>Line: ".__LINE__);
			if (!$dbBindig->Fetch())
			{
				$strSql = "INSERT INTO " . self::TABLE_NAME_METERS_ACCOUNTS . " (METER_ID, ACCOUNT_ID) VALUES ({$meterID}, {$value})";
				$res = $DB->Query($strSql, false, "FILE: ".__FILE__."<br> LINE: ".__LINE__);
				if (!$res)
					break;
			}
		}
		if ($res)
			$DB->Commit();
		else
			$DB->Rollback();

		return $res;
	}

	/**
	 * CTszhMeter::unbindAccount()
	 * ���������� ������� �� ������� ������
	 *
	 * @param int $meterID ID �������� 
	 * @param int|array $accountID ID �������� ����� | ������ ID ������� ������ (���� �� �����, �� ���������� ������� �� ���� ������� ������)
	 * @return true � ������ ������, ����� false
	 */
	public static function unbindAccount($meterID, $accountID = false)
	{
		global $DB; 

		$meterID = intval($meterID);
		if ($meterID <= 0)
			return false;

		$delAllBindingsFlag = $accountID === false || is_array($accountID) && empty($accountID);
		if (!$delAllBindingsFlag)
		{
			if (!is_array($accountID))
				$accountID = array(intval($accountID));
    
			foreach ($accountID as $key => $value)
			{
				$accountID[$key] = intval($value);
				if ($accountID[$key] <= 0)
					return false;
			}
		}
		$res = true;

		$DB->StartTransaction();
		if ($delAllBindingsFlag)
		{
			$strSql = "DELETE FROM " . self::TABLE_NAME_METERS_ACCOUNTS . " WHERE METER_ID={$meterID}";
			$res = $DB->Query($strSql, false, "FILE: ".__FILE__."<br> LINE: ".__LINE__);
		}
		else
		{
			foreach ($accountID as $key => $value)
			{
				$strSql = "DELETE FROM " . self::TABLE_NAME_METERS_ACCOUNTS . " WHERE METER_ID={$meterID} AND ACCOUNT_ID={$value}";
				$res = $DB->Query($strSql, false, "FILE: ".__FILE__."<br> LINE: ".__LINE__);
				if (!$res)
					break;
			}
		}
		if ($res)
			$DB->Commit();
		else
			$DB->Rollback();

		return $res;
	}
}

/**
 * CTszhMeterValue
 * ����� ��� ������ � ����������� ���������
 *
 * ����:
 * ----
 * ID				- ID ������
 * METER_ID			- ID ��������
 * VALUE1			- ��������� �������� �� ������ 1
 * VALUE2			- ��������� �������� �� ������ 2
 * VALUE3			- ��������� �������� �� ������ 3
 * AMOUNT1			- ������ �������� �� 1� �� ������ 1
 * AMOUNT2			- ������ �������� �� 1� �� ������ 2
 * AMOUNT3			- ������ �������� �� 1� �� ������ 3
 * MODIFIED_BY		- ID ������������, ����������� ���������
 * TIMESTAMP_X		- ���� ��������� ���������
 *
 * @package
 * @author
 * @copyright nook.yo
 * @version 2010
 * @access public
 */
class CTszhMeterValue {

	// ������� ��, ���������� ������
	const TABLE_NAME = 'b_tszh_meters_values';
	// �������� ������ � ��������� ��������, ���� ������������ ���������������� ���� �������� ������; false, ���� �� ������������
	const USER_FIELD_ENTITY = 'TSZH_METER_VALUE';

	public static $arGetListFields = array(
		"ID" => Array("FIELD" => "TMV.ID", "TYPE" => "int"),
		"METER_ID" => Array("FIELD" => "TMV.METER_ID", "TYPE" => "int"),
		"VALUE1" => Array("FIELD" => "TMV.VALUE1", "TYPE" => "double"),
		"VALUE2" => Array("FIELD" => "TMV.VALUE2", "TYPE" => "double"),
		"VALUE3" => Array("FIELD" => "TMV.VALUE3", "TYPE" => "double"),
		"AMOUNT1" => Array("FIELD" => "TMV.AMOUNT1", "TYPE" => "double"),
		"AMOUNT2" => Array("FIELD" => "TMV.AMOUNT2", "TYPE" => "double"),
		"AMOUNT3" => Array("FIELD" => "TMV.AMOUNT3", "TYPE" => "double"),
		"TIMESTAMP_X" => Array("FIELD" => "TMV.TIMESTAMP_X", "TYPE" => "datetime"),
		"MODIFIED_BY" => Array("FIELD" => "TMV.MODIFIED_BY", "TYPE" => "int"),
		"MODIFIED_BY_OWNER" => Array("FIELD" => "TMV.MODIFIED_BY_OWNER", "TYPE" => "char"),
		"MONTH" => Array("FIELD" => "DATE_FORMAT((CASE (DAY(TIMESTAMP_X) <= #DAY#) WHEN true THEN TIMESTAMP_X ELSE DATE_ADD(TIMESTAMP_X, INTERVAL 1 MONTH) END), '%Y-%m')", "TYPE" => "string"),

		"METER_ACTIVE" => Array("FIELD" => "TM.ACTIVE", "TYPE" => "char", "FROM" => "INNER JOIN b_tszh_meters TM ON (TMV.METER_ID = TM.ID)"),
		"METER_HOUSE_METER" => Array("FIELD" => "TM.HOUSE_METER", "TYPE" => "char", "FROM" => "INNER JOIN b_tszh_meters TM ON (TMV.METER_ID = TM.ID)"),
		"XML_ID" => Array("FIELD" => "TM.XML_ID", "TYPE" => "string", "FROM" => "INNER JOIN b_tszh_meters TM ON (TMV.METER_ID = TM.ID)"),
		"NAME" => Array("FIELD" => "TM.NAME", "TYPE" => "string", "FROM" => "INNER JOIN b_tszh_meters TM ON (TMV.METER_ID = TM.ID)"),
		"NUM" => Array("FIELD" => "TM.NUM", "TYPE" => "string", "FROM" => "INNER JOIN b_tszh_meters TM ON (TMV.METER_ID = TM.ID)"),
		"SERVICE_ID" => Array("FIELD" => "TM.SERVICE_ID", "TYPE" => "int", "FROM" => "INNER JOIN b_tszh_meters TM ON (TMV.METER_ID = TM.ID)"),
		"SERVICE_NAME" => Array("FIELD" => "TM.SERVICE_NAME", "TYPE" => "string", "FROM" => "INNER JOIN b_tszh_meters TM ON (TMV.METER_ID = TM.ID)"),
		"VALUES_COUNT" => Array("FIELD" => "TM.VALUES_COUNT", "TYPE" => "int", "FROM" => "INNER JOIN b_tszh_meters TM ON (TMV.METER_ID = TM.ID)"),
		"DEC_PLACES" => Array("FIELD" => "TM.DEC_PLACES", "TYPE" => "int", "FROM" => "INNER JOIN b_tszh_meters TM ON (TMV.METER_ID = TM.ID)"),
		"CAPACITY" => Array("FIELD" => "TM.CAPACITY", "TYPE" => "int", "FROM" => "INNER JOIN b_tszh_meters TM ON (TMV.METER_ID = TM.ID)"),

		"ACCOUNT_ID" => Array(
			"FIELD" => "TMA_.ACCOUNT_ID",
			"FIELD_SELECT" => "(SELECT GROUP_CONCAT(TMAS.ACCOUNT_ID ORDER BY TMAS.ACCOUNT_ID SEPARATOR '|') FROM b_tszh_meters_accounts TMAS WHERE TMAS.METER_ID = TMV.METER_ID)", 
			"TYPE" => "int", 
			"FROM" => "INNER JOIN b_tszh_meters_accounts TMA_ ON (TMA_.METER_ID = TMV.METER_ID)", 
			/*"BINDING_TABLE" => "b_tszh_meters_accounts TMAW", 
			"BINDING_EXTERNAL_FIELD" => "TMV.METER_ID", 
			"BINDING_SELECT_FIELD" => "TMAW.METER_ID", 
			"BINDING_WHERE_FIELD" => "TMAW.ACCOUNT_ID"*/
		),
		"USER_ID" => Array(
			"FIELD" => "TA.USER_ID",
			"FIELD_SELECT" => "(SELECT GROUP_CONCAT(TAS.USER_ID ORDER BY TMAS.ACCOUNT_ID SEPARATOR '|') FROM b_tszh_accounts TAS INNER JOIN b_tszh_meters_accounts TMAS ON TAS.ID = TMAS.ACCOUNT_ID WHERE TMAS.METER_ID = TMV.METER_ID)", 
			"TYPE" => "int", 
			"FROM" => "INNER JOIN b_tszh_meters_accounts TMA ON (TMA.METER_ID = TMV.METER_ID) INNER JOIN b_tszh_accounts TA ON (TA.ID = TMA.ACCOUNT_ID)", 
			/*"BINDING_TABLE" => "b_tszh_accounts TAW INNER JOIN b_tszh_meters_accounts TMAW ON TAW.ID = TMAW.ACCOUNT_ID", 
			"BINDING_EXTERNAL_FIELD" => "TMV.METER_ID", 
			"BINDING_SELECT_FIELD" => "TMAW.METER_ID", 
			"BINDING_WHERE_FIELD" => "TAW.USER_ID"*/
		),
		"TSZH_ID" => Array(
			"FIELD" => "TA.TSZH_ID",
			"FIELD_SELECT" => "(SELECT GROUP_CONCAT(TAS.TSZH_ID ORDER BY TMAS.ACCOUNT_ID SEPARATOR '|') FROM b_tszh_accounts TAS INNER JOIN b_tszh_meters_accounts TMAS ON TAS.ID = TMAS.ACCOUNT_ID WHERE TMAS.METER_ID = TMV.METER_ID)", 
			"TYPE" => "int", 
			"FROM" => "INNER JOIN b_tszh_meters_accounts TMA ON (TMA.METER_ID = TMV.METER_ID) INNER JOIN b_tszh_accounts TA ON (TA.ID = TMA.ACCOUNT_ID)", 
			/*"BINDING_TABLE" => "b_tszh_accounts TAW INNER JOIN b_tszh_meters_accounts TMAW ON TAW.ID = TMAW.ACCOUNT_ID", 
			"BINDING_EXTERNAL_FIELD" => "TMV.METER_ID", 
			"BINDING_SELECT_FIELD" => "TMAW.METER_ID", 
			"BINDING_WHERE_FIELD" => "TAW.TSZH_ID"*/
		),
		"ACCOUNT_XML_ID" => Array(
			"FIELD" => "TA.XML_ID",
			"FIELD_SELECT" => "(SELECT GROUP_CONCAT(TAS.XML_ID ORDER BY TMAS.ACCOUNT_ID SEPARATOR '|') FROM b_tszh_accounts TAS INNER JOIN b_tszh_meters_accounts TMAS ON TAS.ID = TMAS.ACCOUNT_ID WHERE TMAS.METER_ID = TMV.METER_ID)", 
			"TYPE" => "string", 
			"FROM" => "INNER JOIN b_tszh_meters_accounts TMA ON (TMA.METER_ID = TMV.METER_ID) INNER JOIN b_tszh_accounts TA ON (TA.ID = TMA.ACCOUNT_ID)", 
			/*"BINDING_TABLE" => "b_tszh_accounts TAW INNER JOIN b_tszh_meters_accounts TMAW ON TAW.ID = TMAW.ACCOUNT_ID", 
			"BINDING_EXTERNAL_FIELD" => "TMV.METER_ID", 
			"BINDING_SELECT_FIELD" => "TMAW.METER_ID", 
			"BINDING_WHERE_FIELD" => "TAW.XML_ID"*/
		),
		"ACCOUNT_EXTERNAL_ID" => Array(
			"FIELD" => "TA.EXTERNAL_ID",
			"FIELD_SELECT" => "(SELECT GROUP_CONCAT(TAS.EXTERNAL_ID ORDER BY TMAS.ACCOUNT_ID SEPARATOR '|') FROM b_tszh_accounts TAS INNER JOIN b_tszh_meters_accounts TMAS ON TAS.ID = TMAS.ACCOUNT_ID WHERE TMAS.METER_ID = TMV.METER_ID)", 
			"TYPE" => "string", 
			"FROM" => "INNER JOIN b_tszh_meters_accounts TMA ON (TMA.METER_ID = TMV.METER_ID) INNER JOIN b_tszh_accounts TA ON (TA.ID = TMA.ACCOUNT_ID)", 
			/*"BINDING_TABLE" => "b_tszh_accounts TAW INNER JOIN b_tszh_meters_accounts TMAW ON TAW.ID = TMAW.ACCOUNT_ID", 
			"BINDING_EXTERNAL_FIELD" => "TMV.METER_ID", 
			"BINDING_SELECT_FIELD" => "TMAW.METER_ID", 
			"BINDING_WHERE_FIELD" => "TAW.EXTERNAL_ID"*/
		),
		"ACCOUNT_NAME" => Array(
			"FIELD" => "TA.NAME",
			"FIELD_SELECT" => "(SELECT GROUP_CONCAT(TAS.NAME ORDER BY TMAS.ACCOUNT_ID SEPARATOR '|') FROM b_tszh_accounts TAS INNER JOIN b_tszh_meters_accounts TMAS ON TAS.ID = TMAS.ACCOUNT_ID WHERE TMAS.METER_ID = TMV.METER_ID)", 
			"TYPE" => "string", 
			"FROM" => "INNER JOIN b_tszh_meters_accounts TMA ON (TMA.METER_ID = TMV.METER_ID) INNER JOIN b_tszh_accounts TA ON (TA.ID = TMA.ACCOUNT_ID)", 
			/*"BINDING_TABLE" => "b_tszh_accounts TAW INNER JOIN b_tszh_meters_accounts TMAW ON TAW.ID = TMAW.ACCOUNT_ID", 
			"BINDING_EXTERNAL_FIELD" => "TMV.METER_ID", 
			"BINDING_SELECT_FIELD" => "TMAW.METER_ID", 
			"BINDING_WHERE_FIELD" => "TAW.NAME"*/
		),
		"ACCOUNT_CITY" => Array(
			"FIELD" => "TA.CITY",
			"FIELD_SELECT" => "(SELECT GROUP_CONCAT(TAS.CITY ORDER BY TMAS.ACCOUNT_ID SEPARATOR '|') FROM b_tszh_accounts TAS INNER JOIN b_tszh_meters_accounts TMAS ON TAS.ID = TMAS.ACCOUNT_ID WHERE TMAS.METER_ID = TMV.METER_ID)", 
			"TYPE" => "string", 
			"FROM" => "INNER JOIN b_tszh_meters_accounts TMA ON (TMA.METER_ID = TMV.METER_ID) INNER JOIN b_tszh_accounts TA ON (TA.ID = TMA.ACCOUNT_ID)", 
			/*"BINDING_TABLE" => "b_tszh_accounts TAW INNER JOIN b_tszh_meters_accounts TMAW ON TAW.ID = TMAW.ACCOUNT_ID", 
			"BINDING_EXTERNAL_FIELD" => "TMV.METER_ID", 
			"BINDING_SELECT_FIELD" => "TMAW.METER_ID", 
			"BINDING_WHERE_FIELD" => "TAW.CITY"*/
		),
		"ACCOUNT_DISTRICT" => Array(
			"FIELD" => "TA.DISTRICT",
			"FIELD_SELECT" => "(SELECT GROUP_CONCAT(TAS.DISTRICT ORDER BY TMAS.ACCOUNT_ID SEPARATOR '|') FROM b_tszh_accounts TAS INNER JOIN b_tszh_meters_accounts TMAS ON TAS.ID = TMAS.ACCOUNT_ID WHERE TMAS.METER_ID = TMV.METER_ID)", 
			"TYPE" => "string", 
			"FROM" => "INNER JOIN b_tszh_meters_accounts TMA ON (TMA.METER_ID = TMV.METER_ID) INNER JOIN b_tszh_accounts TA ON (TA.ID = TMA.ACCOUNT_ID)", 
			/*"BINDING_TABLE" => "b_tszh_accounts TAW INNER JOIN b_tszh_meters_accounts TMAW ON TAW.ID = TMAW.ACCOUNT_ID", 
			"BINDING_EXTERNAL_FIELD" => "TMV.METER_ID", 
			"BINDING_SELECT_FIELD" => "TMAW.METER_ID", 
			"BINDING_WHERE_FIELD" => "TAW.DISTRICT"*/
		),
		"ACCOUNT_REGION" => Array(
			"FIELD" => "TA.REGION",
			"FIELD_SELECT" => "(SELECT GROUP_CONCAT(TAS.REGION ORDER BY TMAS.ACCOUNT_ID SEPARATOR '|') FROM b_tszh_accounts TAS INNER JOIN b_tszh_meters_accounts TMAS ON TAS.ID = TMAS.ACCOUNT_ID WHERE TMAS.METER_ID = TMV.METER_ID)", 
			"TYPE" => "string", 
			"FROM" => "INNER JOIN b_tszh_meters_accounts TMA ON (TMA.METER_ID = TMV.METER_ID) INNER JOIN b_tszh_accounts TA ON (TA.ID = TMA.ACCOUNT_ID)", 
			/*"BINDING_TABLE" => "b_tszh_accounts TAW INNER JOIN b_tszh_meters_accounts TMAW ON TAW.ID = TMAW.ACCOUNT_ID", 
			"BINDING_EXTERNAL_FIELD" => "TMV.METER_ID", 
			"BINDING_SELECT_FIELD" => "TMAW.METER_ID", 
			"BINDING_WHERE_FIELD" => "TAW.REGION"*/
		),
		"ACCOUNT_SETTLEMENT" => Array(
			"FIELD" => "TA.SETTLEMENT",
			"FIELD_SELECT" => "(SELECT GROUP_CONCAT(TAS.SETTLEMENT ORDER BY TMAS.ACCOUNT_ID SEPARATOR '|') FROM b_tszh_accounts TAS INNER JOIN b_tszh_meters_accounts TMAS ON TAS.ID = TMAS.ACCOUNT_ID WHERE TMAS.METER_ID = TMV.METER_ID)", 
			"TYPE" => "string", 
			"FROM" => "INNER JOIN b_tszh_meters_accounts TMA ON (TMA.METER_ID = TMV.METER_ID) INNER JOIN b_tszh_accounts TA ON (TA.ID = TMA.ACCOUNT_ID)", 
			/*"BINDING_TABLE" => "b_tszh_accounts TAW INNER JOIN b_tszh_meters_accounts TMAW ON TAW.ID = TMAW.ACCOUNT_ID", 
			"BINDING_EXTERNAL_FIELD" => "TMV.METER_ID", 
			"BINDING_SELECT_FIELD" => "TMAW.METER_ID", 
			"BINDING_WHERE_FIELD" => "TAW.SETTLEMENT"*/
		),
		"ACCOUNT_STREET" => Array(
			"FIELD" => "TA.STREET",
			"FIELD_SELECT" => "(SELECT GROUP_CONCAT(TAS.STREET ORDER BY TMAS.ACCOUNT_ID SEPARATOR '|') FROM b_tszh_accounts TAS INNER JOIN b_tszh_meters_accounts TMAS ON TAS.ID = TMAS.ACCOUNT_ID WHERE TMAS.METER_ID = TMV.METER_ID)", 
			"TYPE" => "string", 
			"FROM" => "INNER JOIN b_tszh_meters_accounts TMA ON (TMA.METER_ID = TMV.METER_ID) INNER JOIN b_tszh_accounts TA ON (TA.ID = TMA.ACCOUNT_ID)", 
			/*"BINDING_TABLE" => "b_tszh_accounts TAW INNER JOIN b_tszh_meters_accounts TMAW ON TAW.ID = TMAW.ACCOUNT_ID", 
			"BINDING_EXTERNAL_FIELD" => "TMV.METER_ID", 
			"BINDING_SELECT_FIELD" => "TMAW.METER_ID", 
			"BINDING_WHERE_FIELD" => "TAW.STREET"*/
		),
		"ACCOUNT_HOUSE" => Array(
			"FIELD" => "TA.STREET",
			"FIELD_SELECT" => "(SELECT GROUP_CONCAT(TAS.HOUSE ORDER BY TMAS.ACCOUNT_ID SEPARATOR '|') FROM b_tszh_accounts TAS INNER JOIN b_tszh_meters_accounts TMAS ON TAS.ID = TMAS.ACCOUNT_ID WHERE TMAS.METER_ID = TMV.METER_ID)", 
			"TYPE" => "string", 
			"FROM" => "INNER JOIN b_tszh_meters_accounts TMA ON (TMA.METER_ID = TMV.METER_ID) INNER JOIN b_tszh_accounts TA ON (TA.ID = TMA.ACCOUNT_ID)", 
			/*"BINDING_TABLE" => "b_tszh_accounts TAW INNER JOIN b_tszh_meters_accounts TMAW ON TAW.ID = TMAW.ACCOUNT_ID", 
			"BINDING_EXTERNAL_FIELD" => "TMV.METER_ID", 
			"BINDING_SELECT_FIELD" => "TMAW.METER_ID", 
			"BINDING_WHERE_FIELD" => "TAW.HOUSE"*/
		),
		"ACCOUNT_FLAT" => Array(
			"FIELD" => "TA.FLAT",
			"FIELD_SELECT" => "(SELECT GROUP_CONCAT(TAS.FLAT ORDER BY TMAS.ACCOUNT_ID SEPARATOR '|') FROM b_tszh_accounts TAS INNER JOIN b_tszh_meters_accounts TMAS ON TAS.ID = TMAS.ACCOUNT_ID WHERE TMAS.METER_ID = TMV.METER_ID)", 
			"TYPE" => "string", 
			"FROM" => "INNER JOIN b_tszh_meters_accounts TMA ON (TMA.METER_ID = TMV.METER_ID) INNER JOIN b_tszh_accounts TA ON (TA.ID = TMA.ACCOUNT_ID)", 
			/*"BINDING_TABLE" => "b_tszh_accounts TAW INNER JOIN b_tszh_meters_accounts TMAW ON TAW.ID = TMAW.ACCOUNT_ID", 
			"BINDING_EXTERNAL_FIELD" => "TMV.METER_ID", 
			"BINDING_SELECT_FIELD" => "TMAW.METER_ID", 
			"BINDING_WHERE_FIELD" => "TAW.FLAT"*/
		),
		"ACCOUNT_AREA" => Array(
			"FIELD" => "TA.FLAT",
			"FIELD_SELECT" => "(SELECT GROUP_CONCAT(TAS.AREA ORDER BY TMAS.ACCOUNT_ID SEPARATOR '|') FROM b_tszh_accounts TAS INNER JOIN b_tszh_meters_accounts TMAS ON TAS.ID = TMAS.ACCOUNT_ID WHERE TMAS.METER_ID = TMV.METER_ID)", 
			"TYPE" => "double", 
			"FROM" => "INNER JOIN b_tszh_meters_accounts TMA ON (TMA.METER_ID = TMV.METER_ID) INNER JOIN b_tszh_accounts TA ON (TA.ID = TMA.ACCOUNT_ID)", 
			/*"BINDING_TABLE" => "b_tszh_accounts TAW INNER JOIN b_tszh_meters_accounts TMAW ON TAW.ID = TMAW.ACCOUNT_ID", 
			"BINDING_EXTERNAL_FIELD" => "TMV.METER_ID", 
			"BINDING_SELECT_FIELD" => "TMAW.METER_ID", 
			"BINDING_WHERE_FIELD" => "TAW.AREA"*/
		),
		"ACCOUNT_LIVING_AREA" => Array(
			"FIELD" => "TA.LIVING_AREA",
			"FIELD_SELECT" => "(SELECT GROUP_CONCAT(TAS.LIVING_AREA ORDER BY TMAS.ACCOUNT_ID SEPARATOR '|') FROM b_tszh_accounts TAS INNER JOIN b_tszh_meters_accounts TMAS ON TAS.ID = TMAS.ACCOUNT_ID WHERE TMAS.METER_ID = TMV.METER_ID)", 
			"TYPE" => "double", 
			"FROM" => "INNER JOIN b_tszh_meters_accounts TMA ON (TMA.METER_ID = TMV.METER_ID) INNER JOIN b_tszh_accounts TA ON (TA.ID = TMA.ACCOUNT_ID)", 
			/*"BINDING_TABLE" => "b_tszh_accounts TAW INNER JOIN b_tszh_meters_accounts TMAW ON TAW.ID = TMAW.ACCOUNT_ID", 
			"BINDING_EXTERNAL_FIELD" => "TMV.METER_ID", 
			"BINDING_SELECT_FIELD" => "TMAW.METER_ID", 
			"BINDING_WHERE_FIELD" => "TAW.LIVING_AREA"*/
		),
		"ACCOUNT_PEOPLE" => Array(
			"FIELD" => "TA.PEOPLE",
			"FIELD_SELECT" => "(SELECT GROUP_CONCAT(TAS.PEOPLE ORDER BY TMAS.ACCOUNT_ID SEPARATOR '|') FROM b_tszh_accounts TAS INNER JOIN b_tszh_meters_accounts TMAS ON TAS.ID = TMAS.ACCOUNT_ID WHERE TMAS.METER_ID = TMV.METER_ID)", 
			"TYPE" => "int", 
			"FROM" => "INNER JOIN b_tszh_meters_accounts TMA ON (TMA.METER_ID = TMV.METER_ID) INNER JOIN b_tszh_accounts TA ON (TA.ID = TMA.ACCOUNT_ID)", 
			/*"BINDING_TABLE" => "b_tszh_accounts TAW INNER JOIN b_tszh_meters_accounts TMAW ON TAW.ID = TMAW.ACCOUNT_ID", 
			"BINDING_EXTERNAL_FIELD" => "TMV.METER_ID", 
			"BINDING_SELECT_FIELD" => "TMAW.METER_ID", 
			"BINDING_WHERE_FIELD" => "TAW.PEOPLE"*/
		),
		"ACCOUNT_ADDRESS_FULL" => Array(
   			"FIELD" => "CONCAT(TA.CITY,' ',TA.STREET,' ',TA.HOUSE,' ',TA.FLAT)",
			"FIELD_SELECT" => "(SELECT GROUP_CONCAT(CONCAT(TAS.CITY,' ',TAS.STREET,' ',TAS.HOUSE,' ',TAS.FLAT) ORDER BY TMAS.ACCOUNT_ID SEPARATOR '|') FROM b_tszh_accounts TAS INNER JOIN b_tszh_meters_accounts TMAS ON TAS.ID = TMAS.ACCOUNT_ID WHERE TMAS.METER_ID = TMV.METER_ID)", 
			"TYPE" => "string", 
			"FROM" => "INNER JOIN b_tszh_meters_accounts TMA ON (TMA.METER_ID = TMV.METER_ID) INNER JOIN b_tszh_accounts TA ON (TA.ID = TMA.ACCOUNT_ID)", 
			"CONCAT" => true, 
			/*"BINDING_TABLE" => "b_tszh_accounts TAW INNER JOIN b_tszh_meters_accounts TMAW ON TAW.ID = TMAW.ACCOUNT_ID", 
			"BINDING_EXTERNAL_FIELD" => "TMV.METER_ID", 
			"BINDING_SELECT_FIELD" => "TMAW.METER_ID", 
			"BINDING_WHERE_FIELD" => "CONCAT(TAW.CITY,' ',TAW.STREET,' ',TAW.HOUSE,' ',TAW.FLAT)"*/
		),
	);

	/**
	 * CTszhMeterValue::GetByID()
	 * ��������� ���������� ��������� �������� �� ���� ���������
	 *
	 * @param int $ID ��� ��������� ��������
	 * @return
	 */
	public static function GetByID($ID)
	{
		$ID = intval($ID);
		if ($ID <= 0)
			throw new \Bitrix\Main\ArgumentOutOfRangeException("ID", 1);
		return self::GetList(Array(), Array("ID" => $ID))->GetNext();
	}

	/**
	 * ��������� ������ ��������� ���������
	 * @param array $arOrder ������� ����������
	 * @param array $arFilter ���� �������
	 * @param bool|array $arGroupBy
	 * @param bool|array $arNavStartParams
	 * @param array $arSelectFields
	 * @return CTszhMeterValueResult
	 */
	public static function GetList($arOrder = array(), $arFilter = array(), $arGroupBy = false, $arNavStartParams = false, $arSelectFields = array())
	{
		$monthEndDay = COption::GetOptionInt('citrus.tszh', 'start_of_month', 25);
		self::$arGetListFields["MONTH"]["FIELD"] = str_replace('#DAY#', $monthEndDay, self::$arGetListFields["MONTH"]["FIELD"]);

		if (count($arSelectFields) <= 0) {
			$arSelectFields = Array(
				"ID", "METER_ID", "VALUE1", "VALUE2", "VALUE3", "AMOUNT1", "AMOUNT2", "AMOUNT3", "MODIFIED_BY", "TIMESTAMP_X", "MODIFIED_BY_OWNER", "MONTH",
				// ��� ���������
				"METER_HOUSE_METER", "UF_*",
			);
		} elseif (array_key_exists('*', $arSelectFields)) {
			$arSelectFields = array_keys(self::$arGetListFields);
		}

		if (count(array_intersect($arSelectFields, Array("VALUE1", "VALUE2", "VALUE3", "AMOUNT1", "AMOUNT2", "AMOUNT3"))) > 0)
		{
			$arSelectFields[] = "DEC_PLACES";
			$arSelectFields[] = "VALUES_COUNT";
			$arSelectFields[] = "CAPACITY";
		}

		if (self::USER_FIELD_ENTITY)
		{
			$obUserFieldsSql = new CUserTypeSQL;
			$obUserFieldsSql->SetEntity(self::USER_FIELD_ENTITY, "TMV.ID");
			$obUserFieldsSql->SetSelect($arSelectFields);
			$obUserFieldsSql->SetFilter($arFilter);
			$obUserFieldsSql->SetOrder($arOrder);

			$dbRes = CTszh::GetListMakeQuery(self::TABLE_NAME . " TMV", self::$arGetListFields, $arOrder, $arFilter, $arGroupBy, $arNavStartParams, $arSelectFields, $obUserFieldsSql, $strUserFieldsID = "TMV.ID");
		}
		else
			$dbRes = CTszh::GetListMakeQuery(self::TABLE_NAME . " TMV", self::$arGetListFields, $arOrder, $arFilter, $arGroupBy, $arNavStartParams, $arSelectFields);

		if (self::USER_FIELD_ENTITY && is_object($dbRes))
			$dbRes->SetUserFields($GLOBALS["USER_FIELD_MANAGER"]->GetUserFields(self::USER_FIELD_ENTITY));

		return new CTszhMeterValueResult($dbRes, self::$arGetListFields);
	}

	/**
	 * CTszhMeterValue::CheckFields()
	 * �������� �����
	 *
	 * @param array $arFields
	 * @param int $ID
	 * @return
	 */
	public static function CheckFields(&$arFields, $ID = 0)
	{
		global $APPLICATION, $DB;

		$arFields['METER_ID'] = IntVal($arFields['METER_ID']);
		$arFields['MODIFIED_BY'] = IntVal($arFields['MODIFIED_BY']);
		if ($arFields['METER_ID'] <= 0)
		{
			$APPLICATION->ThrowException("CTszhMeterValue error: METER_ID == 0");
			return false;
		}

		if (isset($arFields['VALUE1']))
			$arFields['VALUE1'] = DoubleVal($arFields['VALUE1']);
		if (isset($arFields['VALUE2']))
			$arFields['VALUE2'] = DoubleVal($arFields['VALUE2']);
		if (isset($arFields['VALUE3']))
			$arFields['VALUE3'] = DoubleVal($arFields['VALUE3']);

		for ($i=1; $i<=3; $i++)
		{
			if (isset($arFields["AMOUNT{$i}"]))
			{
				if (strlen($arFields["AMOUNT{$i}"]) > 0)
					$arFields["AMOUNT{$i}"] = DoubleVal($arFields["AMOUNT{$i}"]);
				else
					$arFields["AMOUNT{$i}"] = false;
			}
		}

		global $USER;
		if (!(is_object($USER) && $USER->IsAdmin()) || $arFields['MODIFIED_BY'] <= 0)
			$arFields['MODIFIED_BY'] = is_object($USER) ? $USER->GetID() : 1;

		unset($arFields['ID']);
		if (!array_key_exists("TIMESTAMP_X", $arFields))
			$arFields["TIMESTAMP_X"] = ConvertTimeStamp(time() + CTszh::GetTimeZoneOffset(), "FULL");

		if (!array_key_exists("MODIFIED_BY_OWNER", $arFields))
		{
			$strSql = "SELECT USER_ID FROM b_tszh_accounts TA INNER JOIN b_tszh_meters_accounts TMA ON TA.ID = TMA.ACCOUNT_ID WHERE TMA.METER_ID=" . $arFields['METER_ID'] . " AND TA.USER_ID = " . $arFields['MODIFIED_BY'];
			$res = $DB->Query($strSql, false, "FILE: ".__FILE__."<br> LINE: ".__LINE__);
			if ($res->Fetch())
				$arFields["MODIFIED_BY_OWNER"] = "Y";
			else
				$arFields["MODIFIED_BY_OWNER"] = "N";
		}

		// ��������� ��������� ��� ���������� �����������
		$meter = CTszhMeter::GetByID($arFields["METER_ID"]);
		if ($meter["CAPACITY"])
		{
			$arFields["VALUE1"] = fmod($arFields["VALUE1"], $maxValue = pow(10, $meter["CAPACITY"]));
			$arFields["VALUE2"] = fmod($arFields["VALUE2"], $maxValue);
			$arFields["VALUE3"] = fmod($arFields["VALUE3"], $maxValue);

		}

		if (self::USER_FIELD_ENTITY && !$GLOBALS['USER_FIELD_MANAGER']->CheckFields(self::USER_FIELD_ENTITY, $ID, $arFields))
			return false;

		return true;
	}

	/**
	 * CTszhMeterValue::Add()
	 * ���������� ��������� ��������
	 *
	 * @param array $arFields
	 * @return
	 */
	public static function Add($arFields)
	{
		if (!self::CheckFields($arFields))
			return false;

		$ID = CDatabase::Add(self::TABLE_NAME, $arFields);
		if (self::USER_FIELD_ENTITY && $ID > 0 && CTszh::hasUserFields($arFields))
			$GLOBALS['USER_FIELD_MANAGER']->Update(self::USER_FIELD_ENTITY, $ID, $arFields);

		return $ID;
	}

	/**
	 * CTszhMeterValue::Update()
	 * ��������� �������� ����� ���������� ��������� ��������
	 *
	 * @param int $ID ��� ��������� ��������
	 * @param array $arFields ���� �������� ��������� ��������
	 * @return
	 */
	public static function Update($ID, $arFields)
	{
		global $DB, $APPLICATION;

		$ID = IntVal($ID);
		if ($ID <= 0)
			throw new \Bitrix\Main\ArgumentOutOfRangeException("ID", 1);

		if (!self::CheckFields($arFields, $ID))
			return false;

		$strUpdate = $DB->PrepareUpdate(self::TABLE_NAME, $arFields);
		$strSql =
			"UPDATE " . self::TABLE_NAME . " SET ".
				$strUpdate.
				" WHERE ID=".$ID;

		$bSuccess = $DB->Query($strSql, false, "File: ".__FILE__."<br>Line: ".__LINE__);
		if (self::USER_FIELD_ENTITY && $bSuccess && CTszh::hasUserFields($arFields))
			$GLOBALS['USER_FIELD_MANAGER']->Update(self::USER_FIELD_ENTITY, $ID, $arFields);

		return $bSuccess;
	}

	/**
	 * CTszhMeterValue::Delete()
	 * �������� ���������
	 *
	 * @param int $ID ��� ��������� ��������
	 * @return
	 */
	public static function Delete($ID)
	{
		global $DB;

		$ID = intval($ID);
		if ($ID <= 0)
			throw new \Bitrix\Main\ArgumentOutOfRangeException("ID", 1);

		$DB->StartTransaction();

		$strSql = 'DELETE FROM ' . self::TABLE_NAME . ' WHERE ID='.$ID;
		$z = $DB->Query($strSql, false, "FILE: ".__FILE__."<br> LINE: ".__LINE__);

		if (self::USER_FIELD_ENTITY && $z)
			$GLOBALS['USER_FIELD_MANAGER']->Delete(self::USER_FIELD_ENTITY, $ID);

		$DB->Commit();

		return true;
	}
}

class CTszhMeterValueResult extends CTszhMultiValuesResult
{
	public static function processMeterPrecision($arResult)
	{
		if ($arResult && count(array_intersect_key($arResult, Array("VALUE1" => 1, "VALUE2" => 1, "VALUE3" => 1, "AMOUNT1" => 1, "AMOUNT2" => 1, "AMOUNT3" => 1))) > 0)
		{
			$decimalPlaces = is_set($arResult, "DEC_PLACES") ? $arResult["DEC_PLACES"] : 2;
			for ($i=1; $i<=3; $i++)
			{
				if (array_key_exists("VALUE{$i}", $arResult))
					$arResult["VALUE{$i}"] = number_format($arResult["VALUE{$i}"], $decimalPlaces, ".", "");
				if (array_key_exists("AMOUNT{$i}", $arResult) && strlen($arResult["AMOUNT{$i}"]) > 0)
					$arResult["AMOUNT{$i}"] = number_format($arResult["AMOUNT{$i}"], $decimalPlaces, ".", "");
			}
		}
		return $arResult;
	}

	public function GetNext($bTextHtmlAuto=true, $use_tilda=true)
	{
		$arResult = parent::GetNext($bTextHtmlAuto, $use_tilda);
		return self::processMeterPrecision($arResult);
	}

	public function NavNext($bSetGlobalVars=true, $strPrefix="str_", $bDoEncode=true, $bSkipEntities=true)
	{
		$arResult = parent::NavNext($bSetGlobalVars, $strPrefix, $bDoEncode, $bSkipEntities);
		return self::processMeterPrecision($arResult);
	}
}

class CTszhMeterValueAdminResult extends CTszhMultiValuesAdminResult
{
	public function GetNext($bTextHtmlAuto=true, $use_tilda=true)
	{
		$arResult = parent::GetNext($bTextHtmlAuto, $use_tilda);
		return CTszhMeterValueResult::processMeterPrecision($arResult);
	}

	public function NavNext($bSetGlobalVars=true, $strPrefix="str_", $bDoEncode=true, $bSkipEntities=true)
	{
		$arResult = parent::NavNext($bSetGlobalVars, $strPrefix, $bDoEncode, $bSkipEntities);
		return CTszhMeterValueResult::processMeterPrecision($arResult);
	}
}
?>