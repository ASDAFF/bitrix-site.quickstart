<?
$citrus_tszh_default_option = array(
	"user_group_id" => "3",
	"meters_block_edit" => "N",
	"dolg_subscription_min_debt" => 1000,
	"1C_FILE_SIZE_LIMIT" => 262144,
	//"autosend_modified_receipts" => "N",
	"not_show_personal_data" => "N",
	'1c_exchange.UpdateMode' => 'Y',
	'1c_exchange.CreateUsers' => 'Y',
	'1c_exchange.UpdateUsers' => "N",
	'1c_exchange.Action' => 'A',
	"1c_exchange.Depersonalize" => "N",
	"1c_exchange.Debug" => "Y",

	"post_354_ShowPenaltiesColumn" => "N",
);
?>
