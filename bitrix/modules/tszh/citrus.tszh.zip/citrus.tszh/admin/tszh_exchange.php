<?
define('BX_SESSION_ID_CHANGE', false);
define('BX_SKIP_POST_UNQUOTE', true);
define("NOT_CHECK_PERMISSIONS", true);
define("TSZH_CANCEL_REDIRECT", true);
define("STATISTIC_SKIP_ACTIVITY_CHECK", true);
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
?><?

// dezmaryino.ru
if ($_REQUEST['mode'] == 'export' && $_REQUEST['type'] == 'questions')
{
	$arSite = $GLOBALS['APPLICATION']->GetSiteByDir();
	$siteID = is_array($arSite) ? $arSite["LID"] : false;
	
	?><?$APPLICATION->IncludeComponent("citrus:faq.export","",  array(
			"IBLOCK_TYPE" =>'services',
			"IBLOCK_ID" => COption::GetOptionInt('citrus.tszh', "export_block_id", $siteID),
			"GROUP_PERMISSIONS" => 1,
			"DATE_OF_DISCHARGE"=>""
			)
		)
	?><?
}
else
{
	?><?$APPLICATION->IncludeComponent("citrus:tszh.1c.exchange", "", Array(
		"DEBUG" => "N",
		"FILE_SIZE_LIMIT" => COption::GetOptionString("citrus.tszh", "1C_FILE_SIZE_LIMIT", 0),
		)
	);?><?
}

?><?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>