<?require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin_before.php");

ob_start();
if (!CTszhFunctionalityController::CheckEdition())
{
	$c = ob_get_contents();
	ob_end_clean();
	require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin_after.php");
	echo $c;
	require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/epilog_admin.php");
	return;
}
$demoNotice = ob_get_contents();
ob_end_clean();

$modulePermissions = $APPLICATION->GetGroupRight("citrus.tszh");
if ($modulePermissions<="R")
	$APPLICATION->AuthForm(GetMessage("ACCESS_DENIED"));

require_once($_SERVER["DOCUMENT_ROOT"].BX_ROOT."/modules/citrus.tszh/include.php");
IncludeModuleLangFile(__FILE__);

$strRedirect = BX_ROOT."/admin/tszh_edit.php?lang=".LANG;
$strRedirectList = BX_ROOT."/admin/tszh_list.php?lang=".LANG;

ClearVars();
$errorMessage = "";
$bVarsFromForm = false;
$message = null;

$ID = IntVal($ID);

$aTabs = array(
	array("DIV" => "edit1", "TAB" => GetMessage("TSZH_EDIT_TAB1"), "ICON" => "citrus.tszh", "TITLE" => GetMessage("TSZH_EDIT_TAB1_TITLE")),
	array("DIV" => "edit2", "TAB" => GetMessage("TSZH_EDIT_TAB2"), "ICON" => "citrus.tszh", "TITLE" => GetMessage("TSZH_EDIT_TAB2_TITLE")),
);


$UF_ENTITY = "TSZH";

$tabControl = new CAdminForm("tszhEdit", $aTabs);

if ($REQUEST_METHOD=="POST" && strlen($Update)>0 && $modulePermissions>="W" && check_bitrix_sessid())
{
	if ($modulePermissions < "W")
		$errorMessage .= GetMessage("TE_ERROR_NO_PERMISSIONS") . "<br>";

	if ($ID > 0 && !($arOldTszh = CTszh::GetByID($ID)))
	{
		$errorMessage .= str_replace('#ID#', $ID, GetMessage("TE_ERROR_TSZH_NOT_FOUND")) . "<br>";
	}

	if ($MONETA_ENABLED == "Y" && !in_array($MONETA_SCHEME, array(1, 2)))
	{
		$monetaSchemeErrorFlag = true;
		if ($ID > 0 && is_array($arOldTszh) && !empty($arOldTszh) && $arOldTszh["MONETA_OFFER"] == "Y")
			$monetaSchemeErrorFlag = false;

		if ($monetaSchemeErrorFlag)
			$errorMessage .= GetMessage("TE_ERROR_MONETA_SCHEME_NOT_CHOSEN");
	}

	if (strlen($errorMessage) <= 0)
	{
		$arFields = Array(
			"NAME" => $NAME,
			"SITE_ID" => $SITE_ID,
			"CODE" => $CODE,
			"INN" => $INN,
			"KPP" => $KPP,
			"RSCH" => $RSCH,
			"BANK" => $BANK,
			"KSCH" => $KSCH,
			"BIK" => $BIK,
			"HEAD_NAME" => $HEAD_NAME,
			
			"ADDRESS" => $ADDRESS,
			"LEGAL_ADDRESS" => $LEGAL_ADDRESS,
			"EMAIL" => $EMAIL,
			"PHONE" => $PHONE,
			"PHONE_DISP" => $PHONE_DISP,
			"RECEIPT_TEMPLATE" => $RECEIPT_TEMPLATE,
			"RECEIPT_EPD1161_CONTACT_CENTER" => $RECEIPT_EPD1161_CONTACT_CENTER,

			"METER_VALUES_START_DATE" => $METER_VALUES_START_DATE,
			"METER_VALUES_END_DATE" => $METER_VALUES_END_DATE,

			"MONETA_ENABLED" => $MONETA_ENABLED == "Y" ? "Y" : "N",
			"MONETA_OFFER" => $MONETA_OFFER == "Y" ? "Y" : "N",
			"MONETA_EMAIL" => $MONETA_EMAIL,

			"OFFICE_HOURS" => $_POST["OFFICE_HOURS"],
		);
		
		if (tszhCheckMinEdition('standard'))
		{
			$arFields = array_merge(
				$arFields,
				Array(	
					"SUBSCRIBE_DOLG_ACTIVE" => $SUBSCRIBE_DOLG_ACTIVE == "Y" ? "Y" : "N",
					"SUBSCRIBE_DOLG_MIN_SUM" => $SUBSCRIBE_DOLG_MIN_SUM,
					"SUBSCRIBE_DOLG_DATE" => $SUBSCRIBE_DOLG_DATE,
					"SUBSCRIBE_METERS_ACTIVE" => $SUBSCRIBE_METERS_ACTIVE == "Y" ? "Y" : "N",
					"SUBSCRIBE_METERS_DATE" => $SUBSCRIBE_METERS_DATE,
					"SUBSCRIBE_RECEIPT_ACTIVE" => $SUBSCRIBE_RECEIPT_ACTIVE == "Y" ? "Y" : "N",
					"SUBSCRIBE_RECEIPT_SEND_PDF" => $SUBSCRIBE_RECEIPT_SEND_PDF == "Y" ? "Y" : "N",
				)
			);
		}

		$USER_FIELD_MANAGER->EditFormAddFields($UF_ENTITY, $arFields);
		if ($ID > 0) {
			$bResult = CTszh::Update($ID, $arFields);
		} else {
			$ID = CTszh::Add($arFields);
			$bResult = $ID > 0;
		}
		if ($bResult)
		{
			// error messages from event handlers
			if ($ex = $APPLICATION->GetException())
				$errorMessage .= $ex->GetString();
		}
		elseif (!$bResult)
		{
			if ($ex = $APPLICATION->GetException())
				$errorMessage .= $ex->GetString();
			else
				$errorMessage .= GetMessage("TE_ERROR_SAVE");
		}
	}

	if (strlen($errorMessage) <= 0)
	{
		if (strlen($apply) <= 0)
			LocalRedirect($strRedirectList . GetFilterParams("filter_", false));
		else
			LocalRedirect($strRedirect."&ID=".$ID."&".$tabControl->ActiveTabParam());
	}
	else
	{
		$bVarsFromForm = true;
	}
}

//require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/citrus.tszh/prolog.php");

CJsCore::Init(Array("jquery"));

if ($ID > 0)
	$APPLICATION->SetTitle(str_replace('#ID#', $ID, GetMessage("TE_TITLE_EDIT")));
else
	$APPLICATION->SetTitle(GetMessage("TE_TITLE_ADD"));

require_once ($DOCUMENT_ROOT.BX_ROOT."/modules/main/include/prolog_admin_after.php");

echo $demoNotice;

$dbTszh = CTszh::GetList(
	Array(),
	Array("ID" => $ID),
	false,
	Array("nTopCount" => 1),
	Array("*")
);

if (!$arTszh = $dbTszh->ExtractFields("str_"))
{
	if ($modulePermissions < "W")
		$errorMessage .= GetMessage("TE_ERROR_NO_ADD_PERMISSIONS") . "<br />";
	$ID = 0;
}

if ($bVarsFromForm) {
	$DB->InitTableVarsForEdit("b_tszh", "", "str_");
}

if(strlen($errorMessage)>0)
	echo CAdminMessage::ShowMessage(Array("DETAILS"=>$errorMessage, "TYPE"=>"ERROR", "MESSAGE"=> GetMessage("TE_ERROR_HAPPENED"), "HTML"=>true));

if ($ID > 0 && !CTszh::postValidate($ID))
{
	echo CAdminMessage::ShowMessage(Array("DETAILS"=>'<ul><li>' . implode('<li>', CTszh::$validationErrors) . '</ul>' . GetMessage("TSZH_VALIDATION_FAILED_NOTE"), "TYPE"=>"ERROR", "MESSAGE"=> GetMessage("TSZH_VALIDATION_FAILED"), "HTML"=>true));
}

/**
 *   CAdminForm()
**/

$aMenu = array(
	array(
		"TEXT" => GetMessage("TE_M_ACCOUNT_LIST"),
		"LINK" => "/bitrix/admin/tszh_list.php?lang=".LANG.GetFilterParams("find_"),
		"ICON"	=> "btn_list",
		"TITLE" => GetMessage("TE_M_ACCOUNT_LIST_TITLE"),
	)
);

if ($ID > 0 && $modulePermissions >= "W")
{
	$aMenu[] = array("SEPARATOR" => "Y");

	$aMenu[] = array(
			"TEXT" => GetMessage("TE_M_ADD_TSZH"),
			"LINK" => "/bitrix/admin/tszh_edit.php?lang=".LANG.GetFilterParams("find_"),
			"ICON"	=> "btn_new",
			"TITLE" => GetMessage("TE_M_ADD_TSZH_TITLE"),
		);

	if ($modulePermissions >= "W")
	{
		$aMenu[] = array(
				"TEXT" => GetMessage("TE_M_DELETE_TSZH"),
				"LINK" => "javascript:if(confirm('" . GetMessage("TE_M_DELETE_TSZH_CONFIRM") . "')) window.location='/bitrix/admin/tszh_list.php?ID=".$ID."&action=delete&lang=".LANG."&".bitrix_sessid_get()."#tb';",
				"WARNING" => "Y",
				"ICON"	=> "btn_delete"
			);
	}

}
if(!empty($aMenu))
	$aMenu[] = array("SEPARATOR"=>"Y");
$link = DeleteParam(array("mode"));
$link = $GLOBALS["APPLICATION"]->GetCurPage()."?mode=settings".($link <> ""? "&".$link:"");
$aMenu[] = array(
	"TEXT"=> GetMessage("TE_FORM_SETTING"),
	"TITLE"=> GetMessage("TE_FORM_SETTNG_TITLE"),
	"LINK"=>"javascript:".$tabControl->GetName().".ShowSettings('".htmlspecialcharsbx(CUtil::addslashes($link))."')",
	"ICON"=>"btn_settings",
);

$context = new CAdminContextMenu($aMenu);
$context->Show();


if(method_exists($USER_FIELD_MANAGER, 'showscript')) {
	$tabControl->BeginPrologContent();
	echo $USER_FIELD_MANAGER->ShowScript();
	$tabControl->EndPrologContent();
}


// ============ FORM PROLOG ==================
$tabControl->BeginEpilogContent();
echo GetFilterHiddens("filter_");
?>
<input type="hidden" name="Update" value="Y" />
<input type="hidden" name="lang" value="<?echo LANG ?>" />
<input type="hidden" name="ID" value="<?echo $ID ?>" />
<?
echo bitrix_sessid_post();
$tabControl->EndEpilogContent();
// ===========================================

$tabControl->Begin(array(
	"FORM_ACTION" => $APPLICATION->GetCurPage(),
	"FORM_ATTRIBUTES" => "method=\"POST\" enctype=\"multipart/form-data\"",
));
$tabControl->BeginNextFormTab();

	if ($str_ID > 0) {
		$tabControl->AddViewField("ID", "ID", $str_ID);
		$tabControl->AddViewField("TIMESTAMP_X", GetMessage("TEF_TIMESTAMP_X"), $str_TIMESTAMP_X);
	}
	
	$tabControl->AddEditField("NAME", GetMessage("TEF_NAME"), true, array("size"=>50, "maxlength"=>100), $str_NAME);

	$rsSites = CSite::GetList($by="sort", $order="desc", Array());
	$arSites = Array();
	while ($arSite = $rsSites->Fetch()) {
		$arSites[$arSite['ID']] = '[' . $arSite["ID"] . '] ' . $arSite["NAME"];
	}
	$tabControl->AddDropDownField("SITE_ID", GetMessage("TEF_SITE_ID"), true, $arSites, $str_SITE_ID);
	
	$tabControl->AddEditField("CODE", GetMessage("TEF_CODE"), false, array("size"=>30, "maxlength"=>100), $str_CODE);

	$tabControl->AddSection("RECEIPT_INFO", GetMessage("TEF_RECEIPT_INFO"), false);
	$tabControl->AddEditField("ADDRESS", GetMessage("TEF_ADDRESS"), false, array("size"=>50, "maxlength"=>255), $str_ADDRESS);
	$tabControl->AddEditField("PHONE", GetMessage("TEF_PHONE"), false, array("size"=>50, "maxlength"=>250), $str_PHONE);
	$tabControl->AddEditField("PHONE_DISP", GetMessage("TEF_PHONE_DISP"), false, array("size"=>50, "maxlength"=>255), $str_PHONE_DISP);
	$tabControl->AddDropDownField("RECEIPT_TEMPLATE", GetMessage("TEF_RECEIPT_TEMPLATE"), false, CTszhReceiptTemplateProcessor::getTemplatesForSelect("FROM_COMPONENT_SETTINGS"), $str_RECEIPT_TEMPLATE);
	$tabControl->AddTextField("RECEIPT_EPD1161_CONTACT_CENTER", GetMessage("TEF_RECEIPT_EPD1161_CONTACT_CENTER"), $str_RECEIPT_EPD1161_CONTACT_CENTER, array("cols"=>46, "rows"=>3));

	$tabControl->AddSection("BANK_TITLE", GetMessage("TEF_BANK_TITLE"), false);
	$tabControl->AddEditField("INN", GetMessage("TEF_INN"), false, array("size"=>12, "maxlength"=>12), $str_INN);
	$tabControl->AddEditField("KPP", GetMessage("TEF_KPP"), false, array("size"=>9, "maxlength"=>9), $str_KPP);
	$tabControl->AddEditField("RSCH", GetMessage("TEF_RSCH"), false, array("size"=>20, "maxlength"=>24), $str_RSCH);
	$tabControl->AddEditField("BANK", GetMessage("TEF_BANK"), false, array("size"=>50, "maxlength"=>100), $str_BANK);
	$tabControl->AddEditField("KSCH", GetMessage("TEF_KSCH"), false, array("size"=>20, "maxlength"=>24), $str_KSCH);
	$tabControl->AddEditField("BIK", GetMessage("TEF_BIK"), false, array("size"=>12, "maxlength"=>16), $str_BIK);

	$tabControl->AddSection("ADDITIONAL", GetMessage("TEF_ADDITIONAL"), false);

	$tabControl->AddEditField("HEAD_NAME", GetMessage("TEF_HEAD_NAME"), false, array("size"=>24, "maxlength"=>255), $str_HEAD_NAME);
	$tabControl->AddEditField("LEGAL_ADDRESS", GetMessage("TEF_LEGAL_ADDRESS"), false, array("size"=>50, "maxlength"=>255), $str_LEGAL_ADDRESS);
	$tabControl->AddEditField("EMAIL", GetMessage("TEF_EMAIL"), false, array("size"=>50, "maxlength"=>255), $str_EMAIL);

	if (CModule::IncludeModule("citrus.tszhpayment") && !CTszhFunctionalityController::isUkrainianVersion())
	{
		$tabControl->AddCheckBoxField("MONETA_ENABLED", GetMessage("CITRUS_TSZH_PAYMENT_MONETA_ENABLED"), false, "Y", ($str_MONETA_ENABLED=="Y"));

		$tabControl->AddEditField("MONETA_EMAIL", GetMessage("TEF_MONETA_EMAIL"), true, array("size"=>50, "maxlength"=>255), $str_MONETA_EMAIL);

		$tabControl->BeginCustomField("MONETA_OFFER", strip_tags(GetMessage("CITRUS_TSZH_PAYMENT_MONETA_OFFER")), false);
		?>
			<tr id="tr_MONETA_OFFER" <?=$str_MONETA_ENABLED == "Y" ? '' : 'class="hidden"'?>>
				<td colspan="2">
					<style type="text/css">
						#tr_MONETA_OFFER,
						#tr_MONETA_EMAIL {
							display: none;
						}
					</style>
					<script>
						var $monetaEnabledCheckbox = $('#tr_MONETA_ENABLED input[type=checkbox]'),
							$monetaOffer = $('#tr_MONETA_OFFER'),
							$monetaEmail = $('#tr_MONETA_EMAIL'),
							monetaEnabledCheck = function() {
								var checked = $monetaEnabledCheckbox.is(':checked');
								if (checked) {
									$monetaEmail.fadeIn(300);
									$monetaOffer.fadeIn(300);
								}
								else {
									$monetaEmail.fadeOut(300);
									$monetaOffer.fadeOut(300);
								}
							};

						$(function () {
							monetaEnabledCheck();
							$monetaEnabledCheckbox.change(monetaEnabledCheck);
							$('input[name=MONETA_EMAIL]').change(function () {
								$('.moneta-email').html(this.value);
							});
						});
					</script>
					<?if (function_exists("tszhPaymentMonetaUsageTable"))
						tszhPaymentMonetaUsageTable($arTszh["MONETA_ENABLED"], $arTszh["MONETA_OFFER"], "MONETA_SCHEME", $str_MONETA_EMAIL)?>
				</td>
			</tr>
		<?
		$tabControl->EndCustomField("MONETA_OFFER", '<input type="hidden" name="MONETA_OFFER" value="'.$str_MONETA_OFFER.'">');
	}

	$tabControl->AddSection("OFFICE_HOURS_SECTION", GetMessage("TEF_OFFICE_HOURS"), false);
	$tabControl->BeginCustomField("OFFICE_HOURS", "", false);
	?>
		<tr>
			<td colspan="2" style="text-align: center;">
				<?$APPLICATION->IncludeComponent(
					"citrus:tszh.office_hours.edit",
					"",
					Array(
						"OFFICE_HOURS" => $bVarsFromForm ? $arFields["OFFICE_HOURS"] : $arTszh["OFFICE_HOURS"],
					),
					false
				);?>
			</td>
		</tr>
	<?
	$tabControl->EndCustomField("OFFICE_HOURS", "");

	$tabControl->AddSection("METER_VALUES_PERIOD", GetMessage("TEF_METER_VALUES_PERIOD"), false);
	$tabControl->AddEditField("METER_VALUES_START_DATE", GetMessage("TEF_METER_VALUES_START_DATE"), false, array("size"=>5, "maxlength"=>2), $str_METER_VALUES_START_DATE);
	$tabControl->AddEditField("METER_VALUES_END_DATE", GetMessage("TEF_METER_VALUES_END_DATE"), false, array("size"=>5, "maxlength"=>2), $str_METER_VALUES_END_DATE);

	// ������� ������ � ����������������� ������, ���� �� ��� ���� ���� ��� � ������������ ���� ����� �� ���������� �����
	if(
		(count($USER_FIELD_MANAGER->GetUserFields($UF_ENTITY)) > 0) ||
		($USER_FIELD_MANAGER->GetRights($UF_ENTITY) >= "W")
	)
	{
		$tabControl->AddSection('USER_FIELDS', GetMessage("TEF_USER_FIELDS"));
		$tabControl->ShowUserFields($UF_ENTITY, $str_ID, $bVarsFromForm);
	}

	if (tszhCheckMinEdition('standard'))
	{
		$tabControl->BeginNextFormTab();

		$tabControl->AddSection("SUBSCRIBE_DOLG", GetMessage("TEF_SUBSCRIBE_DOLG_TITLE"), false);
		$tabControl->AddCheckBoxField("SUBSCRIBE_DOLG_ACTIVE", GetMessage("TEF_SUBSCRIBE_ACTIVE"), false, "Y", ($str_SUBSCRIBE_DOLG_ACTIVE=="Y"));
		$tabControl->AddEditField("SUBSCRIBE_DOLG_MIN_SUM", GetMessage("TEF_SUBSCRIBE_DOLG_MIN_SUM"), false, array("size"=>5, "maxlength"=>15), $str_SUBSCRIBE_DOLG_MIN_SUM);
		$tabControl->AddEditField("SUBSCRIBE_DOLG_DATE", GetMessage("TEF_SUBSCRIBE_DATE"), false, array("size"=>5, "maxlength"=>2), $str_SUBSCRIBE_DOLG_DATE);
		$tabControl->AddViewField("SUBSCRIBE_DOLG_LAST_PERIOD", GetMessage("TEF_SUBSCRIBE_LAST_PERIOD"), $str_SUBSCRIBE_DOLG_LAST_PERIOD);
	
		$tabControl->AddSection("SUBSCRIBE_METERS", GetMessage("TEF_SUBSCRIBE_METERS_TITLE"), false);
		$tabControl->AddCheckBoxField("SUBSCRIBE_METERS_ACTIVE", GetMessage("TEF_SUBSCRIBE_ACTIVE"), false, "Y", ($str_SUBSCRIBE_METERS_ACTIVE=="Y"));
		$tabControl->AddEditField("SUBSCRIBE_METERS_DATE", GetMessage("TEF_SUBSCRIBE_DATE"), false, array("size"=>5, "maxlength"=>2), $str_SUBSCRIBE_METERS_DATE);
		$tabControl->AddViewField("SUBSCRIBE_METERS_LAST_PERIOD", GetMessage("TEF_SUBSCRIBE_LAST_PERIOD"), $str_SUBSCRIBE_METERS_LAST_PERIOD);
		
		$tabControl->AddSection("SUBSCRIBE_RECEIPT", GetMessage("TEF_SUBSCRIBE_RECEIPT_TITLE"), false);
		$tabControl->BeginCustomField("SUBSCRIBE_RECEIPT_NOTE", "", false);
		?>
		<tr>
			<td></td>
			<td colspan="1">
				<?
				echo BeginNote();
				echo GetMessage("TEF_SUBSCRIBE_RECEIPT_NOTE");
				echo EndNote();
				?>
			</td>
		</tr>
		<?
		$pdfAvailable = CTszhSubscribe::isPdfAvailable();

		$tabControl->EndCustomField("SUBSCRIBE_RECEIPT_NOTE");
		$tabControl->AddCheckBoxField("SUBSCRIBE_RECEIPT_ACTIVE", GetMessage("TEF_SUBSCRIBE_ACTIVE"), false, "Y", ($str_SUBSCRIBE_RECEIPT_ACTIVE=="Y"));
		$tabControl->AddCheckBoxField("SUBSCRIBE_RECEIPT_SEND_PDF", GetMessage("TEF_SUBSCRIBE_SEND_PDF"), false, "Y", ($str_SUBSCRIBE_RECEIPT_SEND_PDF=="Y"), $pdfAvailable ? array() : array("disabled"));

		if (!$pdfAvailable)
		{
			$tabControl->BeginCustomField("SUBSCRIBE_RECEIPT_PDF_ERRORS", "", false);
			?>
			<tr>
				<td></td>
				<td colspan="1">
					<?
					echo GetMessage("CITRUS_TSZH_SUBSCRIBE_PDF_ERRORS");
					if ($ex = $APPLICATION->GetException())
						echo '<blockquote style="font-style: italic; margin-bottom:0">' . nl2br($ex->GetString(), false) . '</blockquote>';
					?>
				</td>
			</tr>
			<?
			$tabControl->EndCustomField("SUBSCRIBE_RECEIPT_PDF_ERRORS");
		}

		if ($str_SUBSCRIBE_RECEIPT_ACTIVE=="Y")
		{
			$dateSent = CTszhAccountPeriod::GetList(array("DATE_SENT" => "DESC"), array("TSZH_ID" => $str_ID), false, false, array("DATE_SENT"))->Fetch();
			$dateSent = is_array($dateSent) ? $dateSent["DATE_SENT"] : '&mdash;';
			$tabControl->AddViewField("SUBSCRIBE_RECEIPT_LAST_PERIOD", GetMessage("TEF_SUBSCRIBE_LAST_PERIOD"), $dateSent);
		}

		if (!strlen(COption::GetOptionString("citrus.tszh", "hide_pdf_warning")))
		{
			$tabControl->BeginCustomField("SUBSCRIBE_RECEIPT_NOTE2", "", false);
			?>
			<tr>
				<td></td>
				<td colspan="1">
					<?
					echo BeginNote();
					echo GetMessage("TEF_SUBSCRIBE_SEND_PDF_WARNING");
					echo EndNote();
					?>
				</td>
			</tr>
			<?
			$tabControl->EndCustomField("SUBSCRIBE_RECEIPT_NOTE2");
		}

	}

	$tabControl->Buttons(Array(
		"disabled" => ($modulePermissions < "W"),
		"back_url" => "/bitrix/admin/tszh_account_list.php?lang=".LANG.GetFilterParams("filter_")
	));


	$tabControl->Show();

	$tabControl->ShowWarnings($tabControl->GetName(), $message);

if(!defined('BX_PUBLIC_MODE') || BX_PUBLIC_MODE != 1):?>
<?echo BeginNote();?>
<span class="required">*</span> <?echo GetMessage("REQUIRED_FIELDS")?>
<?echo EndNote(); ?>
<?endif;?>
<?require_once ($DOCUMENT_ROOT.BX_ROOT."/modules/main/include/epilog_admin.php");?>