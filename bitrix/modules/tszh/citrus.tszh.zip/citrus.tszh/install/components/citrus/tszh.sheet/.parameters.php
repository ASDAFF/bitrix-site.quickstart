<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentParameters = array(
	"GROUPS" => array(
	),
	"PARAMETERS"  =>  array(
		"MAX_COUNT" => array(
			"NAME" => GetMessage("COMP_MAX_COUNT"),
			"TYPE" => "STRING",
			"DEFAULT" => '10',
		),
		"RECEIPT_URL" => Array(
			"NAME" => GetMessage("RECEIPT_URL"),
			"TYPE" => "STRING",
			"DEFAULT" => "#SITE_DIR#personal/receipt/?period=#ID#",
		),
		"CACHE_TIME"  =>  Array("DEFAULT"=>300),
	),
);

if (CModule::IncludeModule("iblock"))
	CIBlockParameters::AddPagerSettings($arComponentParameters, GetMessage("COMP_NAV_PAGER"), true, true);


?>