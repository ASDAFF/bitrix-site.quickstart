<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

// �������� ����� ������, �� ������� ������� ������
$sourceFields = array(
	array(
		"name",
		"edizm",
		"ammount",
		$arResult["HAS_AMOUNT_NOTES"] ? '*' : null,
		"hammount",
		$arResult["HAS_AMOUNT_NOTES"] ? '*' : null,
		"tarif1..tariff3",
		"sum-hsum",
		"hsum",
		"sum",
		"correction",
		"compensation",
		$arResult["HAS_PENALTIES"] ? 'peni' : null,
		"sumtopay",
		"sumtopay-hsumtopay",
		"hsumtopay",
	),
	array(
		"norm-hnorm",
		"hnorm",
		"meter",
		"hmeter",
		"volumep",
		"volumea",
		"volumeh",
	),
);
$colsCount = array();
foreach ($sourceFields as $idx => &$sf)
{
	$sf = array_values(array_diff($sf, array(null)));
	$colsCount[$idx] = count($sf);
}
unset($sf);

?>
<table class="rcpt-inner rcpt-inner-table" style="border: none; margin-top: 1.5em; width: 100%;">
	<tr class="rcpt-inner-empty">
		<td colspan="<?=(count($sourceFields[0]))?>" style="width: 66%;">
			<?=GetMessage("TPL_SECTION3")?>
		</td>
		<td rowspan="5" style="border-bottom: none; width: 2.5em;"></td>
		<td colspan="<?=(count($sourceFields[1]))?>">
			<?=GetMessage("TPL_SECTION4")?>
		</td>
	</tr>
	<tr>
		<th rowspan="3" style="width: 15%"><?=GetMessage("TPL_SERVICES")?></th>
		<th rowspan="3"><?=GetMessage("TPL_UNITS")?></th>
		<th rowspan="2" colspan="<?=($arResult["HAS_AMOUNT_NOTES"] ? 4 : 2)?>"><?=GetMessage("TPL_SERVICE_AMOUNT")?></th>
		<th rowspan="3"><?=GetMessage("TPL_TARIFF")?></th>
		<th rowspan="2" colspan="2"><?=GetMessage("TPL_SERVICE_PAYMENT")?></th>
		<th rowspan="3"><?=GetMessage("TPL_PERIOD_SUMM")?></th>
		<th rowspan="3"><?=GetMessage("TPL_PERIOD_CORRECTIONS")?></th>
		<th rowspan="3"><?=GetMessage("TPL_PERIOD_COMPENSATIONS")?></th>
		<?
		if ($arResult["HAS_PENALTIES"])
		{
			?>
			<th rowspan="3"><?=GetMessage("TPL_PERIOD_PENALTIES")?></th><?
		}
		?>
		<th colspan="3"><?=GetMessage("TPL_PERIOD_SUMM_TO_PAY")?></th>

		<th colspan="2" rowspan="2"><?=GetMessage("TPL_NORM")?></th>
		<th colspan="2" rowspan="2"><?=GetMessage("TPL_METERS_CURRENT")?></th>
		<th colspan="3" rowspan="2"><?=GetMessage("TPL_TOTAL_VOLUME")?></th>
	</tr>
	<tr>
		<th rowspan="2"><?=GetMessage("TPL_TOTAL")?></th>
		<th colspan="2"><?=GetMessage("TPL_FOR_SERVICE")?></th>
	</tr>
	<tr>
		<th><?=GetMessage("TPL_PERSONAL_CONS")?></th>
		<?
		if ($arResult["HAS_AMOUNT_NOTES"])
			echo '<th>*</th>';
		?>
		<th><?=GetMessage("TPL_SHARED_CONS")?></th>
		<?
		if ($arResult["HAS_AMOUNT_NOTES"])
			echo '<th>*</th>';
		?>
		<th><?=GetMessage("TPL_PERSONAL_CONS")?></th>
		<th><?=GetMessage("TPL_SHARED_CONS")?></th>
		<th><?=GetMessage("TPL_PERSONAL_CONS")?></th>
		<th><?=GetMessage("TPL_SHARED_CONS")?></th>

		<th><?=GetMessage("TPL_PERSONAL_CONS")?></th>
		<th><?=GetMessage("TPL_SHARED_CONS")?></th>
		<th><?=GetMessage("TPL_PERSONAL_CONS1")?></th>
		<th><?=GetMessage("TPL_SHARED_CONS1")?></th>
		<th><?=GetMessage("TPL_PERSONAL_CONS")?></th>
		<th><?=GetMessage("TPL_VOLUMEA")?></th>
		<th><?=GetMessage("TPL_SHARED_CONS")?></th>
	</tr>
	<tr class="rcpt-inner-table-num">
		<?
		for ($i = 1; $i <= $colsCount[0] - ($arResult["HAS_AMOUNT_NOTES"] ? 2 : 0); $i++)
		{
			?>
			<th<?=($arResult["HAS_AMOUNT_NOTES"] && ($i == 3 || $i == 4) ? ' colspan="2"' : '')?>><?=$i?></th>
			<?
		}
		for ($i = 1; $i <= $colsCount[1]; $i++)
		{
			?>
			<th><?=$i?></th><?
		}
		?>
	</tr>
	<?
	if ($printDebugInfo)
	{
		?>
		<tr class="debug">
			<?
			foreach ($sourceFields as $idx=>$group)
			{
				if ($idx !== 0)
				{
					?><td style="border: 0; background: none"></td><?
				}
				for ($i = 0; $i < count($group); $i++)
				{
					?>
					<td><?=$group[$i]?></td><?
				}
			}
			?>
		</tr>
	<?
	}

	/** @var int $tariffIndex ������� ������ ������ (������ ���������� � ������������ ������������� ������ �����������, ������� ������ ������� 1-� �����) */
	$tariffIndex = 0;
	foreach ($arResult['CHARGES'] as $idx => $arCharge)
	{
		$isComponent = $arCharge["COMPONENT"] == "Y";
		$tariffIndex = $isComponent ? $tariffIndex + 1 : 0;

		// ��� ����� ����������, �� ������� �����������, ����� ����� ������ �����
		if (!$isComponent && !$arCharge["HAS_COMPONENTS"])
			$tariffIndex = 1;

		$meterValue = $hMeterValue = false;
		if ($tariffIndex)
		{
			$decPlaces = -1;
			// ��������� ��������� �������������� ��������� �� �������� ������
			if ($arResult["HAS_CHARGES_METERS_BINDING"])
			{
				$meterValues = array();
				foreach ($arCharge["METER_IDS"] as $meterID)
				{
					$arMeter = $arResult["METERS"][$meterID];
					$meterValues[] = $arMeter["VALUE"]["VALUE" . $tariffIndex];
					$decPlaces = max($decPlaces, $arMeter["DEC_PLACES"]);
				}
				$meterValue = empty($meterValues) ? false : CCitrusTszhReceiptComponentHelper::num(array_sum($meterValues), false, $decPlaces <= 0 ? 2 : $decPlaces);
			}
			else
			{
				$meterValues = array();
				foreach ($arResult["METERS"] as $meterID => $arMeter)
				{
					if (trim($arMeter["~SERVICE_NAME"]) == trim($arCharge["~SERVICE_NAME"]))
					{
						$meterValues[] = $arMeter["VALUE"]["VALUE" . $tariffIndex];
						$decPlaces = max($decPlaces, $arMeter["DEC_PLACES"]);
					}
				}
				$meterValue = empty($meterValues) ? false : CCitrusTszhReceiptComponentHelper::num(array_sum($meterValues), false, $decPlaces <= 0 ? 2 : $decPlaces);
			}

			$decPlaces = -1;
			// ��������� ��������� ����������� ��������� �� �������� ������
			$hMeterValues = array();
			foreach ($arCharge["HMETER_IDS"] as $hMeterID)
			{
				$hMeter = $arResult["HMETERS"][$hMeterID];
				$hMeterValues[] = $hMeter["VALUE"]["VALUE" . $tariffIndex];
				$decPlaces = max($decPlaces, $hMeter["DEC_PLACES"]);
			}
			$hMeterValue = empty($hMeterValues) ? false : CCitrusTszhReceiptComponentHelper::num(array_sum($hMeterValues), false, $decPlaces <= 0 ? 2 : $decPlaces);
		}

		$arTariffs = array();
		if ($meterValuesCount > 1)
		{
			for ($i = 0; $i < $meterValuesCount; $i++)
			{
				$fieldName = "SERVICE_TARIFF";
				if ($i)
					$fieldName .= $i + 1;
				$arTariffs[] = $arCharge[$fieldName];
			}
		}

		if (in_array("TARIFF", $arCharge["X_FIELDS"]))
			$sTariffs = 'X';
		else
		{
			$arTariffs[0] = $arCharge["SERVICE_TARIFF"];
			$isAllZeros = true;
			foreach ($arTariffs as $key => $tariff)
			{
                // ������ �15646 (�� ��� ����������) � ������� �� �������� ���� �� ����� ������� �����
				$arTariffs[$key] = CCitrusTszhReceiptComponentHelper::num($tariff, false, -1);
				if ($tariff != 0)
					$isAllZeros = false;
			}
			if ($isComponent && $isAllZeros)
				$sTariffs = CCitrusTszhReceiptComponentHelper::num(0);
			else
				$sTariffs = implode(' / ', $arTariffs);
		}

		if ($arResult["HAS_GROUPS"] && ($idx == 0 || $arResult["CHARGES"][$idx-1]["GROUP"] != $arCharge["GROUP"]))
		{
			?>
			<tr class="rcpt-group-title">
				<td colspan="<?=($colsCount[0])?>">
					<?=$arCharge["GROUP"]?>
				</td>
				<td style="border: none"></td>
				<td colspan="<?=($colsCount[1])?>"></td>
			</tr>
			<?
		}
		?>
		<tr>
			<td><?=$arCharge['SERVICE_NAME']?><?=($arCharge["HAS_COMPONENTS"] ? ':' : '')?></td>
			<td class="center"><?=CCitrusTszhReceiptComponentHelper::getArrayValue(array('UNITS'), $arCharge, false, $arCharge["SERVICE_UNITS"])?></td>
			<td class="n"><?=CCitrusTszhReceiptComponentHelper::getArrayValue(array("AMOUNT", "HAMOUNT"), $arCharge, true, $arCharge['AMOUNT'] - $arCharge['HAMOUNT'], 3)?></td>
			<?
			if ($arResult["HAS_AMOUNT_NOTES"])
			{
				?><td class="center"><?=$arCharge["AMOUNTN"]?></td><?
			}
			?>
			<td class="n"><?=CCitrusTszhReceiptComponentHelper::getArrayValue('HAMOUNT', $arCharge, true, false, 3)?></td>
			<?
			if ($arResult["HAS_AMOUNT_NOTES"])
			{
				?><td class="center"><?=$arCharge["HAMOUNTN"]?></td><?
			}
			?>
			<td class="n"><?=$sTariffs?></td>
			<td class="n"><?=CCitrusTszhReceiptComponentHelper::getArrayValue(array("SUMM", "HSUMM"), $arCharge, true, $arCharge['SUMM'] - $arCharge["HSUMM"])?></td>
			<td class="n"><?=CCitrusTszhReceiptComponentHelper::getArrayValue('HSUMM', $arCharge, true)?></td>
			<td class="n"><?=CCitrusTszhReceiptComponentHelper::getArrayValue('SUMM', $arCharge, true)?></td>
			<td class="n"><?=CCitrusTszhReceiptComponentHelper::getArrayValue('CORRECTION', $arCharge, true)?></td>
			<td class="n"><?=CCitrusTszhReceiptComponentHelper::getArrayValue('COMPENSATION', $arCharge, true)?></td>
			<?
			if ($arResult['HAS_PENALTIES'])
			{
				?>
				<td class="n"><?=CCitrusTszhReceiptComponentHelper::getArrayValue('PENALTIES', $arCharge, true)?></td><?
			}
			?>
			<td class="n"><?=CCitrusTszhReceiptComponentHelper::getArrayValue('SUMM2PAY', $arCharge, true)?></td>
			<td class="n"><?=CCitrusTszhReceiptComponentHelper::getArrayValue(array("SUMM2PAY", "HSUMM2PAY"), $arCharge, true, $arCharge['SUMM2PAY'] - $arCharge["HSUMM2PAY"])?></td>
			<td class="n"><?=CCitrusTszhReceiptComponentHelper::getArrayValue("HSUMM2PAY", $arCharge, true)?></td>

			<td style="border: none<?=($idx == count($arResult["CHARGES"])-1 ? '; border-bottom: 1px solid #fff;' : '')?>">&nbsp;&nbsp;</td>

			<td class="n"><?=CCitrusTszhReceiptComponentHelper::getArrayValue(array("NORM", "HNORM"), $arCharge, true, $arCharge["SERVICE_NORM"] - $arCharge["HNORM"], 3)?></td>
			<td class="n"><?=CCitrusTszhReceiptComponentHelper::getArrayValue("HNORM", $arCharge, true, false, 3)?></td>

			<td class="n" style="white-space: nowrap;"><?=$meterValue?></td>
			<td class="n"><?=$hMeterValue?></td>

			<td class="n"><?=CCitrusTszhReceiptComponentHelper::getArrayValue("VOLUMEP", $arCharge, true, false, 3)?></td>
			<td class="n"><?=CCitrusTszhReceiptComponentHelper::getArrayValue("VOLUMEA", $arCharge, true, false, 3)?></td>
			<td class="n"><?=CCitrusTszhReceiptComponentHelper::getArrayValue("VOLUMEH", $arCharge, true, false, 3)?></td>
		</tr>
	<?
	}

	$firstCols = $arResult["HAS_AMOUNT_NOTES"] ? 7 : 5;
	?>
	<tr class="rcpt-inner-table-footer">
		<td colspan="<?=$firstCols?>"><?=GetMessage("TPL_PERIOD_TOTAL_TO_PAY")?></td>
		<td class="n"><?=CCitrusTszhReceiptComponentHelper::num($arResult["TOTALS"]["_SUMM"])?></td>
		<td class="n"><?=CCitrusTszhReceiptComponentHelper::num($arResult["TOTALS"]["HSUMM"])?></td>
		<td class="n"><?=CCitrusTszhReceiptComponentHelper::num($arResult["TOTALS"]["SUMM"])?></td>
		<td class="n"><?=CCitrusTszhReceiptComponentHelper::num($arResult["TOTALS"]["CORRECTION"])?></td>
		<td class="n"><?=CCitrusTszhReceiptComponentHelper::num($arResult["TOTALS"]["COMPENSATION"])?></td>
		<?if ($arResult["HAS_PENALTIES"]):?>
			<td class="n"><?=CCitrusTszhReceiptComponentHelper::num($arResult["TOTALS"]["PENALTIES"])?></td>
		<?endif?>
		<td class="n"><?=CCitrusTszhReceiptComponentHelper::num($arResult["TOTALS"]["SUMM2PAY"])?></td>
		<td colspan="<?=(array_sum($colsCount)-6-$firstCols)?>" style="border: none;"></td>
	</tr>
</table>
