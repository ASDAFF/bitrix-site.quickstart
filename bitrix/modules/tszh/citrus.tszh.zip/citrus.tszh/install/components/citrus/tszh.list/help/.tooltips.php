<?
$arTooltips = array(
	"IBLOCK_TYPE" => GetMessage("IBLOCK_TYPE_TIP"),
	"IBLOCKS" => GetMessage("IBLOCKS_TIP"),
	"NEWS_COUNT" => GetMessage("NEWS_COUNT_TIP"),
	"SORT_BY1" => GetMessage("SORT_BY1_TIP"),
	"SORT_ORDER1" => GetMessage("SORT_ORDER1_TIP"),
	"SORT_BY2" => GetMessage("SORT_BY2_TIP"),
	"SORT_ORDER2" => GetMessage("SORT_ORDER2_TIP"),
	"DETAIL_URL" => GetMessage("DETAIL_URL_TIP"),
	"ACTIVE_DATE_FORMAT" => GetMessage("ACTIVE_DATE_FORMAT_TIP"),
	"CACHE_TYPE" => GetMessage("CACHE_TYPE_TIP"),
	"CACHE_TIME" => GetMessage("CACHE_TIME_TIP"),
);
?>