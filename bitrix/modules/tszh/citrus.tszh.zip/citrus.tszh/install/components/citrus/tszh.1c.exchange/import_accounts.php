<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

/** @var CCitrusTszh1cExchange $this */

if (!CModule::IncludeModule("citrus.tszh"))
	throw new Exception(GetMessage("TSZH_1C_ERROR_MODULE"));

if (!CModule::IncludeModule("iblock"))
	throw new Exception(GetMessage("TSZH_1C_ERROR_IBLOCK_MODULE"));

$arTszh = $this->getOrg();
if (!is_array($arTszh) || IntVal($arTszh["ID"]) <= 0)
	throw new Exception(GetMessage("TSZH_1C_ERROR_ORG_NOT_FOUND"));

$start_time = time();

$ABS_FILE_NAME = $this->getUploadedFile();

$NS = &$_SESSION["BX_CITRUS_TSZH_IMPORT"];
if (!is_array($NS))
{
	$NS = array(
		"STEP" => 0,
		"TSZH" => $arTszh['ID'],

		"ONLY_DEBT" => COption::GetOptionString('citrus.tszh', '1c_exchange.UpdateMode', "Y") == "D",
		"UPDATE_MODE" => COption::GetOptionString('citrus.tszh', '1c_exchange.UpdateMode', "Y") == "Y",
		"CREATE_USERS" => COption::GetOptionString('citrus.tszh', '1c_exchange.CreateUsers', "Y") == "Y",
		//"UPDATE_USERS" => COption::GetOptionString('citrus.tszh', '1c_exchange.UpdateUsers', "N") != "N",
		"ACTION" => COption::GetOptionString('citrus.tszh', '1c_exchange.Action', "A"),
		"DEPERSONALIZE" => COption::GetOptionString('citrus.tszh', '1c_exchange.Depersonalize', "N") == "Y",
	);
}

$obXMLFile = new CIBlockXMLFile();

$progress = array();
$finished = false;
do
{
	if ($NS["STEP"] < 1)
	{
		$_SESSION["TSZH_IMPORT"] = array(
			"SERVICES" => Array(),
		);

		CIBlockXMLFile::DropTemporaryTables();
		$NS["STEP"]++;

		$progress[] = GetMessage("TI_STEP1_DONE");
	}
	elseif ($NS["STEP"] < 2)
	{
		if (CIBlockXMLFile::CreateTemporaryTables())
			$NS["STEP"]++;
		else
			throw new Exception(GetMessage("TI_ERROR_STEP2"));

		$progress[] = GetMessage("TI_STEP2_DONE");
	}
	elseif ($NS["STEP"] < 3)
	{
		if (file_exists($ABS_FILE_NAME) && is_file($ABS_FILE_NAME) && ($fp = fopen($ABS_FILE_NAME, "rb")))
		{
			if ($obXMLFile->ReadXMLToDatabase($fp, $NS, $this->interval))
				$NS["STEP"]++;
			fclose($fp);
		}
		else
		{
			throw new Exception(GetMessage("TI_STEP3_ERROR"));
		}

		$file_size = file_exists($ABS_FILE_NAME) && is_file($ABS_FILE_NAME) ? filesize($ABS_FILE_NAME) : 0;
		$progress[] = GetMessage("TI_STEP3_PROGRESS", Array('#PROGRESS#' => ($file_size > 0 ? round($obXMLFile->GetFilePosition() / $file_size * 100, 2) : 0)));
	}
	elseif ($NS["STEP"] < 4)
	{
		if (CIBlockXMLFile::IndexTemporaryTables())
			$NS["STEP"]++;
		else
			throw new Exception(GetMessage("TI_STEP4_ERROR"));

		$progress[] = GetMessage("TI_STEP4_DONE");
	}
	elseif ($NS["STEP"] < 5)
	{
		$obImport = new CTszhImport;
		$obImport->Init($NS);
		$result = $obImport->ProcessPeriod();
		$obImport->ImportServices();
		if ($result === true)
		{
			$NS['ACCOUNTS_IMPORT_STARTED'] = time();
			$NS["STEP"]++;
		}
		else
		{
			if ($ex = $APPLICATION->GetException())
			{
				throw new Exception(GetMessage("TI_STEP5_ERROR") . ": " . $ex->GetString());
			}
			else
			{
				throw new Exception(GetMessage("TI_STEP5_ERROR"));
			}
		}

		$progress[] = GetMessage("TI_STEP5_DONE");
	}
	elseif ($NS["STEP"] < 6)
	{
		$obImport = new CTszhImport;
		$obImport->Init($NS);
		$result = $obImport->ImportAccounts($start_time, $this->interval);

		$counter = 0;
		foreach ($result as $key => $value)
		{
			$NS["DONE"][$key] += $value;
			$counter += $value;
		}

		if (!$counter)
		{
			$progress[] = GetMessage("TI_STEP6_DONE");
			$NS["STEP"]++;
		}
		else
			$progress[] = GetMessage("TI_STEP6_PROGRESS", Array('#CNT#' => intval($NS["DONE"]["ADD"] + $NS["DONE"]["UPD"] + $NS["DONE"]["ERR"]), '#TOTAL#' => intval($NS["DONE"]["ALL"])));
	}
	elseif ($NS["STEP"] < 7)
	{

		$obImport = new CTszhImport;
		$obImport->Init($NS);
		$result = $obImport->Cleanup($NS["ACTION"], $start_time, $this->interval);

		$counter = 0;
		foreach ($result as $key => $value)
		{
			$NS["DONE"][$key] += $value;
			$counter += $value;
		}

		if (!$counter)
		{
			$NS["STEP"]++;
			$progress[] = GetMessage("TI_STEP7_DONE");
		}
		else
			$progress[] = GetMessage("TI_STEP7_PROGRESS", Array('#CNT#' => intval($NS["DONE"]["DEL"]) + intval($NS["DONE"]["METER_DEL"]) + intval($NS["DONE"]["DEA"]) + intval($NS["DONE"]["METER_DEA"])));
	}
	elseif ($NS["STEP"] < 8)
	{
		if (!$this->debug)
			@unlink($ABS_FILE_NAME);

		if (CTszh::hasDemoAccounts($NS["TSZH"], $arDemoAccounts))
		{
			$res = false;
			foreach ($arDemoAccounts as $accountID => $arAccount)
			{
				$res = CTszhAccount::delete($accountID);
			}
			if ($res)
				$progress[] = getMessage("TI_STEP8_PROGRESS");
		}

		$NS["STEP"]++;

		$strErrors = CTszhImport::GetErrors();
		if (strlen($strErrors) > 0)
		{
			echo "warning\n" . $strErrors;
			$this->textOutput = true;

			return;
		}

		echo "success\n" . GetMessage("TI_STEP8_DONE");
		if ($this->debug)
			$this->logMessage("�������� ������� ���������\n" . implode("\n", $progress));
		$finished = true;
		break;
	}
	else
	{
		throw new Exception(GetMessage("TI_ERROR_ALREADY_FINISHED"));
	}
} while ($this->interval > 0 && (time()-$start_time) < $this->interval);

if ($finished)
{
	if ($this->debug)
		$this->logMessage("�������� ������� ���������");
}
else
	echo "progress\n" . implode(', ', $progress);

$this->textOutput = true;
	
