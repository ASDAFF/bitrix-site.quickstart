<?
$MESS ['SUPPORT_FAQ_GO_UP'] = "Up";
?>