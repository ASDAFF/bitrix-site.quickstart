<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

if (!CModule::IncludeModule('citrus.tszh'))
{
	ShowError(GetMessage("TSZH_MODULE_NOT_FOUND_ERROR"));
	return;
}

if (!CTszhFunctionalityController::CheckEdition())
	return;

if (strlen($arParams["REGCODE_PROPERTY"]) <= 0) {
	$arParams["REGCODE_PROPERTY"] = "UF_REGCODE";
}
$arParams['PERSONAL_PATH'] = trim($arParams['PERSONAL_PATH']);
if (strlen($arParams["PERSONAL_PATH"]) <= 0)
	$arParams['PERSONAL_PATH'] = "#SITE_DIR#personal/";
$arParams['PERSONAL_PATH'] = str_replace("#SITE_DIR#", SITE_DIR, $arParams['PERSONAL_PATH']);

$arResult = Array();
$arErrors = Array();

if (!$USER->IsAuthorized()) {
	$APPLICATION->AuthForm(GetMessage("ACCESS_DENIED"));
	return;
}

$arResult["TSZH_LIST"] = Array();
$rsTszh = CTszh::GetList(
	Array("NAME"=>"DESC"),
	Array(),
	false, //mixed arGroupBy = false
	false, //mixed arNavStartParams = false
	Array("ID", "NAME") //array arSelectFields = Array());
);
while ($arTszh = $rsTszh->GetNext()) {
	$arResult["TSZH_LIST"][$arTszh["ID"]] = $arTszh;
}

if (count($arResult["TSZH_LIST"]) <= 0) {
	ShowError(GetMessage("TSZH_NO_TSZHS"));
	return;
}

$arResult['ACCOUNT'] = CTszhAccount::GetByUserID($GLOBALS["USER"]->GetID());

if (class_exists('CCitrusJkhOrg'))
{
	$arTszh = CCitrusJkhOrg::getCurrent();
	$tszhCode = $arTszh['CODE'];

	$dbGroup = CGroup::GetList($by = "", $order = "", Array("STRING_ID" => "jkh_users_" . $tszhCode));
	if ($arGroup = $dbGroup->Fetch())
		$groupID = $arGroup['ID'];
	else
		$groupID = false;
}
else
	$groupID = false;

if ($_SERVER["REQUEST_METHOD"] == 'POST' && $_POST['action'] == 'confirm' && check_bitrix_sessid()) {

	$arResult["TSZH"] = IntVal($_REQUEST['tszh']);
	$arResult["REG_CODE"] = htmlspecialcharsbx(trim($_REQUEST['regcode']));
	if ($arResult["TSZH"] <= 0 || !array_key_exists($arResult["TSZH"], $arResult["TSZH_LIST"])) {
		$arErrors[] = GetMessage("ERROR_TSZH_NOT_SELECTED");
	}
	if (strlen($arResult["REG_CODE"]) <= 0) {
		$arErrors[] = GetMessage("ERROR_REGCODE_EMPTY");
	}
	if (CTszh::IsTenant() && is_array($arResult['ACCOUNT'])) {
		$arErrors[] = GetMessage("TSZH_ALREADY_CONFIRMED");
	}
	if (!$APPLICATION->CaptchaCheckCode($_REQUEST["captcha_word"], $_REQUEST["captcha_sid"])) {
		$arErrors[] = GetMessage("TSZH_WRONG_CAPTCHA");
	}

	if (count($arErrors) <= 0) {
		$arFilter = Array(
			'TSZH_ID'  => $arResult["TSZH"],
			'=' . $arParams["REGCODE_PROPERTY"] => $arResult["REG_CODE"],
		);
		$rsAccount = CTszhAccount::GetList(Array(), $arFilter);
		if ($arAccount = $rsAccount->Fetch()) {

			if (IntVal($arAccount["USER_ID"]) > 0 && is_array(CUser::GetByID($arAccount["USER_ID"])->Fetch())) {
				$arErrors[] = GetMessage("TSZH_ACCOUNT_ALREADY_CONFIRMED");
			} else {
				define("TSZH_CANCEL_REDIRECT", true);
				if (CTszhAccount::Update($arAccount["ID"], Array("USER_ID" => $GLOBALS["USER"]->GetID())))
				{
					$userID = $GLOBALS["USER"]->GetID();
					$arGroups = array_unique(array_merge(
						CUser::GetUserGroup($userID),
						Array(
							CTszh::GetTenantGroup()
						),
						false !== $groupID ? Array($groupID) : Array()
					));
					CUser::SetUserGroup($userID, $arGroups);
					$GLOBALS['USER']->Logout();
					$GLOBALS['USER']->Authorize($userID);
					$arResult["NOTE"] = GetMessage("CONFIRM_ACCOUNT_SUCCESS");
					$arResult["ACCOUNT"] = $arAccount;
				} else {
					$arErrors[] = GetMessage("ERROR_SAVING_ACCOUNT");
				}
			}

		} else {
			$arErrors[] = GetMessage("ERROR_WRONG_CODE");
		}
	}
}

$arResult["CAPTCHA_CODE"] = htmlspecialcharsbx($APPLICATION->CaptchaGetCode());

if (count($arErrors) > 0) {
	$arResult["ERRORS"] = implode('<br />', $arErrors);
}

$this->IncludeComponentTemplate();
?>