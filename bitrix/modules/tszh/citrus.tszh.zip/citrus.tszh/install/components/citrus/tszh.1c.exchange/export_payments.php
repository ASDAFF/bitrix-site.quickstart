<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

/** @var CCitrusTszh1cExchange $this */

if (!CModule::IncludeModule("citrus.tszhpayment"))
	throw new Exception(GetMessage("TSZH_1C_ERROR_PAYMENT_MODULE"));

$arTszh = $this->getOrg();
if (!is_array($arTszh) || IntVal($arTszh["ID"]) <= 0)
	throw new Exception(GetMessage("TSZH_1C_ERROR_ORG_NOT_FOUND"));

$filename = "/upload/tszh_exchange/tmp_payments_export_" . date('Y-m-d_Hms') . ".xml";
$absFilename = $_SERVER['DOCUMENT_ROOT'] . $filename;
CheckDirPath($absFilename);

$type = 'payments';
COption::SetOptionString("citrus.tszh", "last_{$type}_export_time_".$arOrg['ID'], time());

$arFilter = Array(
	"TSZH_ID" => $arTszh['ID'],
	"PAYED" => "Y",
);
if ($dateFrom = $this->dateFrom())
	$arFilter[">DATE_PAYED"] = $dateFrom;
if ($dateTo = $this->dateTo())
	$arFilter["<=DATE_PAYED"] = $dateTo;

$NS = Array(
	"filename" => $filename,
	"stepTime" => 0,
	"tszh" => $arTszh,
);
CTszhPaymentsExport::ProcessExport($arFilter, 0, $NS);

echo file_get_contents($absFilename);
unlink($absFilename);
$this->xmlOutput = true;
