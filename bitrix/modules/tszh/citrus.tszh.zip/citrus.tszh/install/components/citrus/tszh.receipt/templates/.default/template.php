<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

global $APPLICATION, $DB;
if ($_GET["print"] == "Y")
	$APPLICATION->RestartBuffer();

if (!function_exists("__citrusReceiptNum"))
{
	function __citrusReceiptNum($number, $decimals=2, $isComponent=false) 
	{
		if ($number == 0) 
		{
			if ($isComponent)
				return '<div style="text-align: center;">X</div>';

			return '0';
		}
		return number_format($number, $decimals, ',', ' ');
	}
}

if (!function_exists("__citrusReceiptGetMeterAmount"))
{
	function __citrusReceiptGetMeterAmount($amount, $curValue, $prevValue, $capacity, $decPlaces)
	{
		if (strlen($amount) > 0)
		{
			$result = $amount;
		}
		else
		{
			$curValue = floatval($curValue);
			$prevValue = floatval($prevValue);
			if ($curValue >= $prevValue)
				$result = $curValue - $prevValue;
			else
			{
				$rate = intval($capacity) - intval($decPlaces);
				if ($rate > 0)
					$result = $curValue + pow(10, $rate) - $prevValue;
				else
					$result = 0;
			}
		}

		return $result;
	}
}

if ($_GET["print"] != "Y") 
{
	$APPLICATION->AddHeadString('<link href="' . $this->GetFolder() . '/styles.css" rel="stylesheet" type="text/css" />');
?>
<p><?=GetMessage("RCPT_YOU_CAN")?> <a href="<?=$APPLICATION->GetCurPageParam('print=Y', Array('print'))?>" target="_blank"><?=GetMessage("RCPT_OPEN_RECEIPT_IN_WINDOW")?></a> <?=GetMessage("RCPT_FOR_PRINTING")?></p>
<?

}
else 
{
	if ($arResult["IS_FIRST"]):
		if ($arResult["MODE"] == "AGENT"):?>
			<style type="text/css">
				<?=$APPLICATION->GetFileContent($_SERVER["DOCUMENT_ROOT"] . $this->GetFolder() . "/styles.css")?>
			</style>
		<?else:
			?><!DOCTYPE html>
			<html>
			<head>
				<meta http-equiv="content-type" content="text/html; charset=<?=SITE_CHARSET?>" />
				<link href="<?=$this->GetFolder()?>/styles.css" rel="stylesheet" type="text/css" />
		<?endif?>
		<style type="text/css" media="print">
			@page {
				size: 21cm 29.7cm;
				margin: 2.5cm 2cm;
			}
			<?if ($arParams["INLINE"] != "Y"):?>
				#receipt div.receipt {
					page-break-after: always;
					page-break-inside: avoid;
				}
			<?endif?>
		</style>
		<?if ($arResult["MODE"] == "ADMIN"):?>
			<style type="text/css" media="screen">
				#receipt div.receipt {
					border-bottom: 1pt dashed #000;
				}
			</style>
		<?endif;

		if ($arResult["MODE"] == "AGENT"):?>
			<div id="receipt">
		<?else:?>
				<title><?=GetMessage("RCPT_TITLE")?></title>
			</head>
			<body id="receipt" onload="window.print();">
		<?endif;
	endif;
}

?>
<div class="receipt">
<table class="no-border">
<tr>
	<td style="width: 41%;" class="tl">
		<?=GetMessage("RCPT_NOTICE")?><br />
		<strong><?=GetMessage("RCPT_FOR")?> <?=$arResult['ACCOUNT_PERIOD']['DISPLAY_NAME']?> <?=GetMessage("RCPT_YEAR_ABBR")?></strong>
	</td>
	<td class="bl">
		<strong><?=$arResult['ACCOUNT_PERIOD']['ACCOUNT_NAME']?></strong>
		<div align="right" style="font-weight: bold;"><?=GetMessage("RCPT_ACCOUNT_ABBR")?> <?=$arResult['ACCOUNT_PERIOD']['XML_ID']?></div>
		<div><?=CTszhAccount::GetFullAddress($arResult['ACCOUNT_PERIOD'])?></div>
	</td>
</tr>
<tr>
	<td>&nbsp;</td>
	<td class="bt bl small">
		<?=$arResult['ORG_TITLE']?><br />
		<span style="white-space: nowrap;"><?=GetMessage("RCPT_INN")?> <?=$arResult['ORG_INN']?> / <?=GetMessage("RCPT_KPP")?>&nbsp;<?=$arResult['ORG_KPP']?></span>
		<br />
		<span style="white-space: nowrap;"><?=GetMessage("RCPT_RSCH")?> <?=$arResult['ORG_RSCH']?>, <?=GetMessage("RCPT_IN")?>&nbsp;<?=$arResult['ORG_BANK']?></span>,
		<span style="white-space: nowrap;"><?=GetMessage("RCPT_KSCH")?> <?=$arResult['ORG_KSCH']?></span>,
		<span style="white-space: nowrap;"><?=GetMessage("RCPT_BIK")?> <?=$arResult['ORG_BIK']?></span>
		<br />
		<div style="margin: 1.5pt 0 2pt 0;" align="right"><br /></div>
	</td>
</tr>
<tr>
	<td>&nbsp;</td>
	<td class="bl">
		<strong style="display: block; float: left;"><?=GetMessage("RCPT_SUMM_TO_PAY"/*$arResult['SUM2PAY'] > 0 ? "RCPT_DEBT_END" : "RCPT_CREDIT_END"*/)?></strong>
		<span style="margin-left: 10pt; font-weight: bold;">
			<?=__citrusReceiptNum(abs($arResult['SUM2PAY']))?>
		</span>
	</td>
</tr>
<tr>
	<td style="vertical-align: middle;" class="tl">
		<?=GetMessage("RCPT_CASHIER")?>
	</td>
	<td style="padding-left: 30pt;" class="bl">
		<?if (!empty($arResult["ACCOUNT_PERIOD"]["BARCODES"])):?>
			<table border="0">
				<tr>
					<?foreach ($arResult["ACCOUNT_PERIOD"]["BARCODES"] as $idx=>$barcode)
					{
						if ($link = CTszhBarCode::getImageLink($barcode))
						{
							$code128 = $barcode["TYPE"] == 'code128';
							?><td class="no-border rcpt-barcode-cell"><img style="<?=($code128 ? 'width: 5.5cm' : 'width: 3cm; height: 3cm; max-height: 4cm;')?>" class="rcpt-barcode" src="<?=$link?>" alt="<?=htmlspecialcharsbx($barcode["VALUE"])?>"></td><?
						}
					}?>
				</tr>
			</table>
		<?endif?>
	</td>
</tr>
<tr>
	<td class="bb tl"></td>
	<td class="bl bb"><?

	if ($arResult['METERS_LAST_UPDATE'])
	{
		$sDateFormat = CSite::GetDateFormat("FULL");
		$sNewDateFormat = 'DD/MM/YYYY';
		$sMetersUpdateDate = $DB->FormatDate($arResult['METERS_LAST_UPDATE'], $sDateFormat, $sNewDateFormat);
		$sMetersUpdateDate = str_replace('/', '&nbsp;&nbsp;/&nbsp;&nbsp;', $sMetersUpdateDate);
	}
	else
	{
		$sMetersUpdateDate = '&mdash;';
	}

	?>
		<?=GetMessage("RCPT_METER_VALUES_ON_DATE")?>&nbsp;&nbsp;&nbsp;<?=$sMetersUpdateDate?>&nbsp;&nbsp;
		<table class="border" style="font-size: 90%"><?

		foreach ($arResult['METERS'] as $arMeter):

		?>
		<tr>
			<td style="white-space: nowrap;"><?=strlen($arMeter['SERVICE_NAME']) > 0 ? $arMeter['SERVICE_NAME'] : $arMeter['NAME']?></td>
			<td style="width: 15%;white-space: nowrap;" class="num"><?=__citrusReceiptNum($arMeter['VALUE_BEFORE']['VALUE1'])?></td>
			<td style="width: 15%;white-space: nowrap;" class="num"><?=__citrusReceiptNum($arMeter['VALUE']['VALUE1'])?></td>
			<td style="width: 15%;white-space: nowrap;" class="num"><?=__citrusReceiptNum($arMeter['VALUE_BEFORE']['VALUE2'])?></td>
			<td style="width: 15%;white-space: nowrap;" class="num"><?=__citrusReceiptNum($arMeter['VALUE']['VALUE2'])?></td>
		</tr><?

		endforeach;

		?>

		</table>
	</td>
</tr>
<tr>
	<td style="padding-top: 20pt;" class="tl">
		<?=GetMessage("RCPT_CHECK")?><br />
		<strong><?=GetMessage("RCPT_FOR")?> <?=$arResult['ACCOUNT_PERIOD']['DISPLAY_NAME']?> <?=GetMessage("RCPT_YEAR_ABBR")?></strong>
	</td>
	<td class="bl" style="padding-top: 7pt;">
		<strong><?=$arResult['ACCOUNT_PERIOD']['ACCOUNT_NAME']?></strong>
		<div align="right" style="font-weight: bold;"><?=GetMessage("RCPT_ACCOUNT_ABBR")?> <?=$arResult['ACCOUNT_PERIOD']['XML_ID']?></div>
		<div><?=CTszhAccount::GetFullAddress($arResult['ACCOUNT_PERIOD'])?></div>
	</td>
</tr>
<tr>
	<td>&nbsp;</td>
	<td class="bt bl small" style="padding-top: 1pt; padding-bottom: 8pt;">
		<?=$arResult['ORG_TITLE']?><br />
		<span style="white-space: nowrap;"><?=GetMessage("RCPT_INN")?> <?=$arResult['ORG_INN']?> / <?=GetMessage("RCPT_KPP")?>&nbsp;<?=$arResult['ORG_KPP']?></span>
		<br />
		<span style="white-space: nowrap;"><?=GetMessage("RCPT_RSCH")?> <?=$arResult['ORG_RSCH']?>, <?=GetMessage("RCPT_IN")?>&nbsp;<?=$arResult['ORG_BANK']?></span>,
		<span style="white-space: nowrap;"><?=GetMessage("RCPT_KSCH")?> <?=$arResult['ORG_KSCH']?></span>,
		<span style="white-space: nowrap;"><?=GetMessage("RCPT_BIK")?> <?=$arResult['ORG_BIK']?></span>
		<br />
	</td>
</tr>
<tr>
	<td colspan="2" class="bt small tl" style="padding-top: 7pt;">
		<div style="margin-left: 2pt; line-height: 140%;">
			<?=str_replace("#PEOPLE#", $arResult['ACCOUNT_PERIOD']['PEOPLE'], GetMessage("RCPT_PEOPLE_LIVING"))?>
			<?=str_replace("#AREA#", __citrusReceiptNum($arResult['ACCOUNT_PERIOD']['AREA']), GetMessage("RCPT_AREA"))?>
			<?=str_replace("#AREA#", __citrusReceiptNum($arResult['ACCOUNT_PERIOD']['LIVING_AREA']), GetMessage("RCPT_LIVING_AREA"))?>
			<br />
			<?=str_replace("#DATE#", $sMetersUpdateDate, GetMessage("RCPT_METER_VALUES_ON"))?>
		</div>
		<table class="border counters" style="width: 86%; margin-top: 2pt; font-size: 90%;">
			<thead><tr>
				<td><?=GetMessage("RCPT_SERVICE")?></td>
				<td colspan="2" class="bt bl"><?=GetMessage("RCPT_METER_VALUE_1")?></td>
				<td class="bt"><?=GetMessage("RCPT_CONSUMPTION")?></td>
				<td colspan="2" class="bt"><?=GetMessage("RCPT_METER_VALUE_2")?></td>
				<td class="bt br"><?=GetMessage("RCPT_CONSUMPTION")?></td>
			</tr></thead>
			<tbody><?


			$lastKey = array_pop(array_keys($arResult['METERS']));

			foreach ($arResult['METERS'] as $key=>$arMeter) {

				$bef1 = $arMeter['VALUE_BEFORE']['VALUE1'];
				$cur1 = $arMeter['VALUE']['VALUE1'];
				$bef2 = $arMeter['VALUE_BEFORE']['VALUE2'];
				$cur2 = $arMeter['VALUE']['VALUE2'];

				$rash1 = __citrusReceiptGetMeterAmount($arMeter["VALUE"]["AMOUNT1"], $cur1, $bef1, $arMeter["CAPACITY"], $arMeter["DEC_PLACES"]);
				$rash2 = __citrusReceiptGetMeterAmount($arMeter["VALUE"]["AMOUNT2"], $cur2, $bef2, $arMeter["CAPACITY"], $arMeter["DEC_PLACES"]);
			?>
				<tr>
					<td style="white-space: nowrap;"><?=strlen($arMeter['SERVICE_NAME']) > 0 ? $arMeter['SERVICE_NAME'] : $arMeter['NAME']?></td>
					<td class="num bl <?=$key==$lastKey?' bb':''?>"><?=__citrusReceiptNum($bef1)?></td>
					<td class="num <?=$key==$lastKey?' bb':''?>"><?=__citrusReceiptNum($cur1)?></td>
					<td class="num <?=$key==$lastKey?' bb':''?>"><?=__citrusReceiptNum($rash1)?></td>
					<td class="num <?=$key==$lastKey?' bb':''?>"><?=__citrusReceiptNum($bef2)?></td>
					<td class="num <?=$key==$lastKey?' bb':''?>"><?=__citrusReceiptNum($cur2)?></td>
					<td class="num br <?=$key==$lastKey?' bb':''?>"><?=__citrusReceiptNum($rash2)?></td>
				</tr>
			<?
			}	
			?>
			</tbody>
		</table>
		<div style="font-weight: bold; text-align: right; margin: 6pt 0;">
			<?if ($arResult['ACCOUNT_PERIOD']['DEBT_BEG'] > 0):?>
			<?=GetMessage("RCPT_CREDIT_BEG")?> <?=__citrusReceiptNum($arResult['ACCOUNT_PERIOD']['DEBT_BEG'])?> <?=GetMessage("RCPT_CURRENCY")?>
			<?else:?>
			<?=GetMessage("RCPT_DEBT_BEG")?> <?=__citrusReceiptNum(-$arResult['ACCOUNT_PERIOD']['DEBT_BEG'])?> <?=GetMessage("RCPT_CURRENCY")?>
			<?endif;?>
		</div>

		<table class="border services">
			<thead>
				<tr>
					<td style="width: 37%;"><?=GetMessage("RCPT_CHARGED")?></td>
					<td><?=GetMessage("RCPT_UNITS")?></td>
					<td><?=GetMessage("RCPT_NORM")?></td>
					<td><?=GetMessage("RCPT_TARIFF")?></td>
					<td><?=GetMessage("RCPT_QUANTITY")?></td>
					<td><?=GetMessage("RCPT_CHARGED2")?></td>
					<td><?=GetMessage("RCPT_CORRECTION")?></td>
					<td><?=GetMessage("RCPT_PRIVIL")?></td>
					<td><?=GetMessage("RCPT_PENI")?></td>
					<td><?=GetMessage("RCPT_TO_PAY")?></td>
				</tr>
			</thead>
			<tbody>
				<?foreach ($arResult['CHARGES'] as $idx => $arCharge):

					$isComponent = $arCharge["COMPONENT"] == "Y";

					$arTariffs = array();
					if ($meterValuesCount > 1)
					{
						for ($i = 0; $i < $meterValuesCount; $i++)
						{
							$fieldName = "SERVICE_TARIFF";
							if ($i)
								$fieldName .= $i + 1;
							$arTariffs[] = $arCharge[$fieldName];
						}
					}
	            
					if (in_array("TARIFF", $arCharge["X_FIELDS"]))
						$sTariffs = 'X';
					else
					{
						$arTariffs[0] = $arCharge["SERVICE_TARIFF"];
						$isAllZeros = true;
						foreach ($arTariffs as $key => $tariff)
						{
							$arTariffs[$key] = CCitrusTszhReceiptComponentHelper::num($tariff);
							if ($tariff != 0)
								$isAllZeros = false;
						}
						if ($isComponent && $isAllZeros)
							$sTariffs = CCitrusTszhReceiptComponentHelper::num(0);
						else
							$sTariffs = implode(' / ', $arTariffs);
					}
					                
					if ($arResult["HAS_GROUPS"] && ($idx == 0 || $arResult["CHARGES"][$idx-1]["GROUP"] != $arCharge["GROUP"])):?>
						<tr class="rcpt-group-title">
							<td colspan="10">
								<?=$arCharge["GROUP"]?>
							</td>
						</tr>
					<?endif?>
					<tr>
						<td><?=$arCharge['SERVICE_NAME']?><?=($arCharge["HAS_COMPONENTS"] ? ':' : '')?></td>
						<td class="center"><?=CCitrusTszhReceiptComponentHelper::getArrayValue(array("UNITS"), $arCharge, false, $arCharge["SERVICE_UNITS"])?></td>
						<td class="num"><?=CCitrusTszhReceiptComponentHelper::getArrayValue(array("NORM"), $arCharge, true, $arCharge["SERVICE_NORM"], 3)?></td>
						<td class="num"><?=$sTariffs?></td>
						<td class="num"><?=CCitrusTszhReceiptComponentHelper::getArrayValue("AMOUNT", $arCharge, true, false, 3)?></td>
						<td class="num"><?=CCitrusTszhReceiptComponentHelper::getArrayValue("SUMM", $arCharge, true)?></td>
						<td class="num"><?=CCitrusTszhReceiptComponentHelper::getArrayValue("CORRECTION", $arCharge, true)?></td>
						<td class="num"><?=CCitrusTszhReceiptComponentHelper::getArrayValue("COMPENSATION", $arCharge, true)?></td>
						<td class="num"><?=CCitrusTszhReceiptComponentHelper::getArrayValue("PENALTIES", $arCharge, true)?></td>
						<td class="num"><?=CCitrusTszhReceiptComponentHelper::getArrayValue("SUMM2PAY", $arCharge, true)?></td>
					</tr>
				<?endforeach?>
			</tbody>
			<tfoot>
				<tr>
					<td style="text-align: right;"><strong><?=GetMessage("RCPT_TOTAL_CHARGED")?></strong></td>
					<td class="center">&nbsp;</td>
					<td class="num">&nbsp;</td>
					<td class="num">&nbsp;</td>
					<td class="num">&nbsp;</td>
					<td class="num"><?=CCitrusTszhReceiptComponentHelper::num($arResult["TOTALS"]["SUMM"])?></td>
					<td class="num"><?=CCitrusTszhReceiptComponentHelper::num($arResult["TOTALS"]["CORRECTION"])?></td>
					<td class="num"><?=CCitrusTszhReceiptComponentHelper::num($arResult["TOTALS"]["COMPENSATION"])?></td>
					<td class="num"><?=CCitrusTszhReceiptComponentHelper::num($arResult["TOTALS"]["PENALTIES"])?></td>
					<td class="num"><?=CCitrusTszhReceiptComponentHelper::num($arResult["TOTALS"]["SUMM2PAY"])?></td>
				</tr>
				<tr>
					<td colspan="5" style="text-align: right;"><strong><?=GetMessage("RCPT_TOTAL_PAYED")?></strong></td>
					<td colspan="5" class="num"><?=CCitrusTszhReceiptComponentHelper::num($arResult["TOTALS"]["SUMM_PAYED"])?></td>
				</tr>
				<tr>
					<td colspan="10" style="text-align: right;">
						<?=GetMessage("RCPT_DEBT_END")?>
						<?=__citrusReceiptNum($arResult['SUM2PAY'])?>
						<?=GetMessage("RCPT_CURRENCY")?>
					</td>
				</tr>
			</tfoot>
		</table>
	</td>
</tr>
</table>
<?

if (CModule::IncludeModule("citrus.tszhpayment") && $arResult["ACCOUNT_PERIOD"]["DEBT_END"] > 0)
{
	if (CModule::IncludeModule("vdgb.portaljkh") && method_exists("CCitrusPortalTszh", "setPaymentBase"))
		CCitrusPortalTszh::setPaymentBase($arResult["TSZH"]);
	if ($paymentPath = CTszhPaySystem::getPaymentPath($arResult["TSZH"]["SITE_ID"], false, true, 'summ=' . round($arResult["ACCOUNT_PERIOD"]["DEBT_END"])))
		echo '<div class="no-print">' . GetMessage("CITRUS_TSZHPAYMENT_LINK", Array("#LINK#" => $paymentPath)) . '</div>';
}

?>
</div>
<?if ($_GET["print"] == "Y"):
	if ($arResult["IS_LAST"]):
		if ($arResult["MODE"] == "AGENT"):?>
			</div>
		<?else:?>
			</body>
			</html>
		<?endif;
	endif;

	if (in_array($arResult["MODE"], array("ADMIN", "AGENT")))
	{
		return;
	}
	else
	{
		require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/epilog_after.php");
		die();
	}
endif;
