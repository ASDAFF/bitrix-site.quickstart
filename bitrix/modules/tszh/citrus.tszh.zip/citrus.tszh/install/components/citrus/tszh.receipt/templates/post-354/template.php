<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

/**@var bool $printDebugInfo �������� ���������� �� ���������� ������ */
$printDebugInfo = false;

global $APPLICATION, $DB;
if ($_GET["print"] == "Y")
	$APPLICATION->RestartBuffer();

require_once(__DIR__ . '/functions.php');

$APPLICATION->SetPageProperty("SHOW_TOP_LEFT", "N");

if ($_GET["print"] != "Y")
{
	$APPLICATION->AddHeadString('<link href="' . $this->GetFolder() . '/styles.css" rel="stylesheet" type="text/css" />');

	?>
	<p>
		&mdash; <a href="<?=$APPLICATION->GetCurPageParam('print=Y', Array('print'))?>" target="_blank"><?=GetMessage("RCPT_OPEN_RECEIPT_IN_WINDOW")?></a>
		<small><?=GetMessage("TPL_LANDSCAPE_NOTE")?></small>
		<br>
		&mdash; <a href="../index.php"><?=GetMessage("TPL_BACK_TO_PERSONAL")?></a>
	</p>
	<?
}
else
{
	if ($arResult["IS_FIRST"]):
		if ($arResult["MODE"] == "AGENT"):?>
			<style type="text/css">
				<?=$APPLICATION->GetFileContent($_SERVER["DOCUMENT_ROOT"] . $this->GetFolder() . "/styles.css")?>
			</style>
		<?
		else:
			?><!doctype html>
			<html>
			<head>
			<meta http-equiv="content-type" content="text/html; charset=<?=SITE_CHARSET?>"/>
			<link href="<?=$this->GetFolder()?>/styles.css" rel="stylesheet" type="text/css"/>
		<?endif?>
		<style type="text/css" media="print">
			@page {
				size: 29.7cm 21cm;
				margin: 1cm 1cm;
			}
			<?if ($arParams["INLINE"] != "Y"):?>
				#receipt table.rcpt-inner tr {
					page-break-inside: avoid;
				}
			<?endif?>
		</style>
		<?if ($arResult["MODE"] == "ADMIN"):?>
		<style type="text/css" media="screen">
			#receipt div.rcpt {
				border-bottom: 1pt dashed #000;
			}
		</style>
	<?endif;

		if ($arResult["MODE"] == "AGENT"):?>
			<div id="receipt">
		<?
		else:?>
				<title><?=GetMessage("RCPT_TITLE")?></title>
			</head>
			<body id="receipt"<?=($printDebugInfo ? '' : ' onload="window.print();"')?>>
		<?endif;
	endif;
}

?>
<div class="rcpt">
	<table width="100%">
	<tr>
		<td colspan="5" class="rcpt-header">
			<h2><?=GetMessage("TPL_DOCUMENT_TITLE")?></h2>
			<p><strong><?=GetMessage("TPL_DOCUMENT_SUBTITLE")?></strong></p>
		</td>
	</tr>
	<tr>
		<td>
			<?=GetMessage("TPL_SECTION1")?>
		</td>
		<td></td>
		<td colspan="3">
			<?=GetMessage("TPL_SECTION2")?>
		</td>
	</tr>
	<tr>
		<td width="44%">
			<?include(__DIR__ . '/1_info.php'); ?>
		</td>
		<td></td>
		<td>
			<?include(__DIR__ . '/2_contractors_info.php') ?>
		</td>
	</tr>
	</table>
	<div style="padding: 0 4pt; overflow: hidden;">
		<?include(__DIR__ . '/3_charges.php'); ?>
		<div style="margin: 1.5em 0; overflow: hidden">
			<div style="width: 42%; float: left;">
				<?=GetMessage("TPL_FOOTER_NOTES");?>
				<?include(__DIR__ . '/5_corrections.php'); ?>
			</div>
			<?include(__DIR__ . '/6_installments.php'); ?>
		</div>
	</div>
	<?

if (CModule::IncludeModule("citrus.tszhpayment") && $arResult["ACCOUNT_PERIOD"]["DEBT_END"] > 0)
{
	if (CModule::IncludeModule("vdgb.portaljkh") && method_exists("CCitrusPortalTszh", "setPaymentBase"))
		CCitrusPortalTszh::setPaymentBase($arResult["TSZH"]);
	if ($paymentPath = CTszhPaySystem::getPaymentPath($arResult["TSZH"]["SITE_ID"], false, true, 'summ=' . round($arResult["ACCOUNT_PERIOD"]["DEBT_END"])))
		echo '<div class="no-print">' . GetMessage("CITRUS_TSZHPAYMENT_LINK", Array("#LINK#" => $paymentPath)) . '</div>';
}

?>
</div>
<?
if ($_GET["print"] == 'Y')
{
	if ($arResult["IS_LAST"])
		if ($arResult["MODE"] == "AGENT")
			echo '</div>';
		else
			echo '</body></html>';

	if (in_array($arResult["MODE"], array("ADMIN", "AGENT")))
		return;
	else
	{
		require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/epilog_after.php");
		die();
	}
}