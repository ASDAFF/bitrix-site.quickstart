<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentParameters = array(
	"GROUPS" => array(
	),
	"PARAMETERS"  =>  array(
		"DONT_CHECK_PREV_VALUE" => Array(
			"NAME" => GetMessage("TSZH_DONT_CHECK_PREV_VALUE"),
			"TYPE" => "CHECKBOX",
			"DEFAULT" => "N",
		),
		"ALLOW_ZERO_VALUES" => Array(
			"NAME" => GetMessage("CITRUS_TSZH_METERS_ALLOW_ZERO_VALUES"),
			"TYPE" => "CHECKBOX",
			"DEFAULT" => "N",
		),
		"CACHE_TIME"  =>  Array("DEFAULT"=>300),
	),
);
?>
