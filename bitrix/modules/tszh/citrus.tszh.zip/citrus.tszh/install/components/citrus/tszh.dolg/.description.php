<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
	"NAME" => GetMessage("C_COMP_DOLG_NAME"),
	"DESCRIPTION" => GetMessage("C_COMP_DOLG_DESC"),
	"ICON" => "/images/icon.gif",
	"PATH" => array(
		"ID" => "citrus.tszh",
		"NAME" => GetMessage("COMPONENT_ROOT_SECTION"),
	),
);
?>
