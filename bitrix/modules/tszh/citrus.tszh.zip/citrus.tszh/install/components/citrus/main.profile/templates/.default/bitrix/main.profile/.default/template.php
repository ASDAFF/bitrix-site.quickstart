<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?><?

$arShowFields = Array(
	Array(
		'name' => 'EMAIL',
		'required' => true,
		'title' => GetMessage("F_EMAIL") . ':',
		'type' => 'string',
	),
	Array(
		'name' => 'NEW_PASSWORD',
		'title' => GetMessage("F_PASSWORD") . ':',
		'type' => 'password',
	),
	Array(
		'name' => 'NEW_PASSWORD_CONFIRM',
		'title' => GetMessage("F_CONFIRM_PASSWORD") . ':',
		'type' => 'password',
	),
);


?>
<h2><?=GetMessage("F_TITLE")?></h2>
<?
if (strlen($arResult["strProfileError"]) > 0)
	echo ShowError($arResult["strProfileError"]);

if ($arResult['DATA_SAVED'] == 'Y')
{
	ShowNote(GetMessage('PROFILE_DATA_SAVED'));

	if ($arResult["CONFIRM_EMAIL_NOTIFICATION_SENT"])
		ShowNote(GetMessage("PROFILE_CONFIRM_EMAIL_NOTIFICATION_SENT", array("#EMAIL#" => $arResult["arUser"]["EMAIL"])));
}
?>
<form method="post" name="form1" action="<?=$arResult["FORM_TARGET"]?>?" enctype="multipart/form-data">
<?=$arResult["BX_SESSION_CHECK"]?>
<input type="hidden" name="lang" value="<?=LANG?>" />
<input type="hidden" name="ID" value=<?=$arResult["ID"]?> />

<table class="profile-table data-table"><tbody>
<?
	if($arResult["ID"]>0)
	{
		$bHiddenLogin = true;
		$bHasRequiredFields = false;
		$strFooterNote = '';
		foreach ($arShowFields as $idx=>$arField) {

			$bHasRequiredFields = $bHasRequiredFields || $arField['required'];
			$bHiddenLogin = ($arField['NAME'] == 'LOGIN' ? false : $bHiddenLogin);
			$currentValue = array_key_exists('value', $arField) ? $arField['value'] : $arResult["arUser"][$arField['name']];

			$strFieldNote = ($arField['required'] ? '<span class="starrequired">*</span>' : '');
			if ($arField["name"] == 'NEW_PASSWORD') {
				$strFieldNote .= '<sup class="starrequired" style="font-size: 11px; font-weight: normal;" title="' . $arResult['GROUP_POLICY']["PASSWORD_REQUIREMENTS"] . '">1</sup>';
				$strFooterNote .= '<p><sup class="starrequired" style="font-size: 11px; font-weight: normal;">1</sup> ? ' . $arResult['GROUP_POLICY']["PASSWORD_REQUIREMENTS"] . '</p>';
			}

			switch ($arField['type']) {
				case 'textarea':
					$html = "<textarea name=\"{$arField['name']}\" id=\"f_{$idx}\" class=\"input\" />{$currentValue}</textarea>";
					break;

				case 'password':
					$html = "<input type=\"password\" name=\"{$arField['name']}\" value=\"\" id=\"f_{$idx}\" class=\"input\" />";
					break;

				default:
					$html = "<input type=\"text\" name=\"{$arField['name']}\" value=\"" . ($arField["name"] == "EMAIL" && $arResult["IS_DUMMY_MAIL"] ? '' : $currentValue) . "\" id=\"f_{$idx}\" class=\"input\" />";
					if ($arField["name"] == "EMAIL" && !$arResult["IS_DUMMY_MAIL"])
						$html = "<table id=\"profile-email-table\"><tr><td>{$html}</td><td class=\"icon " . ($arResult["arUser"]["UF_TSZH_EML_CNFRM_RQ"] ? 'nonconfirmed' : 'confirmed') . '" title="' . (getMessage($arResult["arUser"]["UF_TSZH_EML_CNFRM_RQ"] ? "PROFILE_EMAIL_NONCONFIRMED" : "PROFILE_EMAIL_CONFIRMED")) . "\"></td></tr></table>";
					break;
			}
?>
	<tr>
		<td class="profile-table-field-title"><?=$strFieldNote?><label for="f_<?=$idx?>"><?=$arField['title']?></label></td>
		<td class="profile-table-field"><?=$html?></td>
	</tr>
<?
		}


	if ($bHasRequiredFields || strlen($strFooterNote) > 0) {
?>
	<tr>
		<td>&nbsp;</td>
		<td><?=$strFooterNote?><span class="starrequired">*</span><?=GetMessage('F_REQUIRED_FIELDS')?></td>
	</tr>
<?
	}
?>
	<tr>
		<td>&nbsp;</td>
		<td><?

			if ($bHiddenLogin) {
				?><input type="hidden" name="LOGIN" value="<?=$arResult['arUser']['LOGIN']?>" /><?
			}

			TemplateShowButton(Array('title' => GetMessage("MAIN_SAVE"), 'type' => 'submit', 'attr' => array('name' => 'save', 'value' => '1')));
		?></td>
	</tr>
</table>
<?
	}
/*
	// ******************** /User properties ***************************************************?>
	<p><?echo $arResult["GROUP_POLICY"]["PASSWORD_REQUIREMENTS"];?></p>*/?>
</form>