<?
$APPLICATION->SetPageProperty('robots', 'noindex');
