<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

/** @var CCitrusTszh1cExchange $this */

if (!CModule::IncludeModule("citrus.tszh"))
	throw new Exception(GetMessage("TSZH_1C_ERROR_MODULE"));

$arTszh = $this->getOrg();
if (!is_array($arTszh) || IntVal($arTszh["ID"]) <= 0)
	throw new Exception(GetMessage("TSZH_1C_ERROR_ORG_NOT_FOUND"));

$filename = "/upload/tmp_export_" . date('Y-m-d_Hms') . ".xml";
$absFilename = str_replace('//', '/', $_SERVER['DOCUMENT_ROOT'] . '/' . $filename);

require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/citrus.tszh/classes/general/tszh_export.php");

$type = 'meters';
COption::SetOptionString("citrus.tszh", "last_{$type}_export_time_".$arTszh['ID'], time());

$arValueFilter = array();
if ($dateFrom = $this->dateFrom())
	$arValueFilter[">=TIMESTAMP_X"] = $dateFrom;
if ($dateTo = $this->dateTo())
	$arValueFilter["<=TIMESTAMP_X"] = $dateTo;
if (is_set($_GET, 'owner') && ($owner = $_GET['owner']))
{
	if (!in_array($owner, array("0","1"), true))
		throw new Exception(GetMessage("CITRUS_TSZH_EXCHANGE_WRONG_PARAM", array("#PARAM#" => "owner")));
	$arValueFilter['MODIFIED_BY_OWNER'] = $_GET["owner"] == 1 ? "Y" : "N";
}

if (!CTszhExport::DoExport($arTszh["NAME"], $arTszh["INN"], $_SERVER['DOCUMENT_ROOT'] . $filename, Array("TSZH_ID" => $arTszh['ID']), 0, 0, $arValueFilter)) {
	if ($ex = $APPLICATION->GetException())
		throw new Exception(GetMessage("TSZH_1C_METER_EXPORT_ERROR") . $ex->GetString());
	else
		throw new Exception(GetMessage("TSZH_1C_METER_EXPORT_ERROR"));
}

echo file_get_contents($absFilename);
unlink($absFilename);
$this->xmlOutput = true;
