<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/citrus.tszh/tools/1c_news.php");
?>
