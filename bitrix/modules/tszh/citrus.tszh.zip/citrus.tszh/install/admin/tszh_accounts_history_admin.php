<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/citrus.tszh/admin/tszh_accounts_history_admin.php");
?>
