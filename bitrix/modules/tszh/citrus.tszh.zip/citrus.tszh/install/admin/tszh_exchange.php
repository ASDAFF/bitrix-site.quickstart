<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/citrus.tszh/admin/tszh_exchange.php");
?>
