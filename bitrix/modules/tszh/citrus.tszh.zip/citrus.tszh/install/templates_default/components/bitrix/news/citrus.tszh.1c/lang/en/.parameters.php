<?
$MESS["T_IBLOCK_DESC_NEWS_DATE"] = "Display element date";
$MESS["T_IBLOCK_DESC_NEWS_PICTURE"] = "Display element preview picture";
$MESS["T_IBLOCK_DESC_NEWS_TEXT"] = "Display element preview text";
$MESS["T_IBLOCK_DESC_NEWS_USE_SHARE"] = "Show Social Network Bookmarks Bar";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_HIDE"] = "Hide Social Network Bookmarks Bar By Default";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_TEMPLATE"] = "Social Network Bookmarks Template";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_SYSTEM"] = "Use Social Networks And Bookmarks";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_SHORTEN_URL_LOGIN"] = "bit.ly Login";
$MESS["T_IBLOCK_DESC_NEWS_SHARE_SHORTEN_URL_KEY"] = "bit.ly Key";

$MESS["PARAM_RESIZE_IMAGE_WIDTH"] = "Width of preview-images (PREVIEW_PICTURE and DETAIL_PICTURE)";
$MESS["PARAM_RESIZE_IMAGE_HEIGHT"] = "Height of preview-images (PREVIEW_PICTURE and DETAIL_PICTURE)";
$MESS["PARAM_COLORBOX_MAXWIDTH"] = "Maximal width (maxWidth) of picture (DETAIL_PICTURE), displayed by the ColorBox";
$MESS["PARAM_COLORBOX_MAXHEIGHT"] = "Maximal height (maxHeight) of picture (DETAIL_PICTURE), displayed by the ColorBox";
?>