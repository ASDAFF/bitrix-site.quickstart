<?
$sSectionName = "#SITE_NAME#";
$arDirProperties = Array(
   "description" => "#SITE_NAME#, #SITE_ADDRESS#",
   "news" => "Y",
   "contact" => "N",
   "titule_com" => "N",
   "show_top_left" => "Y",
   "show_top_right" => "Y",
   "show_title" => "N"
);
?>