<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

if (!CModule::IncludeModule("citrus.tszh"))
	return;

$SUBSCRIBE_TEMPLATE_RESULT = true;

if ($SUBSCRIBE_TEMPLATE_RESULT):
	global $not_show_personal_data;
?>
<h3><?=GetMessage("POSTING_TEMPLATE_GREETINGS")?><?if (!$not_show_personal_data):?>, #ACCOUNT_NAME#<?endif?>!</h3>
<p><?=GetMessage("POSTING_TEMPLATE_ON_DATE")?> #CUR_PERIOD_DATE_BEG#<br />
	<?=GetMessage("POSTING_TEMPLAET_YOUR_DEBT_IS")?> <b>#DEBT_END#</b>.</p>
	
<br /><br />
<p><?=GetMessage("POSTING_TEMPLATE_BB")?>,<br />#ORG_NAME#.</p>
<?
else:
?>
<p><?=GetMessage("POSTING_TEMPLATE_NO_DATA")?></p>
<?
endif;


if($SUBSCRIBE_TEMPLATE_RESULT)
	return array(
		"SUBJECT" => $arRubric["NAME"],
		"BODY_TYPE" => "html",
		"CHARSET" => 'Windows-1251',
		"DIRECT_SEND" => "Y",
		"FROM_FIELD" => $arRubric["FROM_FIELD"],
	);
else
	return false;
?>