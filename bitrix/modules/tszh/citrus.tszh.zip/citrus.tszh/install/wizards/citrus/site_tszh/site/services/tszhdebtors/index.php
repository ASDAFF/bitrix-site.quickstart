<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)
	die();

if (!tszhCheckMinEdition('standard'))
	return;

$wizard =& $this->GetWizard();

// copy files
$sourcePath = str_replace("//", "/", WIZARD_SERVICE_ABSOLUTE_PATH."/public/".LANGUAGE_ID."/");
$destPath = WIZARD_SITE_PATH;
CopyDirFiles($sourcePath, $destPath, true, true);

//Add menu items
WizardServices::AddMenuItem(WIZARD_SITE_DIR . "/.top.menu.php", Array(
	GetMessage("F_TSZH_DEBTORS_MENUITEM"),
	WIZARD_SITE_DIR . "debtors/",
	Array(),
	Array(), 
	""
));


$arReplaceMacros = Array(
	"SITE_DIR" => WIZARD_SITE_DIR,
	"SITE_NAME" => htmlspecialcharsbx($wizard->GetVar("siteName")),
	"SITE_EMAIL" => htmlspecialcharsbx($wizard->GetVar("siteEmail")),
	"SITE_PHONE" => htmlspecialcharsbx($wizard->GetVar("siteTelephone")),
	"SITE_ADDRESS" => htmlspecialcharsbx($wizard->GetVar("siteAddress")),
	"DEBTORS_MIN_SUM" => $wizard->GetVar('SUBSCRIBE_DOLG_MIN_SUM'),
	"DEBTORS_DAY" => $wizard->GetVar('SUBSCRIBE_DOLG_DATE'),
);
WizardServices::ReplaceMacrosRecursive(WIZARD_SITE_PATH . '/debtors/', $arReplaceMacros);


?>