<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

$this->setFrameMode(true);

if (!empty($arResult)) {
	echo "<ul>";

	foreach($arResult as $idx=>$arItem) {
		$params = $a_params = '';
		$class = Array();
		if ($arItem['SELECTED'])
			$class[] = 'active';
		if ($arItem['PARAMS']['alt']) {
			$class[] = 'alt';
		}
		if ($arItem['PARAMS']['target']) {
			$a_params .= ' target="' . $arItem['PARAMS']['target'] . '"';
		}

		if (count($class) > 0)
			$params .= ' class="' . implode(' ', $class) . '"';

		echo "
<li$params>
	<a$a_params href=\"{$arItem["LINK"]}\">{$arItem["TEXT"]}</a>
</li>
";

	}
	echo "</ul>";
}

?>
