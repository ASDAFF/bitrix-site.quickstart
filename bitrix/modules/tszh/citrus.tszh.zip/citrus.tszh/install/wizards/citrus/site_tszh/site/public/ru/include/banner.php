<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>
<div class="banner">
	<EMBED type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" src="/include/ban1.swf" width="278" height="182" quality="best" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" ></EMBED>
</div>