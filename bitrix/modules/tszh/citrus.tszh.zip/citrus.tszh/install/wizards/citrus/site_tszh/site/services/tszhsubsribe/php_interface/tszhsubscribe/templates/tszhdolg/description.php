<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arTemplate =
	Array(
		"NAME" => GetMessage("tszhdolg_template_name"),
		"DESCRIPTION" => GetMessage("tszhdolg_template_desc")
	);
?>