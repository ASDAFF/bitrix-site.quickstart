<?

header("Retry-After: 300");
CHTTP::SetStatus("503 Service Unavailable");

?><!DOCTYPE html>
<html lang="ru">
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=<?=LANG_CHARSET?>"/>
	<style type="text/css">
		.error {color:#000; height:200px; margin:-100px 0 0 -340px; font-family:Arial, sans-serif; text-align:center; position:absolute; top:50%; text-align:center; left:50%; width:680px;}
		.error-fon {font-size:240px; font-weight:bold; line-height:240px; color:#f5f5f5; position:absolute; top:-16px; left:50%; margin-left:-200px; z-index:-1;}
		.error-text-top {font-size:40px; margin-top:50px;}
		.error-test-separate {border-top:1px solid #f2f2f2; margin-top:10px;}
		.error-text-bottom {font-size:20px; margin-top:16px;}
	</style>
	<title>503 Service Unavailable</title>
</head>
<body>
<div class="error">
	<div class="error-fon">503</div>
	<div class="error-text-wrap">
		<div class="error-text-top">������� ����������� ������</div>
		<div class="error-test-separate"></div>
		<div class="error-text-bottom">�������� ��������� �� ����������</div>

	</div>
</div>
</body>