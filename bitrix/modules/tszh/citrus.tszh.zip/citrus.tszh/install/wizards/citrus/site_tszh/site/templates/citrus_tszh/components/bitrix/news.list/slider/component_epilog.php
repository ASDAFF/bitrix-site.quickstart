<?
if (count($arResult['ELEMENTS']) > 0)
	CJsCore::Init(Array('jquery'));
?>