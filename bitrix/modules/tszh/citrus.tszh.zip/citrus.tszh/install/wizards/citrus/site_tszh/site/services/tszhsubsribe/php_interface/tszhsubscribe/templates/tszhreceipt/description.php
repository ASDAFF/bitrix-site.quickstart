<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arTemplate =
	Array(
		"NAME" => GetMessage("tszhreceipt_template_name"),
		"DESCRIPTION" => GetMessage("tszhreceipt_template_desc")
	);
?>