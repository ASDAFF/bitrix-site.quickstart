<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)
	die();

if(!CModule::IncludeModule("citrus.tszh"))
	return;

/*if(COption::GetOptionString("citrus.tszh", "wizard_tszh_installed", "N", WIZARD_SITE_ID) == "Y")
	return;*/

$wizard =& $this->GetWizard();

$dbSite = CSite::GetByID(WIZARD_SITE_ID);
if($arSite = $dbSite -> Fetch())
	$lang = $arSite["LANGUAGE_ID"];
if(strlen($lang) <= 0)
	$lang = "ru";

WizardServices::IncludeServiceLang("step.php", $lang);

$arUserTypes = Array(
	array (
		'ENTITY_ID' => 'TSZH_ACCOUNT',
		'FIELD_NAME' => 'UF_REGCODE',
		'USER_TYPE_ID' => 'string',
		'XML_ID' => '',
		'SORT' => '100',
		'MULTIPLE' => 'N',
		'MANDATORY' => 'N',
		'SHOW_FILTER' => 'E',
		'SHOW_IN_LIST' => 'Y',
		'EDIT_IN_LIST' => 'Y',
		'IS_SEARCHABLE' => 'N',
		'SETTINGS' =>
		array (
			'SIZE' => 30,
			'ROWS' => 1,
			'REGEXP' => '',
			'MIN_LENGTH' => 0,
			'MAX_LENGTH' => 0,
			'DEFAULT_VALUE' => '',
		),
		'EDIT_FORM_LABEL' => Array(
			$lang => GetMessage('TSZH_SERVICE_REGCODE'),
		),
		'LIST_COLUMN_LABEL' => Array(
			$lang => GetMessage('TSZH_SERVICE_REGCODE2'),
		),
		'LIST_FILTER_LABEL' => Array(
			$lang => GetMessage('TSZH_SERVICE_REGCODE2'),
		),
	),
);
foreach ($arUserTypes as $arUserTypeEntity)
{
	$arExistingUserType = CUserTypeEntity::GetList(Array(), Array("ENTITY_ID" => $arUserTypeEntity["ENTITY_ID"], "FIELD_NAME" => $arUserTypeEntity["FIELD_NAME"]))->Fetch();
	$userTypeEntity = new CUserTypeEntity();
	if (is_array($arExistingUserType))
		$bSuccess = $userTypeEntity->Update($arExistingUserType['ID'], $arUserTypeEntity);
	else
		$bSuccess = $userTypeEntity->Add($arUserTypeEntity) > 0;
	if (!$bSuccess)
	{
		$strError = GetMessage("TSZH_SERIVCE_ERROR");
		if ($ex = $APPLICATION->GetException())
			$strError .= ': ' . $ex->GetString();
		ShowError($strError);
		die();
	}
}

$arVars = Array(
	"org_title" => 'NAME',
	"org_inn" => "INN",
	"org_kpp" => "KPP",
	"org_rsch" => "RSCH",
	"org_bank" => "BANK",
	"org_ksch" => "KSCH",
	"org_bik" => "BIK",
);

$arFields = Array(
	"NAME" => GetMessage("TSZH_NAME_DEFAULT"),
	"SITE_ID" => WIZARD_SITE_ID,
	"ADDRESS" => $wizard->GetVar("siteAddress"),
	"LEGAL_ADDRESS" => $wizard->GetVar("LEGAL_ADDRESS"),
	"PHONE" => $wizard->GetVar("siteTelephone"),
	"PHONE_DISP" => $wizard->GetVar("siteTelephoneDisp"),
	"MONETA_ENABLED" => $wizard->GetVar("MONETA_ENABLED"),
	"MONETA_OFFER" => $wizard->GetVar("MONETA_OFFER"),
	"MONETA_EMAIL" => $wizard->GetVar("MONETA_EMAIL"),
	"HEAD_NAME" => $wizard->GetVar("HEAD_NAME"),
	"OFFICE_HOURS" => $wizard->GetVar("OFFICE_HOURS"),
	"EMAIL" => $wizard->GetVar("siteEmail"),
	"RECEIPT_TEMPLATE" => $wizard->GetVar("RECEIPT_TEMPLATE"),
);
foreach ($arVars as $strVar => $field) {
	$value = $wizard->GetVar($strVar);
	COption::SetOptionString("citrus.tszh", $strVar, $value);
	if (strlen($value) > 0)
		$arFields[$field] = $value;
}

unset($_SESSION[$wizard->solutionName]['demoTszhID']);
if ($arTszh = CTszh::GetList(Array(), Array("SITE_ID" => WIZARD_SITE_ID))->Fetch()) {
	CTszh::Update($arTszh["ID"], $arFields);
} else {
	$tszhID = CTszh::Add($arFields);
	if (intval($tszhID) > 0)
		$_SESSION[$wizard->solutionName]['demoTszhID'] = $tszhID;
}

WizardServices::SetFilePermission(WIZARD_SITE_DIR . 'personal', Array(COption::GetOptionString("citrus.tszh", "user_group_id", 3, WIZARD_SITE_ID) => 'R', '*' => 'D'));
WizardServices::SetFilePermission(WIZARD_SITE_DIR . 'personal/confirm-account', Array('2' => 'R'));
//WizardServices::IncludeServiceLang("type.php", $languageID);
$arReceiptTmplate = explode("/", $wizard->GetVar("RECEIPT_TEMPLATE"));
$receiptComponentTemplate = strval(array_pop($arReceiptTmplate));
CWizardUtil::ReplaceMacros(WIZARD_SITE_PATH."/personal/receipt/index.php", array("RECEIPT_COMPONENT_TEMPLATE" => $receiptComponentTemplate));

if (tszhCheckMinEdition('standard'))
{
	// copy payment_receive.php and /images
	$sourceDir = str_replace("//", "/", WIZARD_SERVICE_ABSOLUTE_PATH."/public/".LANGUAGE_ID."/");
	$destDir = str_replace("//", "/", WIZARD_SITE_PATH . "/");
	CopyDirFiles($sourceDir, $destDir, true, true);
}

COption::SetOptionString("citrus.tszh", "wizard_tszh_installed", "Y", false, WIZARD_SITE_ID);

?>