<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arTemplate =
	Array(
		"NAME" => GetMessage("tszhmetersvalues_template_name"),
		"DESCRIPTION" => GetMessage("tszhmetersvalues_template_desc")
	);
?>