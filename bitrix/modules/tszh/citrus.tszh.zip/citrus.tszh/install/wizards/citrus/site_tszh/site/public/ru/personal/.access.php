<?
$PERM["payment"]["*"]="R";
$PERM["confirm-account"]["*"]="R";
?>