<?
$PERM["confirm-account"]["*"]="R";
?>