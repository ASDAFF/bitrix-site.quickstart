<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>
<h2><a href="#SITE_DIR#contacts/">��������</a></h2>
<?$APPLICATION->IncludeComponent(
	"citrus:tszh.contacts",
	"block",
	Array(
		"CONTACTS_URL" => "#SITE_DIR#contacts/",
	),
	false
);?>
