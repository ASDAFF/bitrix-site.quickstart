<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)
	die();

if (!tszhCheckMinEdition('standard'))
	return;

/** @var CWizardBase $wizard */
$wizard =& $this->GetWizard();

// copy files
$sourcePath = str_replace("//", "/", WIZARD_SERVICE_ABSOLUTE_PATH."/php_interface/");
$destPath = str_replace("//", "/", WIZARD_SITE_ROOT_PATH . '/bitrix/php_interface/');
CopyDirFiles($sourcePath, $destPath, true, true);

// ��������� ��������� �����������
$arVars = Array(
	"SUBSCRIBE_DOLG_ACTIVE",
	"SUBSCRIBE_DOLG_MIN_SUM",
	"SUBSCRIBE_DOLG_DATE",
	"SUBSCRIBE_METERS_ACTIVE",
	"SUBSCRIBE_METERS_DATE",
	"SUBSCRIBE_RECEIPT_ACTIVE",
);
$arFields = Array();
foreach ($arVars as $strField)
{
	$arFields[$strField] = $wizard->GetVar($strField, true);

	if (in_array($strField, array("SUBSCRIBE_DOLG_ACTIVE", "SUBSCRIBE_METERS_ACTIVE", "SUBSCRIBE_RECEIPT_ACTIVE")))
		$arFields[$strField] = $arFields[$strField] == "Y" ? "Y" : "N";
}

try
{
	$tszh = CTszh::GetList(Array(), Array("SITE_ID" => WIZARD_SITE_ID))->Fetch();
	if (!is_array($tszh))
		throw new Exception("Tszh not found");

	if (!CTszh::Update($tszh["ID"], $arFields))
		throw new Exception(($ex = $APPLICATION->GetException()) ? $ex->GetString() : "CTszh::Update() failed.");
}
catch (Exception $e)
{
	echo $e->getMessage();
	die();
}
