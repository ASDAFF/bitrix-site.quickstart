<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

$this->setFrameMode(true);

if (!empty($arResult)) {
	echo "<ul class=\"left-menu\">\n";
	$n = 1;
	foreach($arResult as $idx=>$arItem) {
		
		$params = '';
		$class = Array();
		if ($arItem['SELECTED'])
			$class[] = 'active';
			
		if (strlen($arItem['TEXT']) > 20)
			$class[] = 'b';
			
		if (count($class) > 0)
			$params = ' class="' . implode(' ', $class) . '"'; 
			
		echo "	<li$params><a href=\"{$arItem["LINK"]}\"><span class=\"n\">{$n}</span> {$arItem["TEXT"]}</a></li>\n";
		$n++;		
	}
	echo "</ul>\n";
}

?>
