<?
$PERM["personal"]["*"]="D";
$PERM["workplace"]["*"]="D";
$PERM["/"]["*"]="R";
?>