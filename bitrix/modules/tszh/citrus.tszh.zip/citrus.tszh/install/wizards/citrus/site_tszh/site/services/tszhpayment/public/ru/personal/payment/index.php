<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("������");
?><?$APPLICATION->IncludeComponent(
	"citrus:tszh.payment",
	"",
	Array(
		"CACHE_TYPE" => "A",
		"CACHE_TIME" => "3600"
	),
false
);?><?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>