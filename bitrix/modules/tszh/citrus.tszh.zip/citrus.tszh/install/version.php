<?
$arModuleVersion = array(
	"VERSION" => "14.6.4",
	"VERSION_DATE" => "2015-04-20 16:00:00"
);
?>