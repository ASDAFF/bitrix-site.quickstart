<?
$MESS["ELEMENT_NOTFOUND"] = "Элемент не найден";
$MESS["SHARE_TEXT"] = 'Поделиться';
$MESS["BACK_LINK"] = "Назад к списку";
$MESS["T_DOCS"] = 'Документы';
$MESS["T_GALLERY"] = 'Фотогалерея';
$MESS["T_PROJECTS"] = 'Проекты';
$MESS["T_REVIEWS"] = 'Отзывы';
$MESS["T_STAFF1"] = 'Специалист';
$MESS["T_STAFF2"] = 'Специалисты';
$MESS["T_GOODS"] = 'Товары';
$MESS["T_SERVICES"] = 'Услуги';
$MESS["T_CHARACTERISTICS"] = "Характеристики";
?>