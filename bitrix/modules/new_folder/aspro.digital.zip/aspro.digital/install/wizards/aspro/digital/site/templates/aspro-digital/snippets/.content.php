<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>
<?
$SNIPPETS = Array();
$SNIPPETS['snippet0001.snp'] = Array('title' => 'Horizontal colored line');
$SNIPPETS['snippet0002.snp'] = Array('title' => 'Blockquote');
$SNIPPETS['snippet0003.snp'] = Array('title' => 'Table with border');
$SNIPPETS['snippet0004.snp'] = Array('title' => 'Table');
$SNIPPETS['snippet0005.snp'] = Array('title' => 'Danger block');
$SNIPPETS['snippet0006.snp'] = Array('title' => 'Info block');
?>