<?
$MESS['SECTION_EMPTY'] = "Нет сотрудников";
$MESS['SECTION_NOTFOUND'] = "Раздел не найден";
?>
