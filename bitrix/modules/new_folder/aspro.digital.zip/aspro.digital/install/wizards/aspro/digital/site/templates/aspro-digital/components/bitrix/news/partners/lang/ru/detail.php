<?
$MESS['ELEMENT_NOTFOUND'] = 'Элемент не найден';
$MESS['BACK_LINK'] = 'Список партнеров';

$MESS['T_REVIEWS'] = 'Отзывы';
$MESS['T_DOCS'] = 'Рекомендательные письма';
$MESS['T_PROJECTS'] = 'Проекты';
?>