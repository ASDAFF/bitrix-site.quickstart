<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>
<?$arTemplate = Array("NAME" => GetMessage('THEME_NAME'), "SORT" => 17);?>