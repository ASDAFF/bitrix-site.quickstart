<?
$MESS['SECTION_EMPTY'] = "Список элементов пуст";
$MESS['SECTION_NOTFOUND'] = "Раздел не найден";
$MESS['S_ASK_QUESTION'] = "Задать вопрос";
?>
