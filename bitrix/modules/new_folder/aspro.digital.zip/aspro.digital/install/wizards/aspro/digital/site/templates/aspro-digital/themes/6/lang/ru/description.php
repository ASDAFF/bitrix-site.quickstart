<?
$MESS["THEME_NAME"] = "Тема 6";
?>