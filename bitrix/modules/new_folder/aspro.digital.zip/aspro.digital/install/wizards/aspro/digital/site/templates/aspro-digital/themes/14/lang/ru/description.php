<?
$MESS["THEME_NAME"] = "Тема 14";
?>