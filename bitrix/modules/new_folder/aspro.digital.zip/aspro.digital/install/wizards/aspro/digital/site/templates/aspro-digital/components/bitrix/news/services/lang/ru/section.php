<?
$MESS["SECTION_EMPTY"] = "Нет услуг";
$MESS["SECTION_NOTFOUND"] = "Раздел не найден";
?>