<div class="scroller">
	<div class="wrap">
		<b><?=__FILE__?></b>
	</div>
</div>