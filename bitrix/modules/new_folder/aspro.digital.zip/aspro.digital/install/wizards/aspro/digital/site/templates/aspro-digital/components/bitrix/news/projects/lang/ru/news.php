<?
$MESS['SEARCH_LABEL'] = "Поиск:";
$MESS['SECTION_EMPTY'] = "Список элементов пуст";
$MESS['ALL_PROJECTS'] = "Все проекты";
$MESS['ALL_TIME'] = "За все время";
?>
