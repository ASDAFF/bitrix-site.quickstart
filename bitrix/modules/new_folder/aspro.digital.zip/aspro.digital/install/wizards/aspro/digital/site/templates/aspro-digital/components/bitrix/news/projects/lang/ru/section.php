<?
$MESS['SECTION_EMPTY'] = "Список элементов пуст";
$MESS['SECTION_NOTFOUND'] = "Раздел не найден";
$MESS['ALL_PROJECTS'] = "Все проекты";
$MESS['CURRENT_PROJECTS'] = "Все проекты за #YEAR# год";
$MESS['ALL_TIME'] = "За все время";
?>
