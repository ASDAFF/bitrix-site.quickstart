<?
$MESS['SEARCH_LABEL'] = "Поиск:";
$MESS['SECTION_EMPTY'] = "Список элементов пуст";
$MESS['ALL_TIME'] = "За все время";
$MESS['S_ASK_QUESTION'] = "Задать вопрос";
?>
