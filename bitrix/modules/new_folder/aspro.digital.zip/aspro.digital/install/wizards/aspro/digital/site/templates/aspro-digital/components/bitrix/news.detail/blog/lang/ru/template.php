<?
$MESS['S_ASK_QUESTION'] = 'Задать вопрос';
$MESS['S_ORDER_SERVISE'] = 'Заказать услугу';
$MESS['S_ORDER_STUDY'] = 'Заказать курс';
$MESS['T_DOCS'] = 'Документы';
$MESS['T_GALLERY'] = 'Фотогалерея';
$MESS['T_PROJECTS'] = 'Проекты';
$MESS['T_REVIEWS'] = 'Отзывы';
$MESS['T_STAFF1'] = 'Сотрудник';
$MESS['T_STAFF2'] = 'Сотрудники';
$MESS['T_GOODS'] = 'Товары';
$MESS['T_STUDY'] = 'Курсы';
$MESS['T_SERVICES'] = 'Услуги';
$MESS['T_CHARACTERISTICS'] = 'Характеристики';
$MESS["T_VIDEO"] = "Видео";
$MESS['SHARE_TEXT'] = 'Поделиться';
$MESS['TAGS'] = 'Теги';
?>