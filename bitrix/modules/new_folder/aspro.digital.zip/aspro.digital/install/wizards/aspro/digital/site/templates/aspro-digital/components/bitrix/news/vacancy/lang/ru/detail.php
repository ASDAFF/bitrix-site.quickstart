<?
$MESS['ELEMENT_NOTFOUND'] = 'Элемент не найден';
$MESS["SHARE_TEXT"] = 'Поделиться';
$MESS['FORM_BUTTON_TITLE'] = "Отправить резюме";
$MESS['BACK_LINK'] = "Список вакансий";
?>