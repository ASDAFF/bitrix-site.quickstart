<?
CDigital::getFieldImageData($arResult, array('PREVIEW_PICTURE'));
?>