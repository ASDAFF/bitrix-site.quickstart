<?
$MESS['SECTION_EMPTY'] = "Нет партнеров";
$MESS['SECTION_NOTFOUND'] = "Раздел не найден";
?>
