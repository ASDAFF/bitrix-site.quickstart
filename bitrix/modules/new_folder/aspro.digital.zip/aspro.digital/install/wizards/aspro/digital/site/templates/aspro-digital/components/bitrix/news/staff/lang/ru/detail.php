<?
$MESS['ELEMENT_NOTFOUND'] = 'Элемент не найден';
$MESS['BACK_LINK'] = 'Список сотрудников';
?>