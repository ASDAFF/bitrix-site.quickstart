<?
$MESS["S_ORDER_PRODUCT"] = "Заказать";
$MESS["S_ORDER_SERVISE"] = "Заказать товар";
$MESS["S_ASK_QUESTION"] = "Задать вопрос";
$MESS["DISCOUNT_PRICE"] = "Цена без скидки:";
$MESS["SHARE_TEXT"] = "Поделиться";
$MESS["MORE_TEXT"] = "Мы свяжемся с вами для уточнения формы оплаты и способа доставки заказа";
$MESS["ARTICLE"] = "Арт.";
$MESS["BRAND"] = "Бренд:";
$MESS["T_CHARACTERISTICS"] = "Характеристики";
$MESS["T_DOCS"] = "Документы";
$MESS["T_PROJECTS"] = "Проекты";
$MESS["T_VIDEO"] = "Видео";
$MESS["T_SERVICES"] = "Услуги";
$MESS["T_DEV"] = "Разработчик продукта";
$MESS["T_ITEMS"] = "Товары";
$MESS["T_FAQ"] = "FAQ";
$MESS["T_TARIF"] = "Тарифы";
$MESS["T_DESC"] = "Описание";
$MESS['BUTTON_TO_CART'] = 'В корзину';
$MESS['BUTTON_IN_CART'] = 'В корзине';
$MESS['MORE_TEXT_BOTTOM'] = 'Подробнее';
$MESS['S_CHOISE_PRODUCT'] = 'Выбрать';
?>