<?
$MESS["IBLOCK_CSC_TAB_COMMENTS"] = "Comments";
$MESS["IBLOCK_CSC_TAB_VK"] = " ";
$MESS["IBLOCK_CSC_NO_DATA"] = "Comment type is not specified in the component properties.";
$MESS["IBLOCK_CSC_COMMENTS_LOADING"] = "Loading comments...";
?>