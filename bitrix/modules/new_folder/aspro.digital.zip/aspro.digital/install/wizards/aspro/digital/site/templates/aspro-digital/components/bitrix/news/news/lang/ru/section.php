<?
$MESS['SECTION_EMPTY'] = "Список элементов пуст";
$MESS['SECTION_NOTFOUND'] = "Раздел не найден";
$MESS['ALL_TIME'] = "За все время";
$MESS['CURRENT_NEWS'] = "Новости за #YEAR# год";

$MESS['S_ASK_QUESTION'] = "Задать вопрос";

?>
