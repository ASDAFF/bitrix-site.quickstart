<?
$MESS['SEARCH_LABEL'] = "Поиск:";
$MESS['SECTION_EMPTY'] = "Список элементов пуст";
$MESS['S_ASK_QUESTION'] = "Задать вопрос";
$MESS['CHOISE_ITEM'] = "-Выбрать #ITEM#-";
$MESS['REGION'] = "регион";
$MESS['CITY'] = "город";
$MESS['SPRAVKA'] = "Справочная служба";
?>
