<div class="mobileheader-custom">
	<div class="burger pull-left">
		<i class="svg svg-burger mask"></i>
		<i class="svg svg-close black lg"></i>
	</div>
	<div class="title-block col-sm-8 col-xs-7 pull-left"><b><?=__FILE__?></b></div>
	<div class="right-icons pull-right">
	</div>
</div>