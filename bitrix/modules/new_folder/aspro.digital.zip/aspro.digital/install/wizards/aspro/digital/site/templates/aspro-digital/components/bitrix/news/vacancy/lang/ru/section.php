<?
$MESS['SECTION_EMPTY'] = "Нет вакансий";
$MESS['SECTION_NOTFOUND'] = "Раздел не найден";
$MESS['FORM_BUTTON_TITLE'] = "Отправить резюме";
?>
