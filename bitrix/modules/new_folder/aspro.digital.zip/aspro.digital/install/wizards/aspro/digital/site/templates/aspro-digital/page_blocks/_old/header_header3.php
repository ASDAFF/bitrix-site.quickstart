<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();?>
<header class="topmenu-LIGHT">
	<div class="logo_and_menu-row">
		<div class="logo-row row">
			<div class="maxwidth-theme">
				<div class="col-md-12">header 3</div>
			</div>
		</div>
	</div>
</header>