<?
$MESS['DIGITAL_CONTROL_CENTER_TITLE'] = 'Центр управления';
$MESS['DIGITAL_NO_RIGHTS_FOR_VIEWING'] = 'Доступ закрыт';
$MESS['DIGITAL_MODULE_NOT_INCLUDED'] = 'Не удалось подключить модуль Аспро: Digital';
$MESS['DIGITAL_MODULE_CONTROL_CENTER_ERROR'] = 'Не удалось получить информацию об установке решения';
?>