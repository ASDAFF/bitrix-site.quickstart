<?
$MESS['NO_RIGHTS_FOR_VIEWING'] = 'Недостаточно прав для просмотра';
$MESS['MAIN_OPTIONS_SITE_TITLE'] = 'Настройки сайта &laquo;#SITE_NAME#&raquo; (#SITE_ID#)';
$MESS['USE_FILTERS'] = 'Использовать фильтры товаров';
$MESS['HTML5_FLASH_ERROR'] = 'Ваш браузер не поддерживает HTML5 и Flash, пожалуйста обновите браузер';
$MESS['CLEAR_HTML_CACHE_NOTE'] = 'После изменения настроек рекомендуем <a target="_blank" href="/bitrix/admin/cache.php?lang=ru&amp;cachetype=html&amp;tabControl_active_tab=fedit2">очистить композитный (html) кеш</a>';
$MESS['WILL_CLEAR_HTML_CACHE_NOTE'] = 'Будет выполнена очистка композитного (html) кеша';
$MESS['NO_COMPOSITE_NOTE'] = 'Включение отображения переключателя тем в публичной части сайта отменит композитное кеширование.';
$MESS['SUB_PARAMS'] = 'Параметры';
?>