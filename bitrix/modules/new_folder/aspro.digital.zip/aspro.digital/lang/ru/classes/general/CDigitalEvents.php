<?
$MESS["EMAIL_IS_ALREADY_EXISTS"] = "#EMAIL# уже используется";
$MESS["ERROR_FORM_CAPTCHA"] = "Неверный код проверки";
$MESS["ERROR_FORM_LICENSE"] = "Согласитесь с условиями";
?>