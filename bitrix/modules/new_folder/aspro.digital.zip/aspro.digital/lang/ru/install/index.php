<?
$MESS['DIGITAL_MODULE_NAME'] = 'Аспро: Digital-компания';
$MESS['DIGITAL_MODULE_DESC'] = 'Мастер создания сайта «Аспро: Digital-компания»';
$MESS['DIGITAL_PARTNER'] = 'Аспро';
$MESS['DIGITAL_PARTNER_URI'] = 'http://aspro.ru';
$MESS['DIGITAL_MOD_INST_OK'] = 'Установка модуля успешно завершена';
$MESS['DIGITAL_MOD_INST_NOTE'] = 'Поздравляем, модуль <b>«Аспро: Digital-компания»</b> успешно установлен!<br />Для установки готового сайта, пожалуйста перейдите <a href="/bitrix/admin/wizard_list.php?lang=ru">в список мастеров</a> <br />и выберите пункт <b>«Установить»</b> в меню мастера aspro:digital';
$MESS['DIGITAL_MOD_UNINST_OK'] = 'Удаление модуля успешно завершено';
$MESS['DIGITAL_MOD_BACK'] = 'Вернуться в список';
$MESS['DIGITAL_OPEN_WIZARDS_LIST'] = 'Открыть список мастеров';
$MESS['DIGITAL_INSTALL_TITLE'] = 'Установка модуля';
$MESS['DIGITAL_UNINSTALL_TITLE'] = 'Удаление модуля';
$MESS['DIGITAL_INSTALL_SITE'] = 'Перейти к установке';
?>