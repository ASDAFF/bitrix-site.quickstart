<?
$MESS["ELEMENT_NOTFOUND"] = "Элемент не найден";
$MESS["SHARE_TEXT"] = 'Поделиться ссылкой:';
$MESS["BACK_LINK"] = "Вернуться к списку";
$MESS["T_DOCS"] = 'Документы';
$MESS["T_GALLERY"] = 'Галерея';
$MESS["T_PROJECTS"] = 'Проекты';
$MESS["T_REVIEWS"] = 'Отзывы';
$MESS["T_STAFF1"] = 'Специалист';
$MESS["T_STAFF2"] = 'Специалисты';
$MESS["T_GOODS"] = 'Товары';
$MESS["T_SERVICES"] = 'Услуги';
$MESS["T_CHARACTERISTICS"] = "Характеристики";
?>