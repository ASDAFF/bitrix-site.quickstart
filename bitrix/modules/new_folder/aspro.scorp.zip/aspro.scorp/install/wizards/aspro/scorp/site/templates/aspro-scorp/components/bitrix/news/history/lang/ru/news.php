<?
$MESS['SEARCH_LABEL'] = "Поиск:";
$MESS['SECTION_EMPTY'] = "Нет истории";
?>
