<?
$MESS["SECTION_EMPTY"] = "Нет проектов";
$MESS["SECTION_NOTFOUND"] = "Раздел не найден";
?>