<?
$MESS ['MYS_LOADING'] = "loading map...";
?>