<?
$MESS["TITLE_DETAIL"] = "Описание проекта";
$MESS["TITLE_PROP"] = "Характеристики";
$MESS["S_ORDER_PROJECT"] = "Заказать проект";
$MESS["S_ASK_QUESTION"] = "Задать вопрос";
$MESS["SHARE_TEXT"] = "Поделиться ссылкой:";
$MESS["LINK_PROJECTS"] = "Похожие проекты";
$MESS["BACK"] = "Вернуться к списку проектов";
$MESS["SECTION_NAME"] = "Категория";
$MESS["T_VIDEO"] = "Видео";
?>