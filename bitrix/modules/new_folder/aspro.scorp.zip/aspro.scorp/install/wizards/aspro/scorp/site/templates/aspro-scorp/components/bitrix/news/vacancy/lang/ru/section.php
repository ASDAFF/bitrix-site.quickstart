<?
$MESS['SECTION_EMPTY'] = "Нет вакансий";
$MESS['SECTION_NOTFOUND'] = "Раздел не найден";
?>
