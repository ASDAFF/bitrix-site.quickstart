<?
$MESS["CT_BNL_ELEMENT_DELETE_CONFIRM"] = "Будет удалена вся информация, связанная с этой записью. Продолжить?";
$MESS["TO_ALL"] = 'Подробнее';
$MESS["TO_ORDER"] = 'Заказать';
$MESS["SECTION_EMPTY"] = 'Список элементов пуст';
?>