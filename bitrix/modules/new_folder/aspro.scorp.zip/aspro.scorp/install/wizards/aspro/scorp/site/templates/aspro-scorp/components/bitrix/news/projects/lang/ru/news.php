<?
$MESS['SEARCH_LABEL'] = "Поиск:";
$MESS["SECTION_EMPTY"] = "Нет проектов";
$MESS["ALL_PROJECTS"] = "Все проекты";
?>
