<?
$MESS["TP_BSP_USE_SUGGEST"] = "Show search phrase prompts";
$MESS["TP_BSP_SHOW_RATING"] = "Show ratings";
$MESS["TP_BSP_PATH_TO_USER_PROFILE"] = "User profile path template";
$MESS["TP_BSP_SHOW_RATING_CONFIG"] = "default";
$MESS["TP_BSP_RATING_TYPE"] = "Rating buttons design";
$MESS["TP_BSP_RATING_TYPE_CONFIG"] = "default";
$MESS["TP_BSP_RATING_TYPE_STANDART_TEXT"] = "Like/Unlike (text)";
$MESS["TP_BSP_RATING_TYPE_STANDART_GRAPHIC"] = "Like/Unlike (image)";
$MESS["TP_BSP_RATING_TYPE_LIKE_TEXT"] = "Like (text)";
$MESS["TP_BSP_RATING_TYPE_LIKE_GRAPHIC"] = "Like (image)";
?>