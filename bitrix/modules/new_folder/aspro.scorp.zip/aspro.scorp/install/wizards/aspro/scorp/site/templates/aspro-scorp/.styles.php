<?
return array(
	"underline" => "Title with underline",
	"table table-striped" => "Table",
	"table table-bordered" => "Borderd table",
	"grey_dark" => "Dark text",
	"grey_light" => "Bright text",
	"dark_light_table" => "Fark table header",
	"dark_light" => "Dark text",
);
?>