<?
$MESS['T_IBLOCK_DESC_NEWS_DATE'] = 'Выводить дату элемента';
$MESS['T_IBLOCK_DESC_NEWS_NAME'] = 'Выводить название элемента';
$MESS['T_IBLOCK_DESC_NEWS_PICTURE'] = 'Выводить детальное изображение';
$MESS['T_IBLOCK_DESC_NEWS_TEXT'] = 'Выводить текст анонса';
$MESS['T_IBLOCK_DESC_NEWS_USE_SHARE'] = 'Отображать панель соц. закладок';
$MESS['T_IBLOCK_DESC_NEWS_SHARE_HIDE'] = 'Не раскрывать панель соц. закладок по умолчанию';
$MESS['T_IBLOCK_DESC_NEWS_SHARE_TEMPLATE'] = 'Шаблон компонента панели соц. закладок';
$MESS['T_IBLOCK_DESC_NEWS_SHARE_SYSTEM'] = 'Используемые соц. закладки и сети';
$MESS['T_IBLOCK_DESC_NEWS_SHARE_SHORTEN_URL_LOGIN'] = 'Логин для bit.ly';
$MESS['T_IBLOCK_DESC_NEWS_SHARE_SHORTEN_URL_KEY'] = 'Ключ для для bit.ly';
$MESS['S_ASK_QUESTION'] = 'Текст кнопки "Задать вопрос"';
$MESS['S_ORDER_SERVICE'] = 'Текст кнопки "Заказть услугу"';
$MESS['T_GALLERY'] = 'Текст подзаголовка "Галерея"';
$MESS['T_DOCS'] = 'Текст подзаголовка "Документы"';
$MESS['T_GOODS'] = 'Текст подзаголовка "Товары"';
$MESS['T_SERVICES'] = 'Текст подзаголовка "Услуги"';
$MESS['T_PROJECTS'] = 'Текст подзаголовка "Проекты"';
$MESS['T_REVIEWS'] = 'Текст подзаголовка "Отзывы"';
$MESS['T_STAFF'] = 'Текст подзаголовка "Специалисты"';
$MESS['T_VIDEO'] = 'Текст подзаголовка "Видео"';
?>