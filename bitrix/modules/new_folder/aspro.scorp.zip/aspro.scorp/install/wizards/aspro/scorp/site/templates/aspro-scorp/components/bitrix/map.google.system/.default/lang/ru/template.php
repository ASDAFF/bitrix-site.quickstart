<?
$MESS ['MYS_LOADING'] = "загрузка карты...";
?>