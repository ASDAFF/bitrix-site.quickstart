<?
$MESS['SHOW_DETAIL_LINK'] = 'Отображать ссылку на детальную страницу';
$MESS['COUNT_IN_LINE'] = 'Количество элементов в строке';
$MESS['VIEW_TYPE'] = 'Вид отображения';
$MESS['VIEW_TYPE_LIST'] = 'Список';
$MESS['VIEW_TYPE_TABLE'] = 'Таблица';
$MESS['VIEW_TYPE_ACCORDION'] = 'Аккордион';
$MESS['COUNT_IN_LINE'] = 'Количество элементов в строке';
$MESS['SHOW_TABS'] = 'Показывать табы';
$MESS['SHOW_NAME'] = 'Показывать название';
$MESS['SHOW_DETAIL'] = 'Ссылка на детальную страницу';
$MESS['SHOW_IMAGE'] = 'Показывать изображение';
$MESS['IMAGE_POSITION'] = 'Положение изображения';
$MESS['IMAGE_POSITION_LEFT'] = 'Слева';
$MESS['IMAGE_POSITION_RIGHT'] = 'Справа';
$MESS['IMAGE_POSITION_TOP'] = 'Сверху';
$MESS['IMAGE_POSITION_BOTTOM'] = 'Снизу';
$MESS['S_ASK_QUESTION'] = 'Текст кнопки "Задать вопрос"';
$MESS['S_ORDER_PROJECT'] = 'Текст кнопки "Заказать проект"';
$MESS['T_GALLERY'] = 'Текст подзаголовка "Галерея"';
$MESS['T_DOCS'] = 'Текст подзаголовка "Документы"';
$MESS['T_PROJECTS'] = 'Текст подзаголовка "Проекты"';
$MESS['T_CHARACTERISTICS'] = 'Текст подзаголовка "Характеристики"';
?>