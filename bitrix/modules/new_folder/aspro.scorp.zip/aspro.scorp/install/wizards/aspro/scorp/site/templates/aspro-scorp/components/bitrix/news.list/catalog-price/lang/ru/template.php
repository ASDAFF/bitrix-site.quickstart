<?
$MESS['CT_BNL_ELEMENT_DELETE_CONFIRM'] = 'Будет удалена вся информация, связанная с этой записью. Продолжить?';
$MESS['TO_ALL'] = 'Подробнее';
$MESS['S_ORDER_PRODUCT'] = 'Заказать';
$MESS['S_ARTICLE'] = 'Артикул';
$MESS['BUTTON_TO_CART'] = 'В корзину';
$MESS['BUTTON_IN_CART'] = 'В корзине';
?>