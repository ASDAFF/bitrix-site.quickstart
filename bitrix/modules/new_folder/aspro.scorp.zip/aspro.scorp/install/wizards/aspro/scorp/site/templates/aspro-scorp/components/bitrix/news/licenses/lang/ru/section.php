<?
$MESS['SECTION_EMPTY'] = "Нет лицензий";
$MESS['SECTION_NOTFOUND'] = "Раздел не найден";
?>
