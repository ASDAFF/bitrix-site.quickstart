<?
$MESS['SCORP_MODULE_NAME'] = 'Аспро: Корпоративный сайт современной компании';
$MESS['SCORP_MODULE_DESC'] = 'Мастер создания сайта «Аспро: Корпоративный сайт современной компании»';
$MESS['SCORP_PARTNER'] = 'Аспро';
$MESS['SCORP_PARTNER_URI'] = 'http://aspro.ru';
$MESS['SCORP_MOD_INST_OK'] = 'Установка модуля успешно завершена';
$MESS['SCORP_MOD_INST_NOTE'] = 'Поздравляем, модуль <b>«Аспро: Корпоративный сайт современной компании»</b> успешно установлен!<br />Для установки готового сайта, пожалуйста перейдите <a href="/bitrix/admin/wizard_list.php?lang=ru">в список мастеров</a> <br />и выберите пункт <b>«Установить»</b> в меню мастера aspro:scorp';
$MESS['SCORP_MOD_UNINST_OK'] = 'Удаление модуля успешно завершено';
$MESS['SCORP_MOD_BACK'] = 'Вернуться в список';
$MESS['SCORP_OPEN_WIZARDS_LIST'] = 'Открыть список мастеров';
$MESS['SCORP_INSTALL_TITLE'] = 'Установка модуля';
$MESS['SCORP_UNINSTALL_TITLE'] = 'Удаление модуля';
$MESS['SCORP_INSTALL_SITE'] = 'Перейти к установке';
?>