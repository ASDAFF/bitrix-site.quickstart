<?
$MESS['SCORP_CONTROL_CENTER_TITLE'] = 'Центр управления';
$MESS['SCORP_NO_RIGHTS_FOR_VIEWING'] = 'Доступ закрыт';
$MESS['SCORP_MODULE_NOT_INCLUDED'] = 'Не удалось подключить модуль Аспро: Scorp';
$MESS['SCORP_MODULE_CONTROL_CENTER_ERROR'] = 'Не удалось получить информацию об установке решения';
?>