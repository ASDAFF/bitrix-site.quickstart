<?
$MESS['SCORP_CANT_INCLUDE_MODULE'] = 'Не получилось подключить модуль #REQUIRE_MODULE_NAME#';
$MESS['SCORP_ACCESS_DENIED'] = 'Доступ запрещен';
$MESS["ERROR_FORM_LICENSE"] = "Согласитесь с условиями.";
$MESS["CT_NAME_SIZE"] = "Размер";
$MESS["CT_NAME_TB"] = " Tб";
$MESS["CT_NAME_GB"] = " Гб";
$MESS["CT_NAME_MB"] = " Мб";
$MESS["CT_NAME_KB"] = " Кб";
$MESS["CT_NAME_b"] = " байт";
$MESS["SCORP_CUR_EUR1"] = '€';
$MESS["SCORP_CUR_RUB1"] = "руб.";
$MESS["SCORP_CUR_RUB2"] = "руб";
$MESS["SCORP_CUR_UAH1"] = "грн.";
$MESS["SCORP_CUR_UAH2"] = "грн";
$MESS["SCORP_CUR_RUB3"] = "р.";
$MESS["SCORP_CUR_RUB4"] = "р";
$MESS["SCORP_CUR_RUB5"] = "ryb.";
$MESS["SCORP_CUR_RUB6"] = "ryb";
$MESS["SCORP_CUR_UAH3"] = "г.";
$MESS["SCORP_CUR_UAH4"] = "г";
$MESS["SCORP_CUR_UAH5"] = "grn.";
$MESS["SCORP_CUR_UAH6"] = "grn";
?>