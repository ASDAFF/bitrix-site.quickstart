<?
$MESS["SPOL_CUR_ORDERS"] = "Посмотреть текущие заказы";
$MESS["SPOL_ORDERS_HISTORY"] = "Посмотреть историю заказов";
$MESS["SPOL_FROM"] = "от";
$MESS["SPOL_NO_ORDERS"] = "Заказы не найдены";
$MESS["SPOL_ORDER"] = "Заказ";
$MESS["SPOL_DATE"] = "Дата";
$MESS["SPOL_ORDER_DETAIL"] = "Подробнее о заказе";
$MESS["SPOL_PAY_SUM"] = "Сумма";
$MESS["SPOL_ACTIONS"] = "Действия";
$MESS["SPOL_CANCELLED"] = "Отменён";
$MESS["SPOL_PAYSYSTEM"] = "Способ оплаты";
$MESS["SPOL_DELIVERY"] = "Доставка";
$MESS["SPOL_BASKET"] = "Состав заказа";
$MESS["SPOL_CANCEL_ORDER"] = "Отменить";
$MESS["SPOL_REPEAT_ORDER"] = "Повторить";
$MESS["SPOL_PAYED"] = "Оплачен";
$MESS["SPOL_SHT"] = "шт.";
$MESS["SPOL_STATUS"] = "Статус";
$MESS["SPOL_ORDERS_ALL"] = "Посмотреть все заказы";
$MESS["SPOL_PSEUDO_CANCELLED"] = "Отменён";
$MESS["SPOL_YES"] = "Да";
$MESS["SPOL_NO"] = "Нет";
$MESS["SPOL_NUM_SIGN"] = "№";
?>