<?
    if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
    
?>
<div class="row">
    <div class="col-md-6 space-right-20">
        <section class="login element-emphasis-strong">
            <h2 class="strong-header large-header">
               <?echo GetMessage("AUTH_TITLE")?>
            </h2>
            <?
        ShowMessage($arParams["~AUTH_RESULT"]);
        ShowMessage($arResult['ERROR_MESSAGE']);
    ?>
            <form name="form_auth" method="post" target="_top" action="<?=SITE_DIR?>auth/<?//=$arResult["AUTH_URL"]?>" class="bx_auth_form" novalidate>
                <input type="hidden" name="AUTH_FORM" value="Y" />
                <input type="hidden" name="TYPE" value="AUTH" />
                <?if (strlen($arParams["BACKURL"]) > 0 || strlen($arResult["BACKURL"]) > 0):?>
                    <input type="hidden" name="backurl" value="<?=($arParams["BACKURL"] ? $arParams["BACKURL"] : $arResult["BACKURL"])?>" />
                    <?endif?>
                <?foreach ($arResult["POST"] as $key => $value):?>
                    <input type="hidden" name="<?=$key?>" value="<?=$value?>" />
                    <?endforeach?>

                <div class="form-group">
                    <label for="login"><?=GetMessage("AUTH_LOGIN")?></label>
                    <input type="text" name="USER_LOGIN" maxlength="255" value="<?=$arResult["LAST_LOGIN"]?>" class="form-control" id="login" required>
                </div>
                <div class="form-group">
                    <label for="password"><?=GetMessage("AUTH_PASSWORD")?></label>
                    <input type="password" name="USER_PASSWORD" class="form-control" id="password" required>
                </div>
                <?if($arResult["CAPTCHA_CODE"]):?>
                    <div class="form-group">
                        <input type="hidden" name="captcha_sid" value="<?echo $arResult["CAPTCHA_CODE"]?>" />
                        <img src="/bitrix/tools/captcha.php?captcha_sid=<?echo $arResult["CAPTCHA_CODE"]?>" width="180" height="40" alt="CAPTCHA" />
                        <?echo GetMessage("AUTH_CAPTCHA_PROMT")?>:
                        <input class="bx-auth-input" type="text" name="captcha_word" maxlength="50" value="" size="15" />
                    </div>
                    <?endif;?>
                <button type="submit" name="Login" value="<?=GetMessage("AUTH_AUTHORIZE")?>" class="btn btn-primary pull-left"><?=GetMessage("AUTH_AUTHORIZE")?></button>
                <?if ($arParams["NOT_SHOW_LINKS"] != "Y"):?>
                    <noindex>
                        <a href="<?=$arParams["AUTH_FORGOT_PASSWORD_URL"] ? $arParams["AUTH_FORGOT_PASSWORD_URL"] : $arResult["AUTH_FORGOT_PASSWORD_URL"]?>" class="btn btn-link pull-right"><?=GetMessage("AUTH_FORGOT_PASSWORD_2")?></a>
                    </noindex>
                    <?endif?>
                <div class="clearfix"></div>
            </form>
        </section>
    </div>
    <div class="col-md-6 space-left-20">
        <section class="element-emphasis-weak">
            <h2 class="strong-header"><?=GetMEssage('AUTH_REGISTER_TITLE')?></h2>
            <p><?=GetMEssage('AUTH_FIRST_ONE')?></p>
            <a href="<?=$arResult['AUTH_REGISTER_URL']?>" class="btn btn-default">
                <?=GetMessage('AUTH_REGISTER')?>
            </a>
        </section>
    </div>
</div>