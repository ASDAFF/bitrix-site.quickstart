<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>
<?if(!empty($arResult['ERRORS']['FATAL'])):
        foreach($arResult['ERRORS']['FATAL'] as $error):
            echo ShowError($error);
            endforeach;
        else:
        if(!empty($arResult['ERRORS']['NONFATAL'])):
            foreach($arResult['ERRORS']['NONFATAL'] as $error):
                echo ShowError($error);
                endforeach;
            endif;
    if(!empty($arResult['ORDERS'])):?>

    <?foreach($arResult["ORDER_BY_STATUS"] as $key => $group): if($group):?>
        <h2 class="strong-header large-header"><?=GetMessage("SPOL_STATUS")?> "<?=$arResult["INFO"]["STATUS"][$key]["NAME"] ?>"</h2>
        <p><?=$arResult["INFO"]["STATUS"][$key]["DESCRIPTION"] ?></p>
        <div class="table table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <td class="width20"><?=GetMessage('SPOL_ORDER')?> <?=GetMessage('SPOL_NUM_SIGN')?></td>
                        <td><?=GetMessage('SPOL_DATE')?></td>
                        <td><?=GetMessage('SPOL_PAY_SUM')?></td>
                        <td><?=GetMessage('SPOL_STATUS')?></td>
                        <td class="text-right width13"><?=GetMessage('SPOL_ACTIONS')?></td>
                    </tr>
                </thead>
                <tbody>
                    <?foreach($group as $k => $order):?>
                        <tr>
                            <td><a href="<?=$order["ORDER"]["URL_TO_DETAIL"]?>"><strong><?=$order["ORDER"]["ACCOUNT_NUMBER"]?></strong></a></td>
                            <td><?=$order["ORDER"]["DATE_INSERT_FORMATED"];?></td>
                            <td><?=$order["ORDER"]["FORMATED_PRICE"]?></td>
                            <td><?=$arResult["INFO"]["STATUS"][$key]["NAME"]?></td>
                            <td class="text-right"><?if($order["ORDER"]["CANCELED"] != "Y"):?>
                                    <a href="<?=$order["ORDER"]["URL_TO_CANCEL"]?>"><?=GetMessage('SPOL_CANCEL_ORDER')?></a>
                                    <?endif?>
                                <a href="<?=$order["ORDER"]["URL_TO_COPY"]?>"><?=GetMessage('SPOL_REPEAT_ORDER')?></a>
                            </td>
                        </tr>
                        <?endforeach?>
                </tbody>
            </table>
        </div>
        <?endif?>
        <?endforeach?>
    <?if(strlen($arResult['NAV_STRING'])):?>
        <?=$arResult['NAV_STRING']?>
        <?endif?>
    <?else:?>
    <?=GetMessage('SPOL_NO_ORDERS')?>
    <?endif?>
<?endif?>