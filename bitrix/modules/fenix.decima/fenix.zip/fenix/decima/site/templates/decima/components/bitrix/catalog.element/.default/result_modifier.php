<?
    if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED!==true) die();
    /** @var CBitrixComponentTemplate $this */
    /** @var array $arParams */
    /** @var array $arResult */
    $displayPreviewTextMode = array(
        'H' => true,
        'E' => true,
        'S' => true
    );
    $detailPictMode = array(
        'IMG' => true,
        'POPUP' => true,
        'MAGNIFIER' => true,
        'GALLERY' => true
    );

    include 'functions.php';

    $arDefaultParams = array(
        'ADD_PICT_PROP' => '-',
        'LABEL_PROP' => '-',
        'OFFER_ADD_PICT_PROP' => '-',
        'OFFER_TREE_PROPS' => array('-'),
        'DISPLAY_NAME' => 'Y',
        'DETAIL_PICTURE_MODE' => 'IMG',
        'ADD_DETAIL_TO_SLIDER' => 'N',
        'DISPLAY_PREVIEW_TEXT_MODE' => 'E',
        'PRODUCT_SUBSCRIPTION' => 'N',
        'SHOW_DISCOUNT_PERCENT' => 'N',
        'SHOW_OLD_PRICE' => 'N',
        'SHOW_MAX_QUANTITY' => 'N',
        'DISPLAY_COMPARE' => 'N',
        'MESS_BTN_BUY' => '',
        'MESS_BTN_ADD_TO_BASKET' => '',
        'MESS_BTN_SUBSCRIBE' => '',
        'MESS_BTN_COMPARE' => '',
        'MESS_NOT_AVAILABLE' => '',
        'USE_VOTE_RATING' => 'N',
        'VOTE_DISPLAY_AS_RATING' => 'rating',
        'USE_COMMENTS' => 'N',
        'BLOG_USE' => 'N',
        'VK_USE' => 'N',
        'VK_API_ID' => '',
        'FB_USE' => 'N',
        'FB_APP_ID' => '',
        'BRAND_USE' => 'N',
        'BRAND_PROP_CODE' => ''
    );
    $arParams = array_merge($arDefaultParams, $arParams);

    $arParams['ADD_PICT_PROP'] = trim($arParams['ADD_PICT_PROP']);
    if ('-' == $arParams['ADD_PICT_PROP'])
        $arParams['ADD_PICT_PROP'] = '';
    $arParams['LABEL_PROP'] = trim($arParams['LABEL_PROP']);
    if ('-' == $arParams['LABEL_PROP'])
        $arParams['LABEL_PROP'] = '';
    $arParams['OFFER_ADD_PICT_PROP'] = trim($arParams['OFFER_ADD_PICT_PROP']);
    if ('-' == $arParams['OFFER_ADD_PICT_PROP'])
        $arParams['OFFER_ADD_PICT_PROP'] = '';
    if (!is_array($arParams['OFFER_TREE_PROPS']))
        $arParams['OFFER_TREE_PROPS'] = $arParams['OFFERS_CART_PROPERTIES'];

    if (empty($arParams['OFFER_TREE_PROPS']) && isset($arParams['OFFERS_CART_PROPERTIES']) && is_array($arParams['OFFERS_CART_PROPERTIES']))
    {
        $arParams['OFFER_TREE_PROPS'] = $arParams['OFFERS_CART_PROPERTIES'];
        foreach ($arParams['OFFER_TREE_PROPS'] as $key => $value)
        {
            $value = (string)$value;
            if ('' == $value || '-' == $value)
                unset($arParams['OFFER_TREE_PROPS'][$key]);
        }
    }

    $arEmptyPreview = false;
    $strEmptyPreview = SITE_TEMPLATE_PATH.'/images/nophoto.png';
    if (file_exists($_SERVER['DOCUMENT_ROOT'].$strEmptyPreview))
    {
        $arSizes = getimagesize($_SERVER['DOCUMENT_ROOT'].$strEmptyPreview);
        if (!empty($arSizes))
        {
            $arEmptyPreview = array(
                'SRC' => $strEmptyPreview,
                'WIDTH' => intval($arSizes[0]),
                'HEIGHT' => intval($arSizes[1])
            );
        }
        unset($arSizes);
    }
    unset($strEmptyPreview);

    $arSKUPropList = array();
    $arSKUPropIDs = array();
    $arSKUPropKeys = array();
    $boolSKU = false;
    $strBaseCurrency = '';
    $boolConvert = isset($arResult['CONVERT_CURRENCY']['CURRENCY_ID']);

    if ($arResult['MODULES']['catalog'])
    {
        if (!$boolConvert)
            $strBaseCurrency = CCurrency::GetBaseCurrency();

        $arSKU = CCatalogSKU::GetInfoByProductIBlock($arParams['IBLOCK_ID']);
        $boolSKU = !empty($arSKU) && is_array($arSKU);

        if ($boolSKU && !empty($arParams['OFFER_TREE_PROPS']))
        {
            $arSKUPropList = CIBlockPriceTools::getTreeProperties(
                $arSKU,
                $arParams['OFFER_TREE_PROPS'],
                array(
                    'PICT' => $arEmptyPreview,
                    'NAME' => '-'
                )
            );
            $arSKUPropIDs = array_keys($arSKUPropList);
        }
    }

    $arResult['CHECK_QUANTITY'] = false;
    if (!isset($arResult['CATALOG_MEASURE_RATIO']))
        $arResult['CATALOG_MEASURE_RATIO'] = 1;
    if (!isset($arResult['CATALOG_QUANTITY']))
        $arResult['CATALOG_QUANTITY'] = 0;
    $arResult['CATALOG_QUANTITY'] = (
        0 < $arResult['CATALOG_QUANTITY'] && is_float($arResult['CATALOG_MEASURE_RATIO'])
        ? floatval($arResult['CATALOG_QUANTITY'])
        : intval($arResult['CATALOG_QUANTITY'])
    );
    $arResult['CATALOG'] = false;
    if (!isset($arResult['CATALOG_SUBSCRIPTION']) || 'Y' != $arResult['CATALOG_SUBSCRIPTION'])
        $arResult['CATALOG_SUBSCRIPTION'] = 'N';

    CIBlockPriceTools::getLabel($arResult, $arParams['LABEL_PROP']);

    $productSlider = CIBlockPriceTools::getSliderForItem($arResult, 'MORE_PHOTO', true);
    if (empty($productSlider))
    {
        $productSlider = array(
            0 => $arEmptyPreview
        );
    }
    $productSliderCount = count($productSlider);
    $arResult['SHOW_SLIDER'] = true;
    $arResult['MORE_PHOTO'] = $productSlider;
    $arResult['MORE_PHOTO_COUNT'] = count($productSlider);

    if ($arResult['MODULES']['catalog'])
    {
        $arResult['CATALOG'] = true;
        if (!isset($arResult['CATALOG_TYPE']))
            $arResult['CATALOG_TYPE'] = CCatalogProduct::TYPE_PRODUCT;
        if (
            (CCatalogProduct::TYPE_PRODUCT == $arResult['CATALOG_TYPE'] || CCatalogProduct::TYPE_SKU == $arResult['CATALOG_TYPE'])
            && !empty($arResult['OFFERS'])
        )
        {
            $arResult['CATALOG_TYPE'] = CCatalogProduct::TYPE_SKU;
        }
        switch ($arResult['CATALOG_TYPE'])
        {
            case CCatalogProduct::TYPE_SET:
                $arResult['OFFERS'] = array();
                $arResult['CATALOG_MEASURE_RATIO'] = 1;
                $arResult['CATALOG_QUANTITY'] = 0;
                $arResult['CHECK_QUANTITY'] = false;
                break;
            case CCatalogProduct::TYPE_SKU:
                break;
            case CCatalogProduct::TYPE_PRODUCT:
            default:
                $arResult['CHECK_QUANTITY'] = ('Y' == $arResult['CATALOG_QUANTITY_TRACE'] && 'N' == $arResult['CATALOG_CAN_BUY_ZERO']);
                break;
        }
    }
    else
    {
        $arResult['CATALOG_TYPE'] = 0;
        $arResult['OFFERS'] = array();
    }

    if ($arResult['CATALOG'] && isset($arResult['OFFERS']) && !empty($arResult['OFFERS']))
    {
        $boolSKUDisplayProps = false;

        $arResultSKUPropIDs = array();
        $arFilterProp = array();
        $arNeedValues = array();
        foreach ($arResult['OFFERS'] as &$arOffer)
        {
            foreach ($arSKUPropIDs as &$strOneCode)
            {
                if (isset($arOffer['DISPLAY_PROPERTIES'][$strOneCode]))
                {
                    $arResultSKUPropIDs[$strOneCode] = true;
                    if (!isset($arFilterProp[$strOneCode]))
                        $arFilterProp[$strOneCode] = $arSKUPropList[$strOneCode];
                }
            }
            unset($strOneCode);
        }
        unset($arOffer);

        CIBlockPriceTools::getTreePropertyValues($arSKUPropList, $arNeedValues);

        $arSKUPropIDs = array_keys($arSKUPropList);
        $arSKUPropKeys = array_fill_keys($arSKUPropIDs, false);


        $arMatrixFields = $arSKUPropKeys;
        $arMatrix = array();

        $arNewOffers = array();

        $arIDS = array();
        $arOfferSet = array();
        $arResult['OFFER_GROUP'] = false;
        $arResult['OFFERS_PROP'] = false;

        $arDouble = array();
        foreach ($arResult['OFFERS'] as $keyOffer => $arOffer)
        {
            $arOffer['ID'] = intval($arOffer['ID']);
            if (isset($arDouble[$arOffer['ID']]))
                continue;
            $arIDS[] = $arOffer['ID'];
            $boolSKUDisplayProperties = false;
            $arOffer['OFFER_GROUP'] = false;
            $arRow = array();
            foreach ($arSKUPropIDs as $propkey => $strOneCode)
            {
                $arCell = array(
                    'VALUE' => 0,
                    'SORT' => PHP_INT_MAX,
                    'NA' => true
                );
                if (isset($arOffer['DISPLAY_PROPERTIES'][$strOneCode]))
                {
                    $arMatrixFields[$strOneCode] = true;
                    $arCell['NA'] = false;
                    if ('directory' == $arSKUPropList[$strOneCode]['USER_TYPE'])
                    {
                        $intValue = $arSKUPropList[$strOneCode]['XML_MAP'][$arOffer['DISPLAY_PROPERTIES'][$strOneCode]['VALUE']];
                        $arCell['VALUE'] = $intValue;
                    }
                    elseif ('L' == $arSKUPropList[$strOneCode]['PROPERTY_TYPE'])
                    {
                        $arCell['VALUE'] = intval($arOffer['DISPLAY_PROPERTIES'][$strOneCode]['VALUE_ENUM_ID']);
                    }
                    elseif ('E' == $arSKUPropList[$strOneCode]['PROPERTY_TYPE'])
                    {
                        $arCell['VALUE'] = intval($arOffer['DISPLAY_PROPERTIES'][$strOneCode]['VALUE']);
                    }
                    $arCell['SORT'] = $arSKUPropList[$strOneCode]['VALUES'][$arCell['VALUE']]['SORT'];
                }
                $arRow[$strOneCode] = $arCell;
            }
            $arMatrix[$keyOffer] = $arRow;

            CIBlockPriceTools::setRatioMinPrice($arOffer);

            $arOffer['MORE_PHOTO'] = array();
            $arOffer['MORE_PHOTO_COUNT'] = 0;
            $offerSlider = CIBlockPriceTools::getSliderForItem($arOffer, $arParams['OFFER_ADD_PICT_PROP'], 'Y' == $arParams['ADD_DETAIL_TO_SLIDER']);
            if (empty($offerSlider))
            {
                $offerSlider = $productSlider;
            }
            $arOffer['MORE_PHOTO'] = $offerSlider;
            $arOffer['MORE_PHOTO_COUNT'] = count($offerSlider);

            $boolSKUDisplayProps = CIBlockPriceTools::clearProperties($arOffer['DISPLAY_PROPERTIES'], $arParams['OFFER_TREE_PROPS']);

            $arDouble[$arOffer['ID']] = true;
            $arNewOffers[$keyOffer] = $arOffer;
        }
        $arResult['OFFERS'] = $arNewOffers;
        $arResult['SHOW_OFFERS_PROPS'] = $boolSKUDisplayProps;

        $arUsedFields = array();
        $arSortFields = array();

        foreach ($arSKUPropIDs as $propkey => $strOneCode)
        {
            $boolExist = $arMatrixFields[$strOneCode];
            foreach ($arMatrix as $keyOffer => $arRow)
            {
                if ($boolExist)
                {
                    if (!isset($arResult['OFFERS'][$keyOffer]['TREE']))
                        $arResult['OFFERS'][$keyOffer]['TREE'] = array();
                    $arResult['OFFERS'][$keyOffer]['TREE']['PROP_'.$arSKUPropList[$strOneCode]['ID']] = $arMatrix[$keyOffer][$strOneCode]['VALUE'];
                    $arResult['OFFERS'][$keyOffer]['SKU_SORT_'.$strOneCode] = $arMatrix[$keyOffer][$strOneCode]['SORT'];
                    $arUsedFields[$strOneCode] = true;
                    $arSortFields['SKU_SORT_'.$strOneCode] = SORT_NUMERIC;
                }
                else
                {
                    unset($arMatrix[$keyOffer][$strOneCode]);

                }
            }
        }
        $arResult['OFFERS_PROP'] = $arUsedFields;
        $arResult['OFFERS_PROP_CODES'] = (!empty($arUsedFields) ? base64_encode(serialize(array_keys($arUsedFields))) : '');

        \Bitrix\Main\Type\Collection::sortByColumn($arResult['OFFERS'], $arSortFields);

        if (!empty($arIDS) && CBXFeatures::IsFeatureEnabled('CatCompleteSet'))
        {
            $rsSets = CCatalogProductSet::getList(
                array(),
                array(
                    '@OWNER_ID' => $arIDS,
                    '=SET_ID' => 0,
                    '=TYPE' => CCatalogProductSet::TYPE_GROUP
                ),
                false,
                false,
                array('ID', 'OWNER_ID')
            );
            while ($arSet = $rsSets->Fetch())
            {
                $arOfferSet[$arSet['OWNER_ID']] = true;
                $arResult['OFFER_GROUP'] = true;
            }
        }

        $arMatrix = array();
        $intSelected = -1;
        $arResult['MIN_PRICE'] = false;
        foreach ($arResult['OFFERS'] as $keyOffer => $arOffer)
        {
            if (empty($arResult['MIN_PRICE']) && $arOffer['CAN_BUY'])
            {
                $intSelected = $keyOffer;
                $arResult['MIN_PRICE'] = (isset($arOffer['RATIO_PRICE']) ? $arOffer['RATIO_PRICE'] : $arOffer['MIN_PRICE']);
            }
            $arSKUProps = false;
            if (!empty($arOffer['DISPLAY_PROPERTIES']))
            {
                $boolSKUDisplayProps = true;
                $arSKUProps = array();
                foreach ($arOffer['DISPLAY_PROPERTIES'] as &$arOneProp)
                {
                    if ('F' == $arOneProp['PROPERTY_TYPE'])
                        continue;
                    $arSKUProps[] = array(
                        'NAME' => $arOneProp['NAME'],
                        'VALUE' => $arOneProp['DISPLAY_VALUE']
                    );
                }
                unset($arOneProp);
            }
            if (isset($arOfferSet[$arOffer['ID']]))
            {
                $arOffer['OFFER_GROUP'] = true;
                $arResult['OFFERS'][$keyOffer]['OFFER_GROUP'] = true;
            }
            reset($arOffer['MORE_PHOTO']);
            $firstPhoto = current($arOffer['MORE_PHOTO']);

        }
        if (-1 == $intSelected)
            $intSelected = 0;
        $arResult['OFFERS_SELECTED'] = $intSelected;

        $arResult['OFFERS_IBLOCK'] = $arSKU['IBLOCK_ID'];
    }

    if ($arResult['MODULES']['catalog'] && $arResult['CATALOG'] && CCatalogProduct::TYPE_PRODUCT == $arResult['CATALOG_TYPE'])
    {
        CIBlockPriceTools::setRatioMinPrice($arResult, true);
    }

    $arResult['SKU_PROPS'] = $arSKUPropList;
    if($arResult['SKU_PROPS'] && $arResult['OFFERS']){
        foreach($arResult['SKU_PROPS'] as $keyP=>$arProp){
            if($arProp['VALUES'])foreach($arProp['VALUES'] as $keyV=>$arVal){ 
                $bool=false;
                foreach($arResult['OFFERS'] as $arOffer){
                    if($arOffer['TREE']['PROP_'.$arProp['ID']]==$arVal['ID']){
                        foreach($arOffer['TREE'] as $id=>$ar){
                          $arResult['SKU_PROPS'][$keyP]['VALUES'][$keyV]['PROPS'][$id][]=$ar;  
                        }
                        unset($arResult['SKU_PROPS'][$keyP]['VALUES'][$keyV]['PROPS']['PROP_'.$arProp['ID']]);
                        $bool=true;   
                    }
                }
                if(!$bool || $arVal['ID']==0)unset($arResult['SKU_PROPS'][$keyP]['VALUES'][$keyV]);
            }
            if(empty($arResult['SKU_PROPS'][$keyP]['VALUES']))unset($arResult['SKU_PROPS'][$keyP]);
        }
    }

    $arResult['DEFAULT_PICTURE'] = $arEmptyPreview;
    $nophoto=array(
        'BIG'=>Array('SRC'=>$file['src'], 'WIDTH'=>1000, 'HEIGHT'=>1000),
        'SMALL'=>Array('SRC'=>$file['src'], 'WIDTH'=>105, 'HEIGHT'=>134),
        'MEDIUM'=>Array('SRC'=>$file['src'], 'WIDTH'=>450, 'HEIGHT'=>574)

    );
    if($arResult['PREVIEW_PICTURE'])$img=is_array($arResult['PREVIEW_PICTURE'])?$arResult['PREVIEW_PICTURE']['ID']:$arResult['PREVIEW_PICTURE'];
    elseif($arResult['DETAIL_PICTURE'])$img=is_array($arResult['DETAIL_PICTURE'])?$arResult['DETAIL_PICTURE']['ID']:$arResult['DETAIL_PICTURE'];
    elseif($arResult['PROPERTIES']['MORE_PHOTO']['VALUE'])$img=count($arResult['PROPERTIES']['MORE_PHOTO'])?$arResult['PROPERTIES']['MORE_PHOTO']['VALUE'][0]:$arResult['DETAIL_PICTURE'];
    $arResult['SLIDER'][]=imagearray($img);

    if($arResult['PROPERTIES']['MORE_PHOTO']['VALUE'])foreach($arResult['PROPERTIES']['MORE_PHOTO']['VALUE'] as $key=>$photo){
        $arResult['SLIDER'][]=imagearray($photo);
    }
    if(!is_array($arResult['SLIDER']))$arResult['SLIDER'][]=$nophoto;
    if (isset($arResult['OFFERS']) && !empty($arResult['OFFERS'])){
        foreach($arResult['OFFERS'] as $key=>$arItem){
            if($arItem['PREVIEW_PICTURE'])$img=is_array($arItem['PREVIEW_PICTURE'])?$arItem['PREVIEW_PICTURE']['ID']:$arItem['PREVIEW_PICTURE'];
            elseif($arItem['DETAIL_PICTURE'])$img=is_array($arItem['DETAIL_PICTURE'])?$arItem['DETAIL_PICTURE']['ID']:$arItem['DETAIL_PICTURE'];
            elseif($arItem['PROPERTIES']['MORE_PHOTO']['VALUE'])$img=count($arItem['PROPERTIES']['MORE_PHOTO'])?$arItem['PROPERTIES']['MORE_PHOTO']['VALUE'][0]:$arItem['DETAIL_PICTURE'];
            $arResult['OFFERS'][$key]['SLIDER'][]=imagearray($img);

            if($arItem['PROPERTIES']['MORE_PHOTO']['VALUE'])foreach($arItem['PROPERTIES']['MORE_PHOTO']['VALUE'] as $key1=>$photo){
                $arResult['OFFERS'][$key]['SLIDER'][]=imagearray($photo);
            }
            if($arItem['TREE']){
                foreach($arItem['TREE'] as $code=>$val)$class.=$code.'-'.$val.' ';
                $arResult['OFFERS'][$key]['CLASS_SKU']=$class;
                unset($class);
            }

            if(!is_array($arResult['OFFERS'][$key]['SLIDER']))$arResult['OFFERS'][$key]['SLIDER']=$arResult['SLIDER'];
        }  
    }
    
?>