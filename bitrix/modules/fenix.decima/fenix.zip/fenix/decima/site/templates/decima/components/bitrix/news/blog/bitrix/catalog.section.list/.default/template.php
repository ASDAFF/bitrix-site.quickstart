<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
    $this->setFrameMode(true);
    $strSectionEdit = CIBlock::GetArrayByID($arParams["IBLOCK_ID"], "SECTION_EDIT");
    $strSectionDelete = CIBlock::GetArrayByID($arParams["IBLOCK_ID"], "SECTION_DELETE");
    $arSectionDeleteParams = array("CONFIRM" => GetMessage('CT_BCSL_ELEMENT_DELETE_CONFIRM'));
    if($arResult['SECTIONS']):?>
    <h3 class="strong-header"><?=GetMessage('BLOG_CATEGORIES')?>
    </h3>
    <div class="categories-widget">
        <ul class="list-unstyled">
            <?foreach ($arResult['SECTIONS'] as &$arSection):
                    $this->AddEditAction($arSection['ID'], $arSection['EDIT_LINK'], $strSectionEdit);
                    $this->AddDeleteAction($arSection['ID'], $arSection['DELETE_LINK'], $strSectionDelete, $arSectionDeleteParams);
                ?><li id="<? echo $this->GetEditAreaId($arSection['ID']); ?>"><a href="<?=$arSection['SECTION_PAGE_URL']; ?>"><?=$arSection['NAME']?></a><span><? echo $arSection['ELEMENT_CNT']; ?></span></li>
            <?endforeach?>  
        </ul>
    </div>
    <?endif?>