<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
$this->setFrameMode(true);$wish=0;
foreach ($arResult["ITEMS"] as $arItem) if ($arItem["DELAY"]=="Y" && $arItem["CAN_BUY"]=="Y")$wish++;
?>
<button type="button" class="btn btn-link pull-right">
    <span aria-hidden="true" data-icon="&#xe006;"></span> <?=$arResult['COUNT']?> <?=digital($arResult['COUNT'], GetMessage('CART_TOVAR'), GetMessage('CART_TOVARA'), GetMessage('CART_TOVAROV'))?>: <?=$arResult['PRICE_FORMATED']?> <b class="caret"></b>
</button>
<a class="btn btn-link wishlink" href="<?=$arParams['PATH_TO_WISHLIST']?>"><?=GetMessage('CART_WISHLIST')?> (<?=$wish?>)</a>

<div role="complementary">
    <?foreach ($arResult["ITEMS"] as $arItem): if ($arItem["DELAY"]=="N" && $arItem["CAN_BUY"]=="Y"):?>
        <article class="shop-summary-item">
            <img src="<?=$arItem['PICTURE']['SRC']?>" alt="<?=$arItem['NAME']?>">

            <div class="item-info-name-features-price">
                <h4><a href="<?=$arItem['DETAIL_PAGE_URL']?>"><?=$arItem['NAME']?></a></h4>
                <span class="features"><?if($arItem['PROPS'])foreach($arItem['PROPS'] as $key=>$arProp): echo $arProp['VALUE'];
                if(($key+1)<count($arItem['PROPS']))echo ', '; endforeach?></span><br>
                <span class="quantity"><?=$arItem['QUANTITY']?></span><b>&times;</b><span class="price"><?=$arItem['PRICE_FORMATED']?></span>
            </div>
            <form action="<?=$APPLICATION->GetCurPage(true)?>">
                <input type="hidden" name="action" value="DELETEFROMCART">
                <input type="hidden" name="id" value="<?=$arItem['ID']?>">
                <button type="submit" class="close" aria-hidden="true"><span aria-hidden="true" data-icon="&#xe005;"></span></button>
            </form>
        </article>
        <?endif?>
        <?endforeach?>
    <hr>
    <span class="total-price-tag pull-left"><?=GetMessage('CART_TOTAL')?></span><span class="total-price pull-right"><?=$arResult['PRICE_FORMATED']?></span>

    <div class="clearfix"></div>
    <a href="<?=$arParams['PATH_TO_BASKET']?>" class="btn btn-primary btn-block">
        <?=GetMessage('CART_BASKET')?>
    </a>
    <a href="<?=$arParams['PATH_TO_ORDER']?>" class="btn btn-default btn-block">
        <?=GetMessage('CART_ORDER')?>
    </a>
</div>

   