<?
$MESS["CATALOG_QUANTITY"] = "Quantity";
$MESS["CATALOG_QUANTITY_FROM_TO"] = "from #FROM# to #TO#";
$MESS["CATALOG_QUANTITY_FROM"] = "#FROM# and more";
$MESS["CATALOG_QUANTITY_TO"] = "up to #TO#";
$MESS["CATALOG_PRICE_VAT"] = "tax included";
$MESS["CATALOG_PRICE_NOVAT"] = "tax excluded";
$MESS["CATALOG_VAT"] = "Tax rate";
$MESS["CATALOG_NO_VAT"] = "not taxed";
$MESS["CATALOG_VAT_INCLUDED"] = "Tax rate included in price";
$MESS["CATALOG_VAT_NOT_INCLUDED"] = "Tax rate not included in price";
$MESS["CT_BCE_QUANTITY"] = "Quantity";
$MESS["CT_BCE_CATALOG_BUY"] = "Buy";
$MESS["CT_BCE_CATALOG_ADD"] = "Add to cart";
$MESS["CT_BCE_CATALOG_COMPARE"] = "Compare";
$MESS["CT_BCE_CATALOG_NOT_AVAILABLE"] = "not available from stock";
$MESS["OSTATOK"] = "Quantity in stock";
$MESS["COMMENTARY"] = "Comments";
$MESS["ECONOMY_INFO"] = "(Savings - #ECONOMY#)";
$MESS["FULL_DESCRIPTION"] = "Full description";
$MESS["CT_BCE_CATALOG_TITLE_ERROR"] = "Error";
$MESS["CT_BCE_CATALOG_TITLE_BASKET_PROPS"] = "Item properties to pass to shopping cart";
$MESS["CT_BCE_CATALOG_BASKET_UNKNOWN_ERROR"] = "Unknown error adding an item to shopping cart";
$MESS["CT_BCE_CATALOG_BTN_SEND_PROPS"] = "Select";
$MESS["CT_BCE_CATALOG_BTN_MESSAGE_CLOSE"] = "Close";
?>