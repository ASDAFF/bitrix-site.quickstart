<?
$MESS["socserv_as_user"] = "Login As";
$MESS["socserv_as_user_note"] = "You can log in if you are registered at one of these services:";
?>