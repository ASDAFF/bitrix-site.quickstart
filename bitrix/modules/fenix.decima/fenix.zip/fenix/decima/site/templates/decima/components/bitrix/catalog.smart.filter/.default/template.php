<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
$this->setFrameMode(true);

?>
<form name="<?echo $arResult["FILTER_NAME"]."_form"?>" action="<?echo $arResult["FORM_ACTION"]?>" method="get" class="smartfilter">
<div class="shop-list-filters col-sm-4 col-md-3">

  
  <div id="listFilters">
   <?foreach($arResult["HIDDEN"] as $arItem):?>
        <input
            type="hidden"
            name="<?echo $arItem["CONTROL_NAME"]?>"
            id="<?echo $arItem["CONTROL_ID"]?>"
            value="<?echo $arItem["HTML_VALUE"]?>"
        />
    <?endforeach;?>
    <div class="filters-details element-emphasis-weak">
      <!-- ACCORDION -->
      <div class="accordion">
        <div class="panel-group">
         <?foreach($arResult["ITEMS"] as $arItem):?>
            <?if($arItem["PROPERTY_TYPE"] == "N" || isset($arItem["PRICE"])):
              if (!$arItem["VALUES"]["MIN"]["VALUE"] || !$arItem["VALUES"]["MAX"]["VALUE"] || $arItem["VALUES"]["MIN"]["VALUE"] == $arItem["VALUES"]["MAX"]["VALUE"])continue;
           ?>
          <div class="panel panel-default">
            <div class="panel-heading">
              <h4 class="strong-header panel-title">
                <a class="accordion-toggle" data-toggle="collapse" href="#collapse-<?=$arItem['ID']?>"><?=$arItem['NAME']?></a>
              </h4>
            </div>
            <div id="collapse-<?=$arItem['ID']?>" class="panel-collapse collapse in">
              <div class="panel-body">  
              <?
                  if($arItem['CURRENCIES']){
                      foreach($arItem['CURRENCIES'] as $cur=>$name){
                        $crnsy=$cur;
                        break;  
                      }
                  }
                  ?>
                <div class="filters-range" currency="<?=$crnsy?>" min="<?=$arItem["VALUES"]["MIN"]["VALUE"]*1?>" max="<?=$arItem["VALUES"]["MAX"]["VALUE"]*1?>" data-min="<?=$arItem["VALUES"]["MIN"]["HTML_VALUE"]?$arItem["VALUES"]["MIN"]["HTML_VALUE"]*1:$arItem["VALUES"]["MIN"]["VALUE"]*1?>" data-max="<?=$arItem["VALUES"]["MAX"]["HTML_VALUE"]?$arItem["VALUES"]["MAX"]["HTML_VALUE"]*1:$arItem["VALUES"]["MAX"]["VALUE"]*1?>" data-step="1">
                  <div class="filter-widget"></div>
                  <div class="filter-value">
                    <input type="text" name="<?echo $arItem["VALUES"]["MIN"]["CONTROL_NAME"]?>"
                                    id="<?echo $arItem["VALUES"]["MIN"]["CONTROL_ID"]?>"
                                    value="<?echo $arItem["VALUES"]["MIN"]["HTML_VALUE"]?>" class="min">
                    <input type="text" name="<?echo $arItem["VALUES"]["MAX"]["CONTROL_NAME"]?>"
                                    id="<?echo $arItem["VALUES"]["MAX"]["CONTROL_ID"]?>"
                                    value="<?echo $arItem["VALUES"]["MAX"]["HTML_VALUE"]?>" class="max">
                  </div>
                </div>
              </div>
            </div>
          </div>
          <script>
        var cur
          </script>
          <?elseif(!empty($arItem["VALUES"])):?>
          <div class="panel panel-default">
            <div class="panel-heading">
              <h4 class="strong-header panel-title">
                <a class="accordion-toggle" data-toggle="collapse" href="#collapse-<?=$arItem['ID']?>"><?=$arItem['NAME']?></a>
              </h4>
            </div>
            <div id="collapse-<?=$arItem['ID']?>" class="panel-collapse collapse in">
              <div class="panel-body">
                <div class="filters-<?if(strpos($arItem['CODE'], 'SIZE')!==false)echo 'size'; elseif(strpos($arItem['CODE'], 'COLOR')!==false)echo 'color'; else echo 'checkboxes'?> myFilters" data-option-group="<?=$arItem['ID']?>" data-option-type="filter">
                 <?foreach($arItem['VALUES'] as $val=>$ar):?>
                 <div class="form-group" <?if(strpos($arItem['CODE'], 'COLOR')!==false):?>data-toggle="tooltip" data-placement="bottom" title="<?=$ar['NAME']?$ar['NAME']:$ar['VALUE']?>"<?endif?>>
                    <input <?if($ar['CHECKED']):?>checked="checked"<?endif?> value="Y" type="checkbox" class="sr-only" name="<?=$ar['CONTROL_NAME']?>" id="<?echo $ar["CONTROL_ID"]?>" onchange="smartFilter.click(this)">
                    <label for="<?echo $ar["CONTROL_ID"]?>" class="">
                    <?if(strpos($arItem['CODE'], 'SIZE')!==false):?>
                    <abbr title="<?=$ar['NAME']?$ar['NAME']:$ar['VALUE']?>"><?=$ar['NAME']?$ar['NAME']:$ar['VALUE']?></abbr>
                    <?elseif(strpos($arItem['CODE'], 'COLOR')!==false):?>
                    <?=$ar['NAME']?$ar['NAME']:$ar['VALUE']?>
                    <span class="filters-color-swatch" style="background: url(<?=$ar['PICT']?>)"></span>
                    <?else:?>
                    <?=$ar['NAME']?$ar['NAME']:$ar['VALUE']?>
                    <?endif?>
                    </label>
                  </div>
                  <?endforeach?>
                </div>
              </div>
            </div>
          </div>
          <?endif?>
          <?endforeach?>
        </div>
      </div>
      <!-- !ACCORDION -->
    </div>
    <div class="modef" id="modef" <?if(!isset($arResult["ELEMENT_COUNT"])) echo 'style="display:none"';?>>
            <?echo GetMessage("CT_BCSF_FILTER_COUNT", array("#ELEMENT_COUNT#" => '<span id="modef_num">'.intval($arResult["ELEMENT_COUNT"]).'</span>'));?>
            <a id="countlink" href="<?echo $arResult["FILTER_URL"]?>" class="showchild"><?echo GetMessage("CT_BCSF_FILTER_SHOW")?></a>
            <!--<span class="ecke"></span>-->
</div>
  </div>
  <button name="del_filter" value="Y" type="submit" class="btn btn-primary btn-small btn-block"><?=GetMessage('CT_BCSF_DEL_FILTER')?></button>
  <!-- / #listFilters -->
</div>
<input type="hidden" name="set_filter" value="Y" />
 
</form>
<script>
    var smartFilter = new JCSmartFilter('<?echo CUtil::JSEscape($arResult["FORM_ACTION"])?>');
</script>