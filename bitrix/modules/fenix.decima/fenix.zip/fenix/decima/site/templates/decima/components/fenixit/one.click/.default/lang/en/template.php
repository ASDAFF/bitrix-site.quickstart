<?
$MESS['1CB_CAPTION_FIO'] = 'Your name';
$MESS['1CB_CAPTION_EMAIL'] = 'E-mail';
$MESS['1CB_CAPTION_PHONE'] = 'Phone';
$MESS['1CB_CAPTION_SKU_SELECT'] = 'Product properties';
$MESS['1CB_ORDER_LINK'] = 'One click purchase';
$MESS['1CB_FORM_HEADER_CAPTION'] = 'One click purchase';
$MESS['1CB_ORDER_BUTTON_CAPTION'] = 'Purchase';
$MESS['1CB_ERROR_FIO'] = 'Specify your name';
$MESS['1CB_ERROR_EMAIL'] = 'Specify proper e-mail or leave field blank';
$MESS['1CB_ERROR_PHONE'] = 'Specify your phone';
$MESS['1CB_FORMAT_ERROR_PHONE'] = 'Numbers, brackets, spaces, dashes and plus sign are allowed in phone number';
$MESS['1CB_FORMAT_ERROR_EMAIL'] = 'Specify proper e-mail or leave field blank';
$MESS['1CB_ORDER_SUCCESS'] = 'Thank you for your order!';
$MESS['1CB_ORDER_SUCCESS_TEXT'] = 'Our manager will contact you very soon.';
$MESS['1CB_ORDER_ERROR'] = 'Error!';
$MESS['1CB_ANTISPAM'] = 'Antispam test is not passed!';
?>
