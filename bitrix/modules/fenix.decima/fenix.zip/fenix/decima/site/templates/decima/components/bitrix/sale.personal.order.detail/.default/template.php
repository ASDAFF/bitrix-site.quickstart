<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>

<div class="row">

<?if(strlen($arResult["ERROR_MESSAGE"])):?>

        <?=ShowError($arResult["ERROR_MESSAGE"]);?>

<?else:?> 

<section class="col-sm-6 col-md-5">

    <p>
     <?=GetMessage('SPOD_ORDER')?> <?=GetMessage('SPOD_NUM_SIGN')?> <strong><?=$arResult["ACCOUNT_NUMBER"]?></strong> <?=GetMessage("SPOD_FROM")?> <strong><?=$arResult["DATE_INSERT_FORMATED"]?></strong><br>
     <?=GetMessage('SPOD_ORDER_STATUS')?>: <strong><?=$arResult["STATUS"]["NAME"]?> (<?=GetMessage("SPOD_FROM")?> <?=$arResult["DATE_STATUS_FORMATED"]?>)</strong><br>
     <?=GetMessage('SPOD_ORDER_PRICE')?>: <strong><?=$arResult["PRICE_FORMATED"]?> <?if(floatval($arResult["SUM_PAID"])):?>(<?=GetMessage('SPOD_ALREADY_PAID')?>:&nbsp;<?=$arResult["SUM_PAID_FORMATED"]?>)<?endif?></strong><br>
     </p>
       
    <?if($arResult["CANCELED"] == "Y" || $arResult["CAN_CANCEL"] == "Y"):?><p>
    <?=GetMessage('SPOD_ORDER_CANCELED')?>:
    <strong><?if($arResult["CANCELED"] == "Y"):?>
                        <?=GetMessage('SPOD_YES')?> (<?=GetMessage('SPOD_FROM')?> <?=$arResult["DATE_CANCELED_FORMATED"]?>)
                        <?elseif($arResult["CAN_CANCEL"] == "Y"):?>
                        <?=GetMessage('SPOD_NO')?>&nbsp;&nbsp;&nbsp;[<a href="<?=$arResult["URL_TO_CANCEL"]?>"><?=GetMessage("SPOD_ORDER_CANCEL")?></a>]
    <?endif?></strong><br></p>
    <?endif?>
        <?if(intval($arResult["USER_ID"])):?>
                <h3 class="strong-header pull-left"><?=GetMessage('SPOD_ACCOUNT_DATA')?></h3>
                <div class="clearfix"></div><p>
                <?if(strlen($arResult["USER_NAME"])):?> <?=GetMessage('SPOD_ACCOUNT')?>: <strong><?=$arResult["USER_NAME"]?></strong><br><?endif?>
                <?=GetMessage('SPOD_LOGIN')?>: <strong><?=$arResult["USER"]["LOGIN"]?></strong><br>
                <?=GetMessage('SPOD_EMAIL')?>: <strong><a href="mailto:<?=$arResult["USER"]["EMAIL"]?>"><?=$arResult["USER"]["EMAIL"]?></a></strong><br>
        </p><?endif?>
        <h3 class="strong-header pull-left"><?=GetMessage('SPOD_ORDER_PROPERTIES')?></h3>
        <div class="clearfix"></div><p>
           <?=GetMessage('SPOD_ORDER_PERS_TYPE')?>: <strong><?=$arResult["PERSON_TYPE"]["NAME"]?></strong><br>
         
            <?foreach($arResult["ORDER_PROPS"] as $prop):?>
                <?if($prop["SHOW_GROUP_NAME"] == "Y"):?>
                     <h3 class="strong-header pull-left"><?=$prop["GROUP_NAME"]?></h3>
        <div class="clearfix"></div>
                <?endif?>
                 <?=$prop['NAME']?>: <strong>
                    <?if($prop["TYPE"] == "CHECKBOX"):?>
                            <?=GetMessage('SPOD_'.($prop["VALUE"] == "Y" ? 'YES' : 'NO'))?>
                            <?else:?>
                            <?=$prop["VALUE"]?>
                    <?endif?>
                    </strong><br>
            <?endforeach?>
        </p><p>
            <?if(!empty($arResult["USER_DESCRIPTION"])):?>
                <?=GetMessage('SPOD_ORDER_USER_COMMENT')?>: <strong><?=$arResult["USER_DESCRIPTION"]?></strong><br>
            <?endif?>
             </p>
            <h3 class="strong-header pull-left"><?=GetMessage("SPOD_ORDER_PAYMENT")?></h3>
        <div class="clearfix"></div><p>
            
            <?=GetMessage('SPOD_PAY_SYSTEM')?>: <strong> 
                        <?if(intval($arResult["PAY_SYSTEM_ID"])):?>
                        <?=$arResult["PAY_SYSTEM"]["NAME"]?>
                        <?else:?>
                        <?=GetMessage("SPOD_NONE")?>
                        <?endif?></strong><br>
            <strong><?=GetMessage('SPOD_ORDER_PAYED')?>:
                <?if($arResult["PAYED"] == "Y"):?>
                        <?=GetMessage('SPOD_YES')?>
                        (<?=GetMessage('SPOD_FROM')?> <?=$arResult["DATE_PAYED_FORMATED"]?>)
                        <?else:?>
                        <?=GetMessage('SPOD_NO')?>
                        <?if($arResult["CAN_REPAY"]=="Y" && $arResult["PAY_SYSTEM"]["PSA_NEW_WINDOW"] == "Y"):?>
                            &nbsp;&nbsp;&nbsp;[<a href="<?=$arResult["PAY_SYSTEM"]["PSA_ACTION_FILE"]?>" target="_blank"><?=GetMessage("SPOD_REPEAT_PAY")?></a>]
                            <?endif?>
                    <?endif?></strong><br>
                </p>
            <h3 class="strong-header pull-left"><?=GetMessage("SPOD_ORDER_DELIVERY")?>: </h3>
        <div class="clearfix"></div><p>
               <?if(strpos($arResult["DELIVERY_ID"], ":") !== false || intval($arResult["DELIVERY_ID"])):?>
                        <strong><?=$arResult["DELIVERY"]["NAME"]?></strong><br>
                        <?if(intval($arResult['STORE_ID']) && !empty($arResult["DELIVERY"]["STORE_LIST"][$arResult['STORE_ID']])):?>
                            <?$store = $arResult["DELIVERY"]["STORE_LIST"][$arResult['STORE_ID']];?>
                            <?=GetMessage('SPOD_TAKE_FROM_STORE')?>: <strong><?=$store['TITLE']?></strong><br>
                            <?if(!empty($store['DESCRIPTION'])):?>
                               <strong><?=$store['DESCRIPTION']?></strong><br>
                            <?endif?>
                            <?if(!empty($store['ADDRESS'])):?>
                            <?=GetMessage('SPOD_STORE_ADDRESS')?>: <strong><?=$store['ADDRESS']?></strong><br>
                            <?endif?>
                            <?if(!empty($store['SCHEDULE'])):?>
                            <?=GetMessage('SPOD_STORE_WORKTIME')?>: <strong><?=$store['SCHEDULE']?></strong><br>
                            <?endif?>
                            <?if(!empty($store['PHONE'])):?>
                            <?=GetMessage('SPOD_STORE_PHONE')?>: <strong><?=$store['PHONE']?></strong><br>
                            <?endif?>
                            <?if(!empty($store['EMAIL'])):?>
                            <?=GetMessage('SPOD_STORE_EMAIL')?>: <strong><a href="mailto:<?=$store['EMAIL']?>"><?=$store['EMAIL']?></a></strong><br>
                            <?endif?>
                        <?endif?>
               <?else:?>
               <strong><?=GetMessage("SPOD_NONE")?></strong><br>
               <?endif?>
               </p>
            <?if($arResult["TRACKING_NUMBER"]):?>
                <p><?=GetMessage('SPOD_ORDER_TRACKING_NUMBER')?>: <strong><?=$arResult["TRACKING_NUMBER"]?></strong><br></p>
            <?endif?>
            
            <?if($arResult["CAN_REPAY"]=="Y" && $arResult["PAY_SYSTEM"]["PSA_NEW_WINDOW"] != "Y"):?>
              <p>  <?
                            $ORDER_ID = $ID;
                            include($arResult["PAY_SYSTEM"]["PSA_ACTION_FILE"]);
                        ?> </p>
            <?endif?>
            
            
             
    </section>
    <div class="clearfix visible-xs space-30"></div>
    <aside class="col-sm-6 col-md-7">
        <div class="table table-responsive cart-summary">
            <table>
                <thead>
                    <tr>
                        <td colspan="2"><?=GetMessage('SPOD_NAME')?></td>
                        <td class="width16"><?=GetMessage('SPOD_PROPS')?></td>
                        <td class="width16"><?=GetMessage('SPOD_QUANTITY')?></td>
                        <td class="text-right width16"><?=GetMessage('SPOD_PRICE')?></td>
                    </tr>
                </thead>
                <tbody>
                    <?foreach($arResult["BASKET"] as $arItem):?>
                        <tr>
                            <td><a href="<?=$arItem['DETAIL_PAGE_URL']?>">
                                   <?if($arItem['PICTURE']['SRC']):?>
                                        <img src="<?=$arItem['PICTURE']['SRC']?>" width="<?=$arItem['PICTURE']['WIDTH']?>" height="<?=$arItem['PICTURE']['HEIGHT']?>" alt="<?=$arItem['NAME']?>" />
                                   <?endif?>
                                </a>
                            </td>
                            <td>
                                <h4><a href="<?=$arItem['DETAIL_PAGE_URL']?>"><?=$arItem['NAME']?></a></h4>
                           </td>
                            <td>
                                <p class="features">
                                    <?if($arItem['PROPS'])foreach($arItem['PROPS'] as $arProp):?>
                                        <?=$arProp['NAME']?>: <strong><?=$arProp['VALUE']?></strong><br>
                                        <?endforeach?>
                                </p>
                            </td>
                            <td>
                                <?=$arItem['QUANTITY']?>
                            </td>
                            <td style="width: 25.6%;">
                                <strong><?=$arItem['PRICE_FORMATED']?></strong>
                            </td>
                        </tr>
                        <?endforeach?>
                </tbody>
            </table>
        </div>
        <div class="space-30"></div>
        <?if(floatval($arResult["ORDER_WEIGHT"])):?>
                <p><?=GetMessage('SPOD_TOTAL_WEIGHT')?>: <strong><?=$arResult['ORDER_WEIGHT_FORMATED']?></strong><br></p>
            <?endif?>
            <p>
           <?=GetMessage('SPOD_PRODUCT_SUM')?>: <strong><?=$arResult['PRODUCT_SUM_FORMATTED']?></strong><br>
           <?if(strlen($arResult["PRICE_DELIVERY_FORMATED"])):?>
                <?=GetMessage('SPOD_DELIVERY')?>: <strong><?=$arResult["PRICE_DELIVERY_FORMATED"]?></strong><br>
           <?endif?>
           <?foreach($arResult["TAX_LIST"] as $tax):?>
           <?=$tax["TAX_NAME"]?>: <strong><?=$tax["VALUE_MONEY_FORMATED"]?></strong><br>
           <?endforeach?>
            <?if(floatval($arResult["TAX_VALUE"])):?>
                <?=GetMessage('SPOD_TAX')?>: <strong><?=$arResult["TAX_VALUE_FORMATED"]?></strong><br>
            <?endif?>
            <?if(floatval($arResult["DISCOUNT_VALUE"])):?>
              <?=GetMessage('SPOD_DISCOUNT')?>: <strong><?=$arResult["DISCOUNT_VALUE_FORMATED"]?></strong><br>
            <?endif?>
            <?=GetMessage('SPOD_SUMMARY')?>: <strong><?=$arResult["PRICE_FORMATED"]?></strong><br>
            </p>
      <a href="<?=$arResult["URL_TO_LIST"]?>" style="margin-top: 20px;" class="btn btn-default"><?=GetMessage('SPOD_CUR_ORDERS')?></a>  
    </aside>
   
    <?endif?>
</div>
