<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die(); $this->setFrameMode(true);?>
<?if($arResult['ITEMS']):?>
    <section class="row" id="<?=$this->randString()?>">
    <?
    $frame=$this->createFrame($this->randString(), false)->begin(""); 
    
    ?>
        <div class="section-header col-xs-12">
            <hr>
            <h2 class="strong-header">
                <?=$arResult['NAME']?>
            </h2>
        </div>
        <?foreach($arResult["ITEMS"] as $arItem):?>
            <?
                $this->AddEditAction($arItem['ID'], $arItem['EDIT_LINK'], CIBlock::GetArrayByID($arItem["IBLOCK_ID"], "ELEMENT_EDIT"));
                $this->AddDeleteAction($arItem['ID'], $arItem['DELETE_LINK'], CIBlock::GetArrayByID($arItem["IBLOCK_ID"], "ELEMENT_DELETE"), array("CONFIRM" => GetMessage('CT_BNL_ELEMENT_DELETE_CONFIRM')));
            ?>
            <div class="col-sm-4" id="<?=$this->GetEditAreaId($arItem['ID']);?>">
                <div class="shop-item-highlight shop-item-highlight-version-1">
                    <a href="<?=$arItem['PROPERTIES']['LINK']['VALUE']?>">
                        <img src="<?=$arItem['PICTURE']['SRC']?>" alt="<?=$arItem['NAME']?>">
                    </a>
                    <a href="<?=$arItem['PROPERTIES']['LINK']['VALUE']?>" class="item-info-name-data">
                        <div class="item-info-name-data-wrapper">
                            <h4><?=$arItem['NAME']?></h4>
                            <span class="price"><?=$arItem['PROPERTIES']['PRICE']['VALUE']?></span>
                        </div>
                    </a>
                </div>
            </div>
            <div class="clearfix visible-xs space-30"></div>
            <?endforeach?> 
            <?$frame->end();?>
    </section>
<?endif?>