<?
$MESS["CATALOG_QUANTITY"] = "Количество";
$MESS["CATALOG_QUANTITY_FROM_TO"] = "От #FROM# до #TO#";
$MESS["CATALOG_QUANTITY_FROM"] = "От #FROM#";
$MESS["CATALOG_QUANTITY_TO"] = "До #TO#";
$MESS["CATALOG_PRICE_VAT"] = "с НДС";
$MESS["CATALOG_PRICE_NOVAT"] = "без НДС";
$MESS["CATALOG_VAT"] = "НДС";
$MESS["CATALOG_NO_VAT"] = "не облагается";
$MESS["CATALOG_VAT_INCLUDED"] = "НДС включен в цену";
$MESS["CATALOG_VAT_NOT_INCLUDED"] = "НДС не включен в цену";
$MESS["CT_BCE_QUANTITY"] = "Количество";
$MESS["CT_BCE_CATALOG_BUY"] = "Купить";
$MESS["CT_BCE_CATALOG_ADD"] = "В корзину";
$MESS["CT_BCE_CATALOG_COMPARE"] = "Сравнение";
$MESS["CT_BCE_CATALOG_NOT_AVAILABLE"] = "нет на складе";
$MESS["OSTATOK"] = "Остаток";
$MESS["COMMENTARY"] = "Комментарии";
$MESS["ECONOMY_INFO"] = "(Экономия в цене - #ECONOMY#)";
$MESS["FULL_DESCRIPTION"] = "Полное описание";
$MESS["CT_BCE_CATALOG_TITLE_ERROR"] = "Ошибка";
$MESS["CT_BCE_CATALOG_TITLE_BASKET_PROPS"] = "Свойства товара, добавляемые в корзину";
$MESS["CT_BCE_CATALOG_BASKET_UNKNOWN_ERROR"] = "Неизвестная ошибка при добавлении товара в корзину";
$MESS["CT_BCE_CATALOG_BTN_SEND_PROPS"] = "Выбрать";
$MESS["ELEMENT_COMMENT"] = "отзыв";
$MESS["ELEMENT_COMMENTA"] = "отзыва";
$MESS["ELEMENT_COMMENTOV"] = "отзывов";
$MESS["ELEMENT_QTY"] = "Кол-во";
$MESS["ELEMENT_WISH"] = "В избранное";
$MESS["ELEMENT_SHARE"] = "Поделиться:";
$MESS["ELEMENT_DESCR"] = "Описание";
$MESS["ELEMENT_CHAR"] = "Характеристики";
$MESS["ELEMENT_REVIEWS"] = "Отзывы";
$MESS["WRITE_COMMENT"] = "Оставить отзыв";
$MESS["SIZE_TABLE"] = "Таблица размеров";

?>