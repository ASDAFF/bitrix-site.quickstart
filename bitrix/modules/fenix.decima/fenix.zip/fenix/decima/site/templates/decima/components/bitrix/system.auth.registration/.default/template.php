<?
    /**
    * Bitrix Framework
    * @package bitrix
    * @subpackage main
    * @copyright 2001-2014 Bitrix
    */

    /**
    * Bitrix vars
    * @global CMain $APPLICATION
    * @param array $arParams
    * @param array $arResult
    * @param CBitrixComponentTemplate $this
    */

    if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
?>   
<div class="row">
    <div class="col-md-6 space-right-20">
        <section class="element-emphasis-weak">
            <h2 class="strong-header">
                <?=GetMessage('ALREADY_AUTH')?>
            </h2>
            <a href="<?=$arResult["AUTH_AUTH_URL"]?>" class="btn btn-default">
                <?=GetMessage("AUTH_AUTH")?>
            </a>
        </section>
    </div>
    <div class="col-md-6 space-left-20">
        <section class="register element-emphasis-strong">
            <h2 class="strong-header large-header"><?=GetMessage("AUTH_REGISTER")?></h2>
             <?
            ShowMessage($arParams["~AUTH_RESULT"]);

            if($arResult["USE_EMAIL_CONFIRMATION"] === "Y" && is_array($arParams["AUTH_RESULT"]) &&  $arParams["AUTH_RESULT"]["TYPE"] === "OK")
            {
            ?>
            <p><?echo GetMessage("AUTH_EMAIL_SENT")?></p>
            <?
            }
            else
            {
            ?>
            <?if($arResult["USE_EMAIL_CONFIRMATION"] === "Y"):?>
                <p><?echo GetMessage("AUTH_EMAIL_WILL_BE_SENT")?></p>
                <?endif?>
            <form role="form" method="post" action="<?=$arResult["AUTH_URL"]?>" name="bform" novalidate>
                    <?if (strlen($arResult["BACKURL"]) > 0):?>
                        <input type="hidden" name="backurl" value="<?=$arResult["BACKURL"]?>" />
                        <?endif?>
                          <input type="hidden" name="AUTH_FORM" value="Y" />
                    <input type="hidden" name="TYPE" value="REGISTRATION" />

                <div class="form-group">
                    <label for="first-name"><?=GetMessage("AUTH_NAME")?></label>
                    <input type="text" name="USER_NAME" value="<?=$arResult["USER_NAME"]?>" class="form-control" id="first-name" required>
                </div>
                <div class="form-group">
                    <label for="last-name"><?=GetMessage("AUTH_LAST_NAME")?></label>
                    <input type="text" name="USER_LAST_NAME"  value="<?=$arResult["USER_LAST_NAME"]?>" class="form-control" id="last-name" required>
                </div>
                <div class="form-group">
                    <label for="last-name"><?=GetMessage("AUTH_LOGIN_MIN")?></label>
                    <input type="text" name="USER_LOGIN"  value="<?=$arResult["USER_LOGIN"]?>" class="form-control" id="last-name" required>
                </div>
                <div class="form-group">
                    <label for="email"><?=GetMessage("AUTH_EMAIL")?></label>
                    <input type="email" name="USER_EMAIL" value="<?=$arResult["USER_EMAIL"]?>" class="form-control" id="email" required>
                </div>
                <div class="form-group">
                    <label for="password"><?=GetMessage("AUTH_PASSWORD_REQ")?></label>
                    <input type="password" name="USER_PASSWORD" value="<?=$arResult["USER_PASSWORD"]?>" class="form-control" id="password" required>
                </div>
                <div class="form-group">
                    <label for="password-repeat"><?=GetMessage("AUTH_CONFIRM")?></label>
                    <input type="password" class="form-control" name="USER_CONFIRM_PASSWORD" value="<?=$arResult["USER_CONFIRM_PASSWORD"]?>"  id="password-repeat" required>
                </div>
                <?if($arResult["USER_PROPERTIES"]["SHOW"] == "Y"):?>
                        <?=strLen(trim($arParams["USER_PROPERTY_NAME"])) > 0 ? $arParams["USER_PROPERTY_NAME"] : GetMessage("USER_TYPE_EDIT_TAB")?>
                        <?foreach ($arResult["USER_PROPERTIES"]["DATA"] as $FIELD_NAME => $arUserField):?>
                        <div class="form-group"><label><?=$arUserField["EDIT_FORM_LABEL"]?></label>
                            <?$APPLICATION->IncludeComponent(
                                "bitrix:system.field.edit",
                                $arUserField["USER_TYPE"]["USER_TYPE_ID"],
                                array("bVarsFromForm" => $arResult["bVarsFromForm"], "arUserField" => $arUserField, "form_name" => "bform"), null, array("HIDE_ICONS"=>"Y"));?>
                            </div>
                            <?endforeach;?>
                        <?endif;?>
                <?if ($arResult["USE_CAPTCHA"] == "Y"):?>
                <div class="form-group">
                        <label><?=GetMessage("CAPTCHA_REGF_TITLE")?><img src="/bitrix/tools/captcha.php?captcha_sid=<?=$arResult["CAPTCHA_CODE"]?>" width="180" height="40" alt="CAPTCHA" /></label>
                        <input type="hidden" name="captcha_sid" value="<?=$arResult["CAPTCHA_CODE"]?>" />
                        <input type="text" name="captcha_word" class="form-control" maxlength="50" value="" class="input_text_style" /><br />
                        <?endif?>
                <button type="submit" name="Register" value="Y" class="btn btn-primary"><?=GetMessage("AUTH_REGISTER")?></button>
            </form>
             <?
            }
        ?>
        </section>
    </div>
</div>


<script type="text/javascript">
    document.bform.USER_NAME.focus();
</script>