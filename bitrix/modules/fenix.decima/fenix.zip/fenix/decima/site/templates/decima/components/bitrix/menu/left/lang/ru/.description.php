<?
$MESS ['MENU_DOT_DEFAULT_NAME'] = "Вертикальное меню по умолчанию";
$MESS ['MENU_DOT_DEFAULT_DESC'] = "Вертикальное меню по умолчанию";
?>