<?
    if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED!==true) die();
    /** @var CBitrixComponentTemplate $this */
    /** @var array $arParams */
    /** @var array $arResult */       
    $arDefaultParams = array(
        'ADD_PICT_PROP' => 'MORE_PHOTO',
        'OFFER_ADD_PICT_PROP' => 'MORE_PHOTO',
    );
    $arParams['DATABASE_PROPERTY_CODE'][]= 'MORE_PHOTO';
    $arParams = array_merge($arDefaultParams, $arParams);
    include 'functions.php';
      if(!empty($arParams['DATABASE_PROPERTY_CODE'])){
        foreach($arParams['DATABASE_PROPERTY_CODE'] as $prop){
            if($prop){
                $res = CIBlockElement::GetProperty($arParams['IBLOCK_ID'], $arItem['ID'], "sort", "asc", array("CODE" => $prop));
                while ($ob = $res->GetNext()) $arItem['PROPERTIES'][$ob['CODE']]=$ob; 

            }  
        }
        }   
    if (!empty($arResult['ITEMS']))
    {
        $arEmptyPreview = false;
        $strEmptyPreview = SITE_TEMPLATE_PATH.'/images/nophoto.png';
        if (file_exists($_SERVER['DOCUMENT_ROOT'].$strEmptyPreview))
        {
            $arSizes = getimagesize($_SERVER['DOCUMENT_ROOT'].$strEmptyPreview);
            if (!empty($arSizes))
            {
                $arEmptyPreview = array(
                    'SRC' => $strEmptyPreview,
                    'WIDTH' => intval($arSizes[0]),
                    'HEIGHT' => intval($arSizes[1])
                );
            }
            unset($arSizes);
        }
        unset($strEmptyPreview);

        $strBaseCurrency = '';
        $boolConvert = isset($arResult['CONVERT_CURRENCY']['CURRENCY_ID']);

        if ($arResult['MODULES']['catalog'])
        {
            if (!$boolConvert)
                $strBaseCurrency = CCurrency::GetBaseCurrency();
        }

        $arNewItemsList = array();
        foreach ($arResult['ITEMS'] as $key => $arItem)
        {      if(!empty($arParams['DATABASE_PROPERTY_CODE'])){
                foreach($arParams['DATABASE_PROPERTY_CODE'] as $prop){
                    if($prop){
                        $res = CIBlockElement::GetProperty($arParams['IBLOCK_ID'], $arItem['ID'], "sort", "asc", array("CODE" => $prop));
                        while ($ob = $res->GetNext()) $arItem['PROPERTIES'][$ob['CODE']]=$ob; 

                    }  
                }
            }  

            $arItem['CHECK_QUANTITY'] = false;
            if (!isset($arItem['CATALOG_MEASURE_RATIO']))
                $arItem['CATALOG_MEASURE_RATIO'] = 1;
            if (!isset($arItem['CATALOG_QUANTITY']))
                $arItem['CATALOG_QUANTITY'] = 0;
            $arItem['CATALOG_QUANTITY'] = (
                0 < $arItem['CATALOG_QUANTITY'] && is_float($arItem['CATALOG_MEASURE_RATIO'])
                ? floatval($arItem['CATALOG_QUANTITY'])
                : intval($arItem['CATALOG_QUANTITY'])
            );
            $arItem['CATALOG'] = false;


            CIBlockPriceTools::getLabel($arItem, $arParams['LABEL_PROP']);

            $productPictures = CIBlockPriceTools::getDoublePicturesForItem($arItem, $arParams['ADD_PICT_PROP']);
            if (empty($productPictures['PICT']))
                $productPictures['PICT'] = $arEmptyPreview;
            if (empty($productPictures['SECOND_PICT']))
                $productPictures['SECOND_PICT'] = $productPictures['PICT'];

            $arItem['PREVIEW_PICTURE'] = $productPictures['PICT'];
            $arItem['PREVIEW_PICTURE_SECOND'] = $productPictures['SECOND_PICT'];
            $arItem['SECOND_PICT'] = true;
            $arItem['PRODUCT_PREVIEW'] = $productPictures['PICT'];
            $arItem['PRODUCT_PREVIEW_SECOND'] = $productPictures['SECOND_PICT'];
            if($productPictures['PICT']['ID'])$arItem['PICTURE']=resize($productPictures['PICT']['ID'], 'Y', $arParams['DISPLAY_IMG_WIDTH'], $arParams['DISPLAY_IMG_HEIGHT']);
            if($productPictures['SECOND_PICT']['ID'])$arItem['PICTURE_TWO']=resize($productPictures['SECOND_PICT']['ID'], 'Y', $arParams['DISPLAY_IMG_WIDTH'], $arParams['DISPLAY_IMG_HEIGHT']);
            if ($arResult['MODULES']['catalog'])
            {
                $arItem['CATALOG'] = true;
                if (!isset($arItem['CATALOG_TYPE']))
                    $arItem['CATALOG_TYPE'] = CCatalogProduct::TYPE_PRODUCT;
                if (
                    (CCatalogProduct::TYPE_PRODUCT == $arItem['CATALOG_TYPE'] || CCatalogProduct::TYPE_SKU == $arItem['CATALOG_TYPE'])
                    && !empty($arItem['OFFERS'])
                )
                {
                    $arItem['CATALOG_TYPE'] = CCatalogProduct::TYPE_SKU;
                }
                switch ($arItem['CATALOG_TYPE'])
                {
                    case CCatalogProduct::TYPE_SET:
                        $arItem['OFFERS'] = array();
                        $arItem['CATALOG_MEASURE_RATIO'] = 1;
                        $arItem['CATALOG_QUANTITY'] = 0;
                        $arItem['CHECK_QUANTITY'] = false;
                        break;
                    case CCatalogProduct::TYPE_SKU:
                        break;
                    case CCatalogProduct::TYPE_PRODUCT:
                    default:
                        $arItem['CHECK_QUANTITY'] = ('Y' == $arItem['CATALOG_QUANTITY_TRACE'] && 'N' == $arItem['CATALOG_CAN_BUY_ZERO']);
                        break;
                }
            }
            else
            {
                $arItem['CATALOG_TYPE'] = 0;
                $arItem['OFFERS'] = array();
            }

            if ($arItem['CATALOG'] && isset($arItem['OFFERS']) && !empty($arItem['OFFERS']))
            {
                $arItem['MIN_PRICE'] = CIBlockPriceTools::getMinPriceFromOffers(
                    $arItem['OFFERS'],
                    $boolConvert ? $arResult['CONVERT_CURRENCY']['CURRENCY_ID'] : $strBaseCurrency
                );     
                if(is_array($arItem['OFFERS']) && !empty($arItem['OFFERS']))
                    foreach($arItem['OFFERS'] as $arOffer){
                        if($arOffer['MIN_PRICE']['VALUE']==$arItem['MIN_PRICE']['VALUE'] || $arOffer['MIN_PRICE']['DISCOUNT_VALUE']==$arItem['MIN_PRICE']['DISCOUNT_VALUE']){
                            $arItem['ADD_URL']=$arOffer['ADD_URL'];
                        }
                }
            }

            if ($arResult['MODULES']['catalog'] && $arItem['CATALOG'] && CCatalogProduct::TYPE_PRODUCT == $arItem['CATALOG_TYPE'])
            {
                CIBlockPriceTools::setRatioMinPrice($arItem, true);
            }

            $arNewItemsList[$key] = $arItem;
        }
        $arNewItemsList[$key]['LAST_ELEMENT'] = 'Y';
        $arResult['ITEMS'] = $arNewItemsList;
        $arResult['SKU_PROPS'] = $arSKUPropList;
        $arResult['DEFAULT_PICTURE'] = $arEmptyPreview;
  
    }
?>