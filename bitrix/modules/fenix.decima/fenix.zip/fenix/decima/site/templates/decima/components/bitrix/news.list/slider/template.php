<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die(); $this->setFrameMode(true);?>
<?if($arResult["ITEMS"]):?>
<div class="full-width no-space flexslider-full-width" id="<?=$this->randString()?>">
  <div class="flexslider">
    <ul class="slides">
      <!-- FLEXSLIDER SLIDE -->
      <?foreach($arResult["ITEMS"] as $arItem):?>
      <?
    $this->AddEditAction($arItem['ID'], $arItem['EDIT_LINK'], CIBlock::GetArrayByID($arItem["IBLOCK_ID"], "ELEMENT_EDIT"));
    $this->AddDeleteAction($arItem['ID'], $arItem['DELETE_LINK'], CIBlock::GetArrayByID($arItem["IBLOCK_ID"], "ELEMENT_DELETE"), array("CONFIRM" => GetMessage('CT_BNL_ELEMENT_DELETE_CONFIRM')));
    ?>
      <li  style="background-image: url(<?=$arItem['PREVIEW_PICTURE']['SRC']?$arItem['PREVIEW_PICTURE']['SRC']:$arItem['DETAIL_PICTURE']['SRC']?>); min-height: 560px">
        <div id="<?=$this->GetEditAreaId($arItem['ID']);?>" class="container">
          <div class="row">
            <div class="col-sm-4 col-sm-offset-6">
              <br><br><br><br><br><br><br>
              <!-- CALL TO ACTION BOX -->
              <div class="calltoaction-box text-center">
                <h4 class="strong-header"><?=$arItem['NAME']?></h4>
                <p><?=$arItem['PREVIEW_TEXT']?><br><br>
                </p>
                <a href="<?=$arItem['PROPERTIES']['LINK']['VALUE']?>" class="btn btn-primary"><?=$arItem['PROPERTIES']['TEXT']['VALUE']?$arItem['PROPERTIES']['TEXT']['VALUE']:GetMessage('SLIDER_MORE')?></a>
              </div>
              <!-- !CALL TO ACTION BOX -->
            </div>
          </div>
        </div>
      </li>
     <?endforeach?>
    </ul>
    <div class="flexslider-full-width-controls"></div>
  </div>
</div>
<?endif?>