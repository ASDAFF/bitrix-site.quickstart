<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die(); $this->setFrameMode(true);?>

<?if (!empty($arResult)):?>
     <div class="col-md-3 col-sm-6">
        <h3 class="strong-header"><?=$arParams['MENU_TITLE']?></h3>
        <div class="link-widget">
          <ul class="list-unstyled">
          <?foreach($arResult as $arItem): if($arItem['DEPTH_LEVEL']>1)continue;?>
            <li><a href="<?=$arItem["LINK"]?>"><?=$arItem["TEXT"]?></a></li>
           <?endforeach?>
          </ul>
        </div>
      </div>
<?endif?>