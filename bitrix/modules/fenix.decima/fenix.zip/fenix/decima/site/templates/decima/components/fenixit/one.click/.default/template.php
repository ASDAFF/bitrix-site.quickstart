<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
if (empty($arResult['ERRORS']) || !$arParams['USE_DEBUG_MESSAGES']) {
?>
<button id="show-ocb-form" class="btn btn-primary oneclick"><?=GetMessage('1CB_ORDER_LINK')?></button>
<div class="ocb-form" id="ocb-form-wrap">
	<div class="ocb-form-header">
		<div class="ocb-form-header-caption"><?=GetMessage('1CB_FORM_HEADER_CAPTION')?></div>
		<div class="ocb-form-header-close"></div>
	</div>
	<form method="post" id="ocb-form" action="<?=$arResult['SCRIPT_PATH']?>/script.php"><div id="ocb-params">
		<input type="hidden" name="buyMode" value="<?=$arParams['BUY_MODE']?>" />
		<? if (!$arParams['USE_SKU']) {?>
		<input type="hidden" name="itemId" value="<?=$arParams['ELEMENT_ID']?>" />
		<? }
		if (strlen($arParams['DUB'])>0) {?>
		<input type="hidden" name="dubLetter" value="<?=$arParams['DUB']?>" />
		<? }
		if ($arParams['USE_ANTISPAM']) {?>
		<input type="hidden" name="antispam_check" id="ocb_antispam_check" value="Y" />
		<? }?>
		<input type="hidden" name="paysystemId" value="<?=$arParams['DEFAULT_PAYMENT']?>" />
		<input type="hidden" name="deliveryId" value="<?=$arParams['DEFAULT_DELIVERY']?>" />
		<input type="hidden" name="personTypeId" value="<?=$arParams['DEFAULT_PERSON_TYPE']?>" />
		<input type="hidden" name="priceId" value="<?=$arParams['PRICE_ID']?>" />
		<input type="hidden" name="currencyCode" value="<?=$arParams['DEFAULT_CURRENCY']?>" />
		<?=bitrix_sessid_post()?>
<?	foreach($arParams['ORDER_FIELDS'] as $curItem) {
		if ($USER->IsAuthorized()) {
			if ($curItem=='EMAIL')
				$value = $USER->GetEmail();
			elseif ($curItem=='FIO')
				$value = $USER->GetFullName();
			else
				$value = $arResult['USER_PHONE'];
		}?>
		<div class="ocb-form-field">
			<label><?=GetMessage('1CB_CAPTION_'.$curItem)?>
	<?	if (in_array($curItem, $arParams['REQUIRED_ORDER_FIELDS'])) {?><ins>*</ins><? }?>
			</label>
			<input type="text" name="new_order[<?=$curItem?>]" value="<?=$value?>" id="ocb-id-<?=$curItem?>" />
			<div id="ocb-id-<?=$curItem?>-error" class="ocb-error-msg"><?=GetMessage('1CB_ERROR_' . $curItem)?></div>
			<? if($curItem=='PHONE' || $curItem=='EMAIL') {?>
			<div id="ocb-id-<?=$curItem?>-format-error" class="ocb-error-msg"><?=GetMessage('1CB_FORMAT_ERROR_' . $curItem)?></div>
			<? }?>
		</div>
<?	}
	if ($arParams['USE_SKU']) {?>
		<div class="ocb-form-field">
			<input type="hidden" name="useSku" value="Y" />
			<input type="hidden" name="skuCodes" value="<?=$arResult['SKU_PROPERTIES_STRING']?>" />
			<input type="hidden" name="iblockId" value="<?=$arParams['IBLOCK_ID']?>" />
			<label><?=GetMessage('1CB_CAPTION_SKU_SELECT')?></label>
			<select name="itemId">
	<?	foreach($arResult['OFFERS'] as $id => $offer_data) {?>
				<option value="<?=$id?>"><?=$offer_data?></option>
	<?	}?>
			</select>
		</div>
<?	}?>
		<div class="modules-button ptichka">
			<input type="submit" value="<?=GetMessage('1CB_ORDER_BUTTON_CAPTION')?>" id="ocb-form-button" name="ocb_form_button" />
		</div>
		<div class="ocb-form-loader"></div>
	</div></form>
	<div class="ocb-form-result" id="ocb-form-result">
		<div class="ocb-result-icon-success"><?=GetMessage('1CB_ORDER_SUCCESS')?></div>
		<div class="ocb-result-icon-fail"><?=GetMessage('1CB_ORDER_ERROR')?></div>
		<div class="ocb-result-text"><?=GetMessage('1CB_ORDER_SUCCESS_TEXT')?></div>
	</div>
</div>
<?} else {
	if (!empty($arResult['ERRORS'])) {?>
<div class="ocb-debug-messages">
	<?	$i = 0;
		$t = sizeof($arResult['ERRORS']);
		for (; $i < $t; $i++)
			echo($arResult['ERRORS'][$i] . '<br />');?>
</div>
<?	}
}?>
