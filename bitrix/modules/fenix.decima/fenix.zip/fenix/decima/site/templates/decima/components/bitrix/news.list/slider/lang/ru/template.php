<?
$MESS["SLIDER_MORE"] = "Подробнее";
?>