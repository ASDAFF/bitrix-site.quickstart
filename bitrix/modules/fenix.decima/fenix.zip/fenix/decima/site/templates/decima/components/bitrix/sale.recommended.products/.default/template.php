<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
$this->setFrameMode(true);
if($arResult["ITEMS"]):
include 'functions.php';
?>
<p class="inbasket_rec_title"><?=GetMessage('buy_with_this')?>:</p>

<div class="col-xs-12 space-left-10">
<div class="clearfix visible-xs space-30"></div>
<div class="row space-30">
    <?$k=0;foreach ($arResult["ITEMS"] as $arItem):?>
        <div class="col-xs-6 col-sm-4 item" item="<?=$arItem['ID']?>">
            <!-- SHOP FEATURED ITEM -->
            <article class="shop-item shop-item-wishlist overlay-element">
                <div class="overlay-wrapper">
                    <a href="<?=$arItem['DETAIL_PAGE_URL']?>">
                        <img src="<?=$arItem['PICTURE']['SRC']?>" style="padding:<?=margin($arItem['PICTURE']['HEIGHT'], $arParams['DISPLAY_IMG_HEIGHT'], $arItem["PICTURE"]["WIDTH"], $arParams['DISPLAY_IMG_WIDTH'], false)?>" alt="<?=$arItem['NAME']?>">
                    </a>
                    <div class="overlay-contents">
                    <?if($arItem['CAN_BUY']):?>
                        <div class="shop-item-actions">
                            <a href="<?=$APPLICATION->GetCurPageParam('action=ADD2BASKET&id='.$arItem['ID'], array('action', 'id', 'site'))?>" style="margin-top: 15px;" class="btn btn-primary btn-block btn-small buybtn">
                                <?=GetMessage('LIST_TOCART')?>
                            </a>
                        </div>
                        <?endif?>
                    </div>
                </div>
                <header class="item-info-name-features-price">
                    <h4><a href="<?=$arItem['DETAIL_PAGE_URL']?>"><?=$arItem['NAME']?></a></h4>
                   
                </header>
            </article>
            <!-- !SHOP FEATURED ITEM -->
        </div>
        <?endforeach?>
</div>
</div>
<div class="clearfix visible-xs space-30"></div>
<?endif?>