<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
?>
<div class="full-width section-emphasis-2" id="subscribe-form">
<?
$frame = $this->createFrame("subscribe-form", false)->begin();
?>
  <div class="container">
    <section class="row">
      <div class="section-header col-xs-12">
        <hr>
        <h2 class="strong-header">
          <?=GetMessage("subscr_form_title")?>
        </h2>
      </div>
      <div class="col-md-8 col-md-offset-2 text-center">
       <div class="successMessage alert alert-success alert-dismissable" style="display: none">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              Thank You! E-mail was sent.
          </div>
          <div class="errorMessage alert alert-danger alert-dismissable" style="display: none">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              Ups! An error occured. Please try again later.
          </div>
        <div class="newsletter-box">
          
          <form role="form" action="<?=$arResult["FORM_ACTION"]?>" class="form-inline validateIt" data-email-subject="Newsletter Form" data-show-errors="true" data-hide-form="true">
          <?foreach($arResult["RUBRICS"] as $itemID => $itemValue):?>
            <input type="hidden" name="sf_RUB_ID[]" value="<?=$itemValue["ID"]?>"/>
          <?endforeach;?>
           
            <div class="form-group">
              <label class="sr-only" for="newsletter-widget-email-1"><?=GetMessage("subscr_form_email_title")?></label>
              <input type="email" required name="sf_EMAIL" class="form-control" id="newsletter-widget-email-1" placeholder="<?=GetMessage("subscr_form_email_title")?>" value="<?=$arResult["EMAIL"]?>">
            </div>
            <input type="submit" class="btn btn-primary btn-small" name="OK" value="<?=GetMessage("subscr_form_button")?>">
          </form>
        </div>
        <!-- !NEWSLETTER BOX -->

      </div>
    </section>

  </div>

<?
$frame->beginStub();
?>
<div class="container">
    <section class="row">
      <div class="section-header col-xs-12">
        <hr>
        <h2 class="strong-header">
          <?=GetMessage("subscr_form_title")?>
        </h2>
      </div>
      <div class="col-md-8 col-md-offset-2 text-center">
       <div class="successMessage alert alert-success alert-dismissable" style="display: none">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              Thank You! E-mail was sent.
          </div>
          <div class="errorMessage alert alert-danger alert-dismissable" style="display: none">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              Ups! An error occured. Please try again later.
          </div>
        <div class="newsletter-box">

          <form role="form" action="<?=$arResult["FORM_ACTION"]?>" class="form-inline validateIt" data-email-subject="Newsletter Form" data-show-errors="true" data-hide-form="true">
          <?foreach($arResult["RUBRICS"] as $itemID => $itemValue):?>
            <input type="hidden" name="sf_RUB_ID[]" value="<?=$itemValue["ID"]?>"/>
          <?endforeach;?>
           
            <div class="form-group">
              <label class="sr-only" for="newsletter-widget-email-1"><?=GetMessage("subscr_form_email_title")?></label>
              <input type="email" required name="sf_EMAIL" class="form-control" id="newsletter-widget-email-1" placeholder="<?=GetMessage("subscr_form_email_title")?>" value="<?=$arResult["EMAIL"]?>">
            </div>
            <input type="submit" class="btn btn-primary btn-small" name="OK" value="<?=GetMessage("subscr_form_button")?>">
          </form>
        </div>
        <!-- !NEWSLETTER BOX -->

      </div>
    </section>

  </div>
<?
$frame->end();
?>
</div>
