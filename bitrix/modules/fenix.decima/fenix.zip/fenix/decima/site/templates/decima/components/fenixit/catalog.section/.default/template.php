<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
$this->setFrameMode(true); 

if($arResult['ITEMS']):
$type=$arParams['TYPE']?$arParams['TYPE']:'default';
if($type!='default'):?>
<section class="row" id="s<?=$this->randString()?>">  
<?endif;
$lineCount=$arParams['LINE_ELEMENT_COUNT']?$arParams['LINE_ELEMENT_COUNT']:3;
switch($type):
case 'SLIDER_DOUBLE':
case 'SLIDER_FADE':
case 'default':
if($type=='default'):
?>
<div class="col-xs-12">
<div id="isotopeContainer" class="shop-product-list isotope">
<?else:?>
<div class="section-header col-xs-12">
<hr><h2 class="strong-header"><?=GetMessage('LIST_FLAG_'.$arParams['PROPERTY_FILTER'])?></h2>
</div>
<div class="col-md-12">
<div class="flexslider flexslider-nopager row">
    <ul class="slides"> 
        <li class="row">
<?endif?>
            <?$k=0; foreach($arResult['ITEMS'] as $arItem): 
                    $this->AddEditAction($arItem['ID'], $arItem['EDIT_LINK'], CIBlock::GetArrayByID($arParams["IBLOCK_ID"], "ELEMENT_EDIT"));
                    $this->AddDeleteAction($arItem['ID'], $arItem['DELETE_LINK'], CIBlock::GetArrayByID($arParams["IBLOCK_ID"], "ELEMENT_DELETE"), array("CONFIRM" => GetMessage('CT_BCS_TPL_ELEMENT_DELETE_CONFIRM')));
                    $strMainID = $this->GetEditAreaId($arItem['ID']);

                if($k>0 && $k%$lineCount==0 && $type!='default'):?></li><li class="row"><?endif?>
                <div class="<?=$type=='default'?'isotope-item':'col-md-3 col-sm-6 col-xs-12'?> item<?=$arItem['ID']?> item" item="<?=$arItem['ID']?>" id="<?=$strMainID?>">
              
                    <div class="shop-item shop-item-featured overlay-element">
                        <?if($type=='SLIDER_FADE' || $type=='default'):?>
                            <div class="overlay-wrapper">
                                <a href="<?=$arItem['DETAIL_PAGE_URL']?>">
                                    <img src="<?=$arItem['PICTURE']['SRC']?>" alt="<?=$arItem['NAME']?>" style="padding:<?=margin($arItem['PICTURE']['HEIGHT'], $arParams['DISPLAY_IMG_HEIGHT'], $arItem["PICTURE"]["WIDTH"], $arParams['DISPLAY_IMG_WIDTH'], false)?>">
                                </a>
                                <div class="overlay-contents">
                                    <div class="shop-item-actions">
                                        <a href="<?=$arItem['ADD_URL']?>" props="<?=$arParams['OFFERS_CART_PROPERTIES']?urlencode(json_encode($arParams['OFFERS_CART_PROPERTIES'])):''?>" class="btn btn-primary btn-block buybtn">
                                            <?=GetMessage('LIST_TOCART')?>
                                        </a>
                                        <a href="<?=$arItem['DETAIL_PAGE_URL']?>" class="btn btn-default btn-block">
                                            <?=GetMessage('LIST_DETAIL')?>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <?else:?>
                            <div class="flipImage clearfix">
                                <a href="<?=$arItem['DETAIL_PAGE_URL']?>">
                                    <span class="frontImg"><img src="<?=$arItem['PICTURE']['SRC']?>" style="padding:<?=margin($arItem['PICTURE']['HEIGHT'], $arParams['DISPLAY_IMG_HEIGHT'], $arItem["PICTURE"]["WIDTH"], $arParams['DISPLAY_IMG_WIDTH'], false)?>" alt=" "></span>
                                    <span class="backImg"><img src="<?=$arItem['PICTURE_TWO']['SRC']?>" style="padding:<?=margin($arItem['PICTURE_TWO']['HEIGHT'], $arParams['DISPLAY_IMG_HEIGHT'], $arItem["PICTURE_TWO"]["WIDTH"], $arParams['DISPLAY_IMG_WIDTH'], false)?>" alt=" "></span>
                                </a>
                            </div>
                            <?endif?>
                        <div class="item-info-name-price">
                            <h4><a href="<?=$arItem['DETAIL_PAGE_URL']?>"><?=$arItem['NAME']?></a></h4>
                            <?if($arItem['MIN_PRICE']['DISCOUNT_VALUE'] < $arItem['MIN_PRICE']['VALUE']):?>
                                <span class="price-old"><?=$arItem['MIN_PRICE']['PRINT_VALUE']?></span>&nbsp;&nbsp;
                                <span class="price"><?=$arItem['MIN_PRICE']['PRINT_DISCOUNT_VALUE']?></span>
                                <?else:?>
                                <span class="price"><?=$arItem['MIN_PRICE']['PRINT_VALUE']?></span>
                                <?endif?>
                        </div>
                    </div>
         
                </div>
                <?if($type!='default'):?><div class="clearfix visible-xs <?=$k%2!=0?'visible-sm':''?> space-30"></div><?endif?>
                <?$k++;endforeach?>
                <?if($type=='default'):?>
                </div>
</div>
                <?else:?>
        </li>
    </ul>
</div>
</div>
<?endif?>

<?break;?>
<?case 'SIMPLE':?>
<div class="section-header col-xs-12">
<hr><h2 class="strong-header"><?=GetMessage('LIST_FLAG_'.$arParams['PROPERTY_FILTER'])?></h2></div>
<?$k=0; foreach($arResult['ITEMS'] as $arItem): $k++; 
    $this->AddEditAction($arItem['ID'], $arItem['EDIT_LINK'], CIBlock::GetArrayByID($arParams["IBLOCK_ID"], "ELEMENT_EDIT"));
    $this->AddDeleteAction($arItem['ID'], $arItem['DELETE_LINK'], CIBlock::GetArrayByID($arParams["IBLOCK_ID"], "ELEMENT_DELETE"), array("CONFIRM" => GetMessage('CT_BCS_TPL_ELEMENT_DELETE_CONFIRM')));
    $strMainID = $this->GetEditAreaId($arItem['ID']);?>
<div class="col-sm-6 col-md-4 item<?=$arItem['ID']?> item" item="<?=$arItem['ID']?>" id="<?=$strMainID?>">
    <div class="shop-top-rated">
        <a href="<?=$arItem['DETAIL_PAGE_URL']?>">
            <img src="<?=$arItem['PICTURE']['SRC']?>" style="padding:<?=margin($arItem['PICTURE']['HEIGHT'], $arParams['DISPLAY_IMG_HEIGHT'], $arItem["PICTURE"]["WIDTH"], $arParams['DISPLAY_IMG_WIDTH'], false)?>" alt=" ">
        </a>
        <span class="rating" data-score="0"></span>
        <div class="item-info-name-price">
            <h4><a href="<?=$arItem['DETAIL_PAGE_URL']?>"><?=$arItem['NAME']?></a></h4>
            <?if($arItem['MIN_PRICE']['DISCOUNT_VALUE'] < $arItem['MIN_PRICE']['VALUE']):?>
                <span class="price-old"><?=$arItem['MIN_PRICE']['PRINT_VALUE']?></span>&nbsp;&nbsp;
                <span class="price"><?=$arItem['MIN_PRICE']['PRINT_DISCOUNT_VALUE']?></span>
                <?else:?>
                <span class="price"><?=$arItem['MIN_PRICE']['PRINT_VALUE']?></span>
                <?endif?>
        </div>
    </div>
</div>
<div class="clearfix <?=$k%2==0?'visible-sm':''?> <?=$k%3==0?'visible-md visible-lg':''?> visible-xs space-30"></div>
<?endforeach?>
<?break;?>
<?case 'SLIDER_SIMPLE':?>
<div class="section-header col-xs-12">
  <hr>
  <h2 class="strong-header"><?=GetMessage('LIST_FLAG_'.$arParams['PROPERTY_FILTER'])?></h2>
</div>
<div class="col-md-12">
<div class="flexslider flexslider-pager row">
<ul class="slides">
<li>
<?$k=0; foreach($arResult['ITEMS'] as $arItem):  
    $this->AddEditAction($arItem['ID'], $arItem['EDIT_LINK'], CIBlock::GetArrayByID($arParams["IBLOCK_ID"], "ELEMENT_EDIT"));
    $this->AddDeleteAction($arItem['ID'], $arItem['DELETE_LINK'], CIBlock::GetArrayByID($arParams["IBLOCK_ID"], "ELEMENT_DELETE"), array("CONFIRM" => GetMessage('CT_BCS_TPL_ELEMENT_DELETE_CONFIRM')));
    $strMainID = $this->GetEditAreaId($arItem['ID']);?>
    <?if($k>0 && $k%$lineCount==0):?></li><li><?endif?>

  <div class="col-md-2 col-sm-4 col-xs-6 item<?=$arItem['ID']?> item" item="<?=$arItem['ID']?>" id="<?=$strMainID?>">
    <div class="shop-recently-viewed overlay-element">
      <div class="overlay-wrapper">
        <a href="<?=$arItem['DETAIL_PAGE_URL']?>">
          <img src="<?=$arItem['PICTURE']['SRC']?>" style="padding:<?=margin($arItem['PICTURE']['HEIGHT'], $arParams['DISPLAY_IMG_HEIGHT'], $arItem["PICTURE"]["WIDTH"], $arParams['DISPLAY_IMG_WIDTH'], false)?>" alt="<?=$arItem['NAME']?>">
        </a>
        <div class="overlay-contents">
          <div class="shop-item-actions">
            <a href="<?=$arItem['ADD_URL']?>" props="<?=$arParams['OFFERS_CART_PROPERTIES']?urlencode(json_encode($arParams['OFFERS_CART_PROPERTIES'])):''?>" class="btn btn-primary btn-small buybtn">
              <?=GetMessage('LIST_BUY')?>
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?if($k>0 && $k<$lineCount):?><div class="clearfix <?=$k%2!=0?'visible-xs':'visible-sm'?> space-30"></div><?endif?>
<?$k++; endforeach?>
</li>
</ul>
</div>
</div>
<?break;?>
<?endswitch?>
<?if ($arParams["DISPLAY_BOTTOM_PAGER"]):?>
<div class="col-md-12 article-wrapper">
<? echo $arResult["NAV_STRING"]; ?>
</div>
<?endif?>
</section>
<?endif?>