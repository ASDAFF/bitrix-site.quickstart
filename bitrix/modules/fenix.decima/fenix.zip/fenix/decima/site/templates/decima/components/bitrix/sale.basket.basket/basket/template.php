<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
    $arUrls = Array(
        "delete" => $APPLICATION->GetCurPage()."?".$arParams["ACTION_VARIABLE"]."=delete&id=#ID#",
        "delay" => $APPLICATION->GetCurPage()."?".$arParams["ACTION_VARIABLE"]."=delay&id=#ID#",
        "add" => $APPLICATION->GetCurPage()."?".$arParams["ACTION_VARIABLE"]."=add&id=#ID#",
    );
    $normalCount = count($arResult["ITEMS"]["AnDelCanBuy"]);
    if (strlen($arResult["ERROR_MESSAGE"]) == 0 && $normalCount>0)
    {
        
    ?><section class="row" id="basket_items">
        <form method="post" action="<?=POST_FORM_ACTION_URI?>" name="basket_form" id="basket_form" novalidate>
        <?foreach($arResult["ITEMS"]["DelDelCanBuy"] as $arItem):?>
        <input type="hidden" name="DELAY_<?=$arItem['ID']?>" value="Y">
        <?endforeach?>
            <div class="col-xs-12">
                <div class="table table-responsive cart-summary">
                    <table>
                        <thead>
                            <tr>
                                <td colspan="2"><?=GetMessage('SALE_NAME')?></td>
                                <td class="width16"><?=GetMessage('SALE_PROPS')?></td>
                                <td class="width16"><?=GetMessage('SALE_QUANTITY')?></td>
                                <td class="text-right width16"><?=GetMessage('SALE_SUM')?></td>
                            </tr>
                        </thead>
                        <tbody>
                            <?foreach($arResult["ITEMS"]["AnDelCanBuy"] as $arItem):?>
                                <tr id="<?=$arItem["ID"]?>">
                                    <td><?
                                            if (strlen($arItem["PREVIEW_PICTURE_SRC"]) > 0):
                                                $url = $arItem["PREVIEW_PICTURE_SRC"];
                                                elseif (strlen($arItem["DETAIL_PICTURE_SRC"]) > 0):
                                                $url = $arItem["DETAIL_PICTURE_SRC"];
                                                else:
                                                $url = SITE_TEMPLATE_PATH."/images/nophoto.png";
                                                endif;
                                        ?>
                                        <a href="<?=$arItem['DETAIL_PAGE_URL']?>">
                                            <img src="<?=$url?>" alt="<?=$arItem['NAME']?>">
                                        </a>
                                    </td>
                                    <td>
                                        <h4><a href="<?=$arItem['DETAIL_PAGE_URL']?>"><?=$arItem['NAME']?></a></h4>
 <?if($arItem['PRICE'] < $arItem['FULL_PRICE']):?>
                                <span class="price-old"><?=$arItem['FULL_PRICE_FORMATED']?></span>&nbsp;&nbsp;
                                <span class="price"><?=$arItem['PRICE_FORMATED']?></span>
                                <?else:?>
                                <span class="price"><?=$arItem['PRICE_FORMATED']?></span>
                                <?endif?>
                                          <br><br>
                                        <a href="<?=str_replace("#ID#", $arItem["ID"], $arUrls["delay"])?>"><?=GetMessage("SALE_DELAY")?></a>&nbsp;&nbsp;&nbsp;
                                        <a href="<?=str_replace("#ID#", $arItem["ID"], $arUrls["delete"])?>"><?=GetMessage("SALE_DELETE")?></a>
                                    </td>
                                    <td class="props">
                                       
                                        <?
                                    if (is_array($arItem["SKU_DATA"]) && !empty($arItem["SKU_DATA"])):
                                        foreach ($arItem["SKU_DATA"] as $propId => $arProp):

                                            // if property contains images or values
                                            $isImgProperty = false;
                                            if (array_key_exists('VALUES', $arProp) && is_array($arProp["VALUES"]) && !empty($arProp["VALUES"]))
                                            {
                                                foreach ($arProp["VALUES"] as $id => $arVal)
                                                {
                                                    if (isset($arVal["PICT"]) && !empty($arVal["PICT"]))
                                                    {
                                                        $isImgProperty = true;
                                                        break;
                                                    }
                                                }
                                            }

                                            $full = (count($arProp["VALUES"]) > 5) ? "full" : "";

                                            if ($isImgProperty): // iblock element relation property
                                            ?>
                                                <div class="bx_item_detail_scu_small_noadaptive <?=$full?>">

                                                    <span class="bx_item_section_name_gray">
                                                        <?=$arProp["NAME"]?>:
                                                    </span>

                                                    <div class="bx_scu_scroller_container">

                                                        <div class="bx_scu">
                                                            <ul id="prop_<?=$arProp["CODE"]?>_<?=$arItem["ID"]?>"
                                                                style="width: 200%; margin-left:0%;"
                                                                class="sku_prop_list"
                                                                >
                                                                <?
                                                                foreach ($arProp["VALUES"] as $valueId => $arSkuValue):

                                                                    $selected = "";
                                                                    foreach ($arItem["PROPS"] as $arItemProp):
                                                                        if ($arItemProp["CODE"] == $arItem["SKU_DATA"][$propId]["CODE"])
                                                                        {
                                                                            if ($arItemProp["VALUE"] == $arSkuValue["NAME"] || $arItemProp["VALUE"] == $arSkuValue["XML_ID"])
                                                                                $selected = "bx_active";
                                                                        }
                                                                    endforeach;
                                                                ?>
                                                                    <li style="width:10%;"
                                                                        class="sku_prop <?=$selected?>"
                                                                        data-value-id="<?=$arSkuValue["XML_ID"]?>"
                                                                        data-element="<?=$arItem["ID"]?>"
                                                                        data-property="<?=$arProp["CODE"]?>"
                                                                        >
                                                                        <a href="javascript:void(0);">
                                                                            <span style="background-image:url(<?=$arSkuValue["PICT"]["SRC"]?>)"></span>
                                                                        </a>
                                                                    </li>
                                                                <?
                                                                endforeach;
                                                                ?>
                                                            </ul>
                                                        </div>

                                                        <div class="bx_slide_left" onclick="leftScroll('<?=$arProp["CODE"]?>', <?=$arItem["ID"]?>);"></div>
                                                        <div class="bx_slide_right" onclick="rightScroll('<?=$arProp["CODE"]?>', <?=$arItem["ID"]?>);"></div>
                                                    </div>

                                                </div>
                                            <?
                                            else:
                                            ?>
                                                <div class="bx_item_detail_size_small_noadaptive <?=$full?>">

                                                    <span class="bx_item_section_name_gray">
                                                        <?=$arProp["NAME"]?>:
                                                    </span>

                                                    <div class="bx_size_scroller_container">
                                                        <div class="bx_size">
                                                            <ul id="prop_<?=$arProp["CODE"]?>_<?=$arItem["ID"]?>"
                                                                style="width: 200%; margin-left:0%;"
                                                                class="sku_prop_list"
                                                                >
                                                                <?
                                                                foreach ($arProp["VALUES"] as $valueId => $arSkuValue):

                                                                    $selected = "";
                                                                    foreach ($arItem["PROPS"] as $arItemProp):
                                                                        if ($arItemProp["CODE"] == $arItem["SKU_DATA"][$propId]["CODE"])
                                                                        {
                                                                            if ($arItemProp["VALUE"] == $arSkuValue["NAME"])
                                                                                $selected = "bx_active";
                                                                        }
                                                                    endforeach;
                                                                ?>
                                                                    <li style="width:10%;"
                                                                        class="sku_prop <?=$selected?>"
                                                                        data-value-id="<?=$arSkuValue["NAME"]?>"
                                                                        data-element="<?=$arItem["ID"]?>"
                                                                        data-property="<?=$arProp["CODE"]?>"
                                                                        >
                                                                        <a href="javascript:void(0);"><?=$arSkuValue["NAME"]?></a>
                                                                    </li>
                                                                <?
                                                                endforeach;
                                                                ?>
                                                            </ul>
                                                        </div>
                                                        <div class="bx_slide_left" onclick="leftScroll('<?=$arProp["CODE"]?>', <?=$arItem["ID"]?>);"></div>
                                                        <div class="bx_slide_right" onclick="rightScroll('<?=$arProp["CODE"]?>', <?=$arItem["ID"]?>);"></div>
                                                    </div>

                                                </div>
                                            <?
                                            endif;
                                        endforeach;
                                    endif;
                                    ?>
                                            <?/*if($arItem['PROPS'])foreach($arItem['PROPS'] as $arProp):?>
                                                <?=$arProp['NAME']?>: <strong><?=$arProp['VALUE']?></strong><br>
                                            <?endforeach*/?>
                                      
                                    </td>
                                    <td>
                                        <input type="text" onchange="document.getElementById('basket_form').submit(); alert();" class="form-control spinner-quantity" name="QUANTITY_<?=$arItem["ID"]?>" id="quantity1" value="<?=$arItem['QUANTITY']?>" required>
                                    </td>
                                    <td class="text-right">
                                        <strong><?=$arItem['SUM']?></strong>
                                    </td>
                                </tr>
                                <?endforeach?>
                        </tbody>
                    </table>
                </div>
            </div><div class="col-sm-6 col-md-4 form-inline"><?if ($arParams["HIDE_COUPON"] != "Y"):?><div class="form-group">
                    <label for="promo-code" class="sr-only"><?=GetMessage("STB_COUPON_PROMT")?></label>
                    <input type="text" class="form-control" id="coupon" name="COUPON" value="<?=$arResult["COUPON"]?>" placeholder="<?=GetMessage("STB_COUPON_PROMT")?>">
                </div><button style="width: 99px;" type="submit" name="BasketRefresh" value="Y" class="btn btn-primary btn-small refresh"><?=GetMessage('SALE_REFRESH')?></button><?endif?></div>
            <div class="col-sm-6 col-md-4 col-md-offset-4">
                <div class="table">
                    <table class="price-calc">
                        <tbody>
                            <?if ($arParams["PRICE_VAT_SHOW_VALUE"] == "Y"):?>
                                <tr>
                                    <td><?echo GetMessage('SALE_VAT_EXCLUDED')?></td>
                                    <td class="text-right" id="allSum_wVAT_FORMATED"><?=$arResult["allSum_wVAT_FORMATED"]?></td>
                                </tr>
                                <tr>
                                    <td><?echo GetMessage('SALE_VAT_INCLUDED')?></td>
                                    <td class="text-right" id="allVATSum_FORMATED"><?=$arResult["allVATSum_FORMATED"]?></td>
                                </tr>
                                <?endif;?>

                            <tr class="order-total">
                                <td class="fwb"><?=GetMessage("SALE_TOTAL")?></td>
                                <td class="text-right" id="allSum_FORMATED"><?=str_replace(" ", "&nbsp;", $arResult["allSum_FORMATED"])?></td>
                            </tr>
                            <tr>
                                <td class="custom_t1"><?=GetMessage("SALE_TOTAL_FULL")?></td>
                                <td class="text-right" style="text-decoration:line-through; color:#828282;" id="PRICE_WITHOUT_DISCOUNT">
                                    <?if (floatval($arResult["DISCOUNT_PRICE_ALL"]) > 0):?>
                                        <?=$arResult["PRICE_WITHOUT_DISCOUNT"]?>
                                        <?endif;?>
                                </td>
                            </tr>

                        </tbody>
                    </table>
                </div>
            </div>
            <div class="col-xs-12">
                <a href="<?=SITE_DIR?>" type="button" class="btn btn-default pull-left"><?=GetMessage('SALE_MAIN')?></a>
                <button type="submit" name="BasketOrder" value="Y" class="btn btn-primary pull-right"><?=GetMessage('SALE_ORDER')?></button>
               
            </div>
            <?if($_REQUEST['AJAX_CALL']=='Y'):?>
            <script>
            
            if (jQuery().spinner) {
            var config = {
                '.spinner': {},
                '.spinner-quantity': {min: 1}
            };
            for (var selector in config) {
                jQuery(selector).spinner(config[selector]);
            }
        }</script>
        <?endif?>
        <input type="hidden" id="column_headers" value="<?=CUtil::JSEscape(implode($arHeaders, ","))?>" />
    <input type="hidden" id="offers_props" value="<?=CUtil::JSEscape(implode($arParams["OFFERS_PROPS"], ","))?>" />
    <input type="hidden" id="action_var" value="<?=CUtil::JSEscape($arParams["ACTION_VARIABLE"])?>" />
    <input type="hidden" id="quantity_float" value="<?=$arParams["QUANTITY_FLOAT"]?>" />
    <input type="hidden" id="count_discount_4_all_quantity" value="<?=($arParams["COUNT_DISCOUNT_4_ALL_QUANTITY"] == "Y") ? "Y" : "N"?>" />
    <input type="hidden" id="price_vat_show_value" value="<?=($arParams["PRICE_VAT_SHOW_VALUE"] == "Y") ? "Y" : "N"?>" />
    <input type="hidden" id="hide_coupon" value="<?=($arParams["HIDE_COUPON"] == "Y") ? "Y" : "N"?>" />
    <input type="hidden" id="coupon_approved" value="N" />
    <input type="hidden" id="use_prepayment" value="<?=($arParams["USE_PREPAYMENT"] == "Y") ? "Y" : "N"?>" />

        </form>
    </section>
    <div class="oneorder">
    <?$APPLICATION->IncludeComponent(
    "bitrix:main.include",
    "",
    Array(
        "AREA_FILE_SHOW" => "page",
        "AREA_FILE_SUFFIX" => "oneclick",
        "EDIT_TEMPLATE" => ""
    )
);?>
    
</div>
    <?
    }
    else
    {?>
    <div class="row shop-cart-empty">
        <div class="col-xs-12">
            <h1 class="strong-header"><?=GetMessage('SALE_EMPTY')?></h1>
            <p><?=GetMessage('SALE_EMPTY')?></p>
            <a href="<?=SITE_DIR?>" class="btn btn-primary"><?=GetMessage('SALE_MAIN')?></a>
        </div>
    </div>

    <?}
?>