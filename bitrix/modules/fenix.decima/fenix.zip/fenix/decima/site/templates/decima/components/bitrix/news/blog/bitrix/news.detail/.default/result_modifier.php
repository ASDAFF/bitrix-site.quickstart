<?
        $img=$arResult['~PREVIEW_PICTURE']?$arResult['~PREVIEW_PICTURE']:$arResult['~DETAIL_PICTURE'];
        if($img){
           $file = CFile::ResizeImageGet($img, array('width'=>680, 'height'=>330), BX_RESIZE_IMAGE_PROPORTIONAL, true, false, false, 100); 
        }
        else{
        $arEmptyPreview = false;
        $strEmptyPreview = SITE_TEMPLATE_PATH.'/images/nophoto.png';
        if (file_exists($_SERVER['DOCUMENT_ROOT'].$strEmptyPreview))
        {
            $arSizes = getimagesize($_SERVER['DOCUMENT_ROOT'].$strEmptyPreview);
            if (!empty($arSizes))
            {
                $file = array(
                    'src' => $strEmptyPreview,
                    'width' => intval($arSizes[0]),
                    'height' => intval($arSizes[1])
                );
            }
            unset($arSizes);
        }
        unset($strEmptyPreview);
        }
        $arResult['PICTURE']=Array('ID'=>$img, 'SRC'=>$file['src'], 'BIG_SRC'=>CFile::GetPath($img), 'WIDTH'=>$file['width'], 'HEIGHT'=>$file['height']); 
        unset($img);
        unset($file);
?>