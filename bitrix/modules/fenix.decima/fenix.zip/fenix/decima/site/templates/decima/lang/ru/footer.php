<?
$MESS['FOOTER_HELP']='Помощь';
$MESS['FOOTER_COMPANY']='Компания';
$MESS['FOOTER_PERSONAL']='Кабинет';
$MESS['FOOTER_SOCIAL']='Соц. сети';
?>