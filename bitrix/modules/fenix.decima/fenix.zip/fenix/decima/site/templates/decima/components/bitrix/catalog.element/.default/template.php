<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
    $this->setFrameMode(true);
    $strMainID = $this->GetEditAreaId($arResult['ID']);
?>
<div class="col-md-6 space-right-20" id="<? echo $arItemIDs['ID']; ?>">
    <?if (!isset($arResult['OFFERS']) || empty($arResult['OFFERS'])):?>
        <div class="thumbnailSlider">
            <div class="flexslider flexslider-thumbnails">
                <ul class="slides">
                    <?if($arResult['SLIDER']):?>
                        <?foreach($arResult['SLIDER'] as $arImg):?>
                            <li><a href="<?=$arImg['BIG']['SRC']?>" data-rel="prettyPhotoGallery[product]">
                                    <img style="padding:<?=margin($arImg['MEDIUM']['HEIGHT'], 574, $arImg['MEDIUM']["WIDTH"], 450)?>" src="<?=$arImg['MEDIUM']['SRC']?>" alt=" ">
                            </a></li>
                            <?endforeach?>
                        <?endif?>
                </ul>
            </div>
            <ul class="smallThumbnails clearfix">
                <?if($arResult['SLIDER']):?>
                    <?foreach($arResult['SLIDER'] as $key=>$arImg):?>
                        <li data-target="<?=$key?>" class="<?=$key==0 && $k==1?'active':''?>">
                            <img style="padding:<?=margin($arImg['SMALL']['HEIGHT'], 134, $arImg['SMALL']["WIDTH"], 105)?>" src="<?=$arImg['SMALL']['SRC']?>" alt=" ">
                        </li>
                        <?endforeach?>
                    <?endif?>
            </ul>
        </div>
        <?else:?>
        <?$k==0;foreach($arResult['OFFERS'] as $arOffer): $k++;?>
            <div class="thumbnailSlider offer <?=$arOffer['CLASS_SKU']?> <?=$k!=1?'hide':''?>"  item="<?=$arOffer['ID']?>">
                <div class="flexslider flexslider-thumbnails">
                    <ul class="slides">
                        <?if($arOffer['SLIDER']):?>
                            <?foreach($arOffer['SLIDER'] as $arImg):?>
                                <li>
                                    <a href="<?=$arImg['BIG']['SRC']?>" data-rel="prettyPhotoGallery[product]">
                                        <img style="padding:<?=margin($arImg['MEDIUM']['HEIGHT'], 574, $arImg['MEDIUM']["WIDTH"], 450)?>" src="<?=$arImg['MEDIUM']['SRC']?>" alt=" ">
                                    </a>
                                </li>
                                <?endforeach?>
                            <?endif?>
                </ul>
            </div>
            <ul class="smallThumbnails clearfix">
                <?if($arOffer['SLIDER']):?>
                    <?foreach($arOffer['SLIDER'] as $key=>$arImg):?>
                        <li data-target="<?=$key?>" class="<?=$key==0 && $k==1?'active':''?>">
                            <img style="padding:<?=margin($arImg['SMALL']['HEIGHT'], 134, $arImg['SMALL']["WIDTH"], 105)?>" src="<?=$arImg['SMALL']['SRC']?>" alt=" ">
                        </li>
                        <?endforeach?>
                    <?endif?>
            </ul>
        </div>
        <?endforeach?>
    <?endif?>
</div>
<div class="clearfix visible-sm visible-xs space-30"></div>
<div class="col-md-6 space-left-20">
<header>
    <span class="rating" id="rate<?=$arResult['ID']?>" data-score="5"></span>
    <a href="#reviews" id="rews<?=$arResult['ID']?>"></a>
    <a href="#reviews"><?=GetMessage('WRITE_COMMENT')?></a>
    <h1><?=$arResult['NAME']?></h1>
    <?if (!isset($arResult['OFFERS']) || empty($arResult['OFFERS'])):?>
	<?if (!empty($arResult['PROPERTIES']['ARTNUMBER']['VALUE'])):?>
        <span class="product-code"><?=$arResult['PROPERTIES']['ARTNUMBER']['NAME']?>: <?=$arResult['PROPERTIES']['ARTNUMBER']['VALUE']?></span><br><br>
    <?endif;?>
		<?if($arResult['MIN_PRICE']['DISCOUNT_VALUE']<$arResult['MIN_PRICE']['VALUE']):?>
            <span class="price-old"><?=$arResult['MIN_PRICE']['PRINT_VALUE']?></span>&nbsp;&nbsp;
            <span class="price"><?=$arResult['MIN_PRICE']['PRINT_DISCOUNT_VALUE']?></span>
            <?else:?>
            <span class="price"><?=$arResult['MIN_PRICE']['PRINT_VALUE']?></span>
            <?endif?>
        <?else:?>
        <?$k=0;foreach($arResult['OFFERS'] as $arOffer): $k++;?>
            <div class="offer <?=$arOffer['CLASS_SKU']?> <?=$k!=1?'hide':''?>">
                <span  class="product-code"><?=$arOffer['PROPERTIES']['ARTNUMBER']['NAME']?>: <?=$arOffer['PROPERTIES']['ARTNUMBER']['VALUE']?></span><br><br>
                <?if($arOffer['MIN_PRICE']['DISCOUNT_VALUE']<$arOffer['MIN_PRICE']['VALUE']):?>
                    <span  class="price-old"><?=$arOffer['MIN_PRICE']['PRINT_VALUE']?></span>&nbsp;&nbsp;
                    <span class="price"><?=$arOffer['MIN_PRICE']['PRINT_DISCOUNT_VALUE']?></span>
                    <?else:?>
                    <span class="price"><?=$arOffer['MIN_PRICE']['PRINT_VALUE']?></span>
                    <?endif?>
            </div>
            <?endforeach?>
        <?endif?>
</header>
<form role="form" class="shop-form form-horizontal" action="<?=$APPLICATION->GetCurPage(true)?>" method="post" novalidate>
    <?if (isset($arResult['OFFERS']) && !empty($arResult['OFFERS']) && !empty($arResult['OFFERS_PROP']) && $arResult['SKU_PROPS']):
            foreach ($arResult['SKU_PROPS'] as &$arProp):?>
            <div class="form-group">
                <label class="col-xs-2" for="PROP_<?=$arProp['ID']?>"><?=$arProp['NAME']?></label>
                <div class="col-xs-5">
                    <select class="sku chosen chosen-select-searchless" id="PROP_<?=$arProp['ID']?>">
                        <?foreach ($arProp['VALUES'] as $arOneValue): $class['value']=$arOneValue['ID']; foreach($arOneValue['PROPS'] as $id=>$ar)foreach($ar as $val)$class['PROPS'][$id][]=$val; ?>
                            <option id="PROP_<?=$arProp['ID']?>_<?=$arOneValue['ID']?>" value="<?echo htmlspecialchars_decode(CUtil::PhpToJSObject($class, false, true))?>"><?echo htmlspecialcharsbx($arOneValue['NAME']); ?></option>
                            <?unset($class);endforeach?>
                    </select>
                </div>
                <?if(strpos($arProp['CODE'], 'SIZE')!==false && !$flag): $flag=true;?>
                    <div class="col-xs-3" style="width: 130px;">
                        <a href="#SizeGuide" class="size-guide-toggle"><?=GetMessage('SIZE_TABLE')?></a>
                    </div>
                    <div class="clearfix visible-xs visible-sm"></div>
                    <?endif?>
            </div>
            <?endforeach?>
        <script> 
        </script>
        <?endif?> 
    <div class="size-guide-wrapper form-group visible-xs visible-sm">
        <div class="col-xs-12">
            <div id="SizeGuide">
                <div class="table">
                    <?$APPLICATION->IncludeComponent(
                            "bitrix:main.include",
                            "",
                            Array(
                                "AREA_FILE_SHOW" => "file",
                                "AREA_FILE_SUFFIX" => "inc",
                                "EDIT_TEMPLATE" => "",
                                "PATH" => SITE_DIR."include/sizes.php"
                            )
                        );?>

                </div>
            </div>
        </div>
    </div>
    <div class="form-group">
        <label class="col-xs-2" for="quantity"><?=GetMessage('ELEMENT_QTY')?></label>

        <div class="col-xs-2">
            <?if($arParams['USE_PRODUCT_QUANTITY']=='Y'):?>
                <input class="form-control spinner-quantity" name="<?=$arParams['PRODUCT_QUANTITY_VARIABLE']?>" value="1" id="quantity" required>
                <?endif?>
        </div>
    </div>
    <button type="submit" props="<?=$arParams['OFFERS_CART_PROPERTIES']?urlencode(json_encode($arParams['OFFERS_CART_PROPERTIES'])):''?>" name="<?=$arParams['ACTION_VARIABLE']?>" value="ADD2BASKET" class="btn btn-primary adddetail"><?=GetMessage('CT_BCE_CATALOG_ADD')?></button>

    <button type="submit" name="<?=$arParams['ACTION_VARIABLE']?>" value="ADD2DELAY" class="btn btn-default adddelay"><?=GetMessage('ELEMENT_WISH')?></button>

    <input type="hidden" name="site" value="<?=SITE_ID?>">
    <input type="hidden" id="offerID" name="<?=$arParams['PRODUCT_ID_VARIABLE']?>" value="<?=is_array($arResult['OFFERS']) && !empty($arResult['OFFERS'])?$arResult['OFFERS'][0]['ID']:$arResult['ID']?>">
    <div class="clearfix"></div>
</form>
    <?$APPLICATION->IncludeComponent("fenixit:one.click", ".default", array(
	"IBLOCK_TYPE" => $arParams['IBLOCK_TYPE'],
    "IBLOCK_ID" => $arParams['IBLOCK_ID'],
    "ELEMENT_ID" => $arResult["ID"],
	"USE_QUANTITY" => count($arResult['OFFERS'])>0?"Y":'N',
	"SEF_FOLDERIX" => $arParams["SEF_FOLDER"],
	"ORDER_FIELDS" => array(
		0 => "FIO",
		1 => "PHONE",
		2 => "EMAIL",
	),
	"REQUIRED_ORDER_FIELDS" => array(
		0 => "FIO",
		1 => "PHONE",
		2 => "EMAIL",
	),
	"BUY_MODE" => "ONE",
	"PRICE_ID" => "1",
	"USE_DEBUG_MESSAGES" => "Y",
	"CACHE_TYPE" => "N",
	"USE_ANTISPAM" => "N",
	"USE_SKU" => count($arResult['OFFERS'])>0?"Y":'N',
	"SKU_PROPERTIES_CODES" => $arParams['OFFERS_CART_PROPERTIES'],
	"SKU_COUNT" => "10"
	),
	false
);?>
<div class="shop-product-single-social">
    <span class="social-label pull-left"><?=GetMessage('ELEMENT_SHARE')?></span>

    <div class="social-widget social-widget-mini social-widget-dark">
        <ul class="list-inline">
            <li>
                <a href="https://www.facebook.com/sharer/sharer.php?u=http://<?=$_SERVER['HTTP_HOST']?>"
                    onclick="window.open(this.href, 'facebook-share','width=580,height=296'); return false;"
                    rel="nofollow"
                    title="Facebook"
                    class="fb">
                    <span class="sr-only">Facebook</span>
                </a>
            </li>
            <li>
                <a href="http://twitter.com/share?text=CreateIT&amp;url=http://<?=$_SERVER['HTTP_HOST']?>"
                    onclick="window.open(this.href, 'twitter-share', 'width=550,height=235'); return false;"
                    rel="nofollow"
                    title=" Share on Twitter"
                    class="tw">
                    <span class="sr-only">Twitter</span>
                </a>
            </li>
            <li>
                <a href="https://plus.google.com/share?url=http://<?=$_SERVER['HTTP_HOST']?>"
                    onclick="window.open(this.href, 'google-plus-share', 'width=490,height=530'); return false;"
                    rel="nofollow"
                    title="Google+"
                    class="gp">
                    <span class="sr-only">Google+</span>
                </a>
            </li>
            <li>
                <a href="http://www.pinterest.com/pin/create/button/?url=http://<?=$_SERVER['HTTP_HOST']?>/&amp;media=http://<?=$_SERVER['HTTP_HOST'].SITE_DIR?>include/logo.png&amp;description=<?=$arResult['NAME']?>"
                    onclick="window.open(this.href, 'pinterest-share', 'width=770,height=320'); return false;"
                    rel="nofollow"
                    title="Pinterest"
                    class="pt">
                    <span class="sr-only">Pinterest</span>
                </a>
            </li>
            <li>
                <a href="http://www.linkedin.com/shareArticle?mini=true&amp;url=http://<?=$_SERVER['HTTP_HOST']?>&amp;title=<?=$arResult['NAME']?>&amp;source=<?=$arResult['NAME']?>"
                    onclick="window.open(this.href, 'linkedin-share', 'width=600,height=439'); return false;"
                    rel="nofollow"
                    title="LinkedIn" class="in">
                    <span class="sr-only">LinkedIn</span>
                </a>
            </li>
        </ul>
    </div>
</div>
<div class="tabs">
<ul class="nav nav-tabs">
    <li class="active"><a href="#description" data-toggle="tab"><?=GetMessage('ELEMENT_DESCR')?></a></li>
    <?if(!empty($arResult['DISPLAY_PROPERTIES'])):?><li><a href="#info" data-toggle="tab"><?=GetMessage('ELEMENT_CHAR')?></a></li><?endif?>
    <li><a href="#reviews" data-toggle="tab"><?=GetMessage('ELEMENT_REVIEWS')?> (<span id="revcnt<?=$arResult['ID']?>">0</span>)</a></li>
</ul>

<div class="tab-content">
<div class="tab-pane fade in active" id="description">
    <p><?=$arResult['DETAIL_TEXT']?></p>
	<?if (!empty($arResult['DISPLAY_PROPERTIES']["VIDEO"]["DISPLAY_VALUE"])):?>
	<p><?=$arResult['DISPLAY_PROPERTIES']["VIDEO"]["DISPLAY_VALUE"]?></p>
	<?endif;?>
</div> 
<?if(!empty($arResult['DISPLAY_PROPERTIES'])):?>
    <div class="tab-pane fade" id="info">
        <div class="table table-condensed">
            <table>
                <tbody> 
                    <?
                        foreach ($arResult['DISPLAY_PROPERTIES'] as &$arOneProp):?>
						<?if ($arOneProp["CODE"] != "VIDEO"):?>
                        <tr><th class="weak"><? echo $arOneProp['NAME']; ?></th><?
                                echo '<td>', (
                                    is_array($arOneProp['DISPLAY_VALUE'])
                                    ? implode(' / ', $arOneProp['DISPLAY_VALUE'])
                                    : $arOneProp['DISPLAY_VALUE']
                            ), '</td>';?></tr>
						<?endif;?>
							<?
                            endforeach?>
                </tbody>
            </table>
        </div>
    </div> 
    <?endif?>