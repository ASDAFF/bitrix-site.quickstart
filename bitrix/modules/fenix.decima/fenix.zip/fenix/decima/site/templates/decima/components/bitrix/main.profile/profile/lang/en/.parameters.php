<?
$MESS["USER_PROPERTY_NAME"] = "Extra Properties Tab Title";
?>