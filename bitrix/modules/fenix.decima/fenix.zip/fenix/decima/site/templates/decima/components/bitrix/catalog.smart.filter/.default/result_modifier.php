<?CModule::IncludeModule('highloadblock');   CModule::IncludeModule('iblock'); CModule::IncludeModule('catalog'); 
    //PROPERTIES
    foreach($arResult['ITEMS'] as $key=>$arItem){
        if($arItem['USER_TYPE']=='directory' && !empty($arItem['VALUES'])):
            $hlblock = \Bitrix\Highloadblock\HighloadBlockTable::getList(array("filter" => array('TABLE_NAME' => $arItem['USER_TYPE_SETTINGS']['TABLE_NAME'])))->fetch();
            if (!isset($hlblock['ID']))
                continue;
            $arValues = array();
            $entity = \Bitrix\Highloadblock\HighloadBlockTable::compileEntity($hlblock);
            $entity_data_class = $entity->getDataClass();
            $rsPropEnums = $entity_data_class::getList(array());
            while ($arEnum = $rsPropEnums->fetch())
            {
                if (!isset($arEnum['UF_NAME'])) break;
                $arEnum['PREVIEW_PICTURE'] = false;
                $file = CFile::ResizeImageGet($arEnum['UF_FILE'], array('width'=>28, 'height'=>28), BX_RESIZE_IMAGE_EXACT, true);                
                $arEnum['PREVIEW_PICTURE'] = $file['src'];
                $arValues[$arEnum['UF_XML_ID']] = array(
                    'ID' => $arEnum['ID'],
                    'NAME' => $arEnum['UF_NAME'],
                    'SORT' => intval($arEnum['UF_SORT']),
                    'XML_ID' => $arEnum['UF_XML_ID'],
                    'PICT' =>  $arEnum['PREVIEW_PICTURE']
                );
                if(array_key_exists($arEnum['UF_XML_ID'], $arItem['VALUES']))
                    $arResult['ITEMS'][$key]['VALUES'][$arEnum['UF_XML_ID']]=array_merge($arItem['VALUES'][$arEnum['UF_XML_ID']], $arValues[$arEnum['UF_XML_ID']]);
            }

            endif;
    }
    //--PROPERTIES
    //--COUNTER
    $mxResult = CCatalogSKU::GetInfoByProductIBlock($arParams['IBLOCK_ID']);
    if (is_array($mxResult)) $offerIB=$mxResult['IBLOCK_ID'];
    $productFilter=Array("IBLOCK_ID"=>$arParams['IBLOCK_ID'], 'INCLUDE_SUBSECTIONS'=>'Y', "ACTIVE"=>"Y");
    $offersFilter=Array("IBLOCK_ID"=>$offerIB, 'INCLUDE_SUBSECTIONS'=>'Y', "ACTIVE"=>"Y");
    if($arParams['SECTION_ID'])$productFilter['SECTION_ID']=$arParams['SECTION_ID'];
    $f=$GLOBALS[$arParams['FILTER_NAME']];
    $priceF['><CATALOG_PRICE_1']=$f['><CATALOG_PRICE_1'];
    unset($f['><CATALOG_PRICE_1']);
    if(is_array($f))$productFilter=array_merge($f, $productFilter);
    if(is_array($priceF))$offersFilter=array_merge($priceF, $offersFilter);
    if(is_array($f['OFFERS']))$offersFilter=array_merge($f['OFFERS'], $offersFilter);


    foreach($arResult["ITEMS"] as $key => $arItem){
        $curProductFilter=$productFilter;
        $curOffersFilter=$offersFilter;
        if(!$arItem['PRICE'] && !empty($arItem["VALUES"]))
            foreach($arItem["VALUES"] as $val => $ar){
                unset($propFilter);
                if($ar['CHECKED'])$arResult["ITEMS"][$key]['CHECKED']=1;
                if($arItem['USER_TYPE']=='directory')$name=$ar['XML_ID'];
                else $name=$ar['VALUE'];
                if($arItem['PROPERTY_TYPE'] == 'S')$name=htmlspecialchars_decode($name);
                if($arItem['PROPERTY_TYPE'] == 'L')$propFilter["PROPERTY_".$arItem['CODE'].'_VALUE']=$name;
                else $propFilter["PROPERTY_".$arItem['CODE']]=$name;
                
                $cnt=0;
                if(array_key_exists('=PROPERTY_'.$arItem['ID'], $curProductFilter)){
                    unset($curProductFilter['=PROPERTY_'.$arItem['ID']]); 
                }
                if($arParams['IBLOCK_ID']!=$arItem['IBLOCK_ID']){
                    if(is_array($curOffersFilter))$curOffersFilter=array_merge($curOffersFilter, $propFilter);
                    else $curOffersFilter=$propFilter;
                }
                else {
                     if(is_array($curProductFilter))$curProductFilter=array_merge($curProductFilter, $propFilter);
                     else $curProductFilter=$propFilter;
                }
                $curProductFilter["ID"] = CIBlockElement::SubQuery("PROPERTY_CML2_LINK", array($curOffersFilter));
                $res = CIBlockElement::GetList(Array(), $curProductFilter, false, false, Array("ID", "NAME"));
                while($arFields = $res->GetNext()){
                    $cnt++;   
                } 
               if($cnt==0) $arResult["ITEMS"][$key]["VALUES"][$val]['DISABLED']=1;
                $arResult["ITEMS"][$key]["VALUES"][$val]['COUNT']=$cnt;
                unset($cnt);
        }
    }

?>