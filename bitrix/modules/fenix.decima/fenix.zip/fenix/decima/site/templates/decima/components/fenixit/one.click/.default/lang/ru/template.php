<?
$MESS['1CB_CAPTION_FIO'] = 'Ваше имя';
$MESS['1CB_CAPTION_PHONE'] = 'Контактный телефон';
$MESS['1CB_CAPTION_EMAIL'] = 'E-mail';
$MESS['1CB_CAPTION_SKU_SELECT'] = 'Свойства товара';
$MESS['1CB_ORDER_LINK'] = 'Купить в 1 клик';
$MESS['1CB_FORM_HEADER_CAPTION'] = 'Купить в 1 клик';
$MESS['1CB_ORDER_BUTTON_CAPTION'] = 'Отправить заказ';
$MESS['1CB_ERROR_FIO'] = 'Обязательно укажите ваше имя';
$MESS['1CB_ERROR_EMAIL'] = 'Укажите правильный e-mail или оставьте поле пустым';
$MESS['1CB_ERROR_PHONE'] = 'Обязательно укажите контактный телефон';
$MESS['1CB_FORMAT_ERROR_PHONE'] = 'В номере телефона допускаются только цифры, скобки, пробелы, знак плюса и тире';
$MESS['1CB_FORMAT_ERROR_EMAIL'] = 'Укажите правильный e-mail или оставьте поле пустым';
$MESS['1CB_ORDER_SUCCESS'] = 'Спасибо за заказ!';
$MESS['1CB_ORDER_SUCCESS_TEXT'] = 'В ближайшее время наш менеджер свяжется с вами.';
$MESS['1CB_ORDER_ERROR'] = 'Ошибка!';
$MESS['1CB_ANTISPAM'] = 'Проверка на антиспам не пройдена'
?>
