<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();$this->setFrameMode(true);?>
<?if($arResult["FORM_TYPE"] == "login"):?>
    <a href="<?=SITE_DIR?>auth/" class="btn btn-link pull-left btn-login"><?=GetMessage("AUTH_LOGIN_BUTTON")?></a>
    <?else:?>
    <form action="<?=$arResult["AUTH_URL"]?>" style="display: inline;position: absolute; margin: 0;">
        <a href="<?=$arResult["PROFILE_URL"]?>" title="<?=GetMessage("AUTH_PROFILE")?>"><?=$arResult["USER_NAME"]?> [<?=$arResult["USER_LOGIN"]?>]</a>
        <?foreach ($arResult["GET"] as $key => $value):?>
            <input type="hidden" name="<?=$key?>" value="<?=$value?>" />
            <?endforeach?>
        <input type="hidden" name="logout" value="yes" />
        <button type="submit" name="logout_butt" value="Y" class="btn btn-primary btn-small"><?=GetMessage("AUTH_LOGOUT_BUTTON")?></button>
    </form>
    <?endif?>
