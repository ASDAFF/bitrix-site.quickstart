<?
$MESS ['subscr_form_email_title'] = "Введите ваш e-mail";
$MESS ['subscr_form_button'] = "Подписаться";
$MESS ['subscr_form_title'] = "Подписаться на новости";
?>