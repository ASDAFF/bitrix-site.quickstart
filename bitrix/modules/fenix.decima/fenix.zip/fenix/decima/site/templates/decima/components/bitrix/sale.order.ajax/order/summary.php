<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>
<?if($arResult['BASKET_ITEMS']):?>
    <div class="col-sm-5 col-sm-push-7 space-left-30">
        <section class="order-summary element-emphasis-weak">
            <h3 class="strong-header element-header pull-left"><?=GetMessage("SALE_PRODUCTS_SUMMARY");?></h3>
            <a href="<?=$arParams['PATH_TO_BASKET']?>" class="pull-right"><?=GetMessage("SALE_BASKET");?></a>
            <div class="clearfix"></div>
            <!-- SHOP SUMMARY ITEM -->
            <?foreach($arResult['BASKET_ITEMS'] as $arItem):?>
                <article class="shop-summary-item">
                    <?if (strlen($arItem["PREVIEW_PICTURE_SRC"]) > 0):
                            $url = $arItem["PREVIEW_PICTURE_SRC"];
                            elseif (strlen($arItem["DETAIL_PICTURE_SRC"]) > 0):
                            $url = $arItem["DETAIL_PICTURE_SRC"];
                            else:
                            $url = $templateFolder."/images/no_photo.png";
                            endif;?>
                    <img src="<?=$url?>"  alt="<?=$arItem['NAME']?>">
                    <header class="item-info-name-features-price">
                        <h4><a href="04-shop-product-single.html"><?=$arItem['NAME']?></a></h4>
                        <span class="features"><?if($arItem['PROPS'])foreach($arItem['PROPS'] as $key=>$arProp): echo $arProp['VALUE'];
                                if(($key+1)<count($arItem['PROPS']))echo ', '; endforeach?></span><br>
                    <span class="quantity"><?=$arItem['QUANTITY']?></span><b>&times;</b><span class="price"><?=$arItem['SUM']?></span>
                </header>
            </article>
            <?endforeach?>
            <!-- !SHOP SUMMARY ITEM -->


            <dl class="order-summary-price">
                <dt><?=GetMessage("SOA_TEMPL_SUM_SUMMARY")?></dt>
                <dd><strong><?=$arResult["ORDER_PRICE_FORMATED"]?></strong></dd>
                <?if (doubleval($arResult["DISCOUNT_PRICE"]) > 0){?>
                    <dt><?=GetMessage("SOA_TEMPL_SUM_DISCOUNT")?>
                        <?if (strLen($arResult["DISCOUNT_PERCENT_FORMATED"])>0):?> (<?echo $arResult["DISCOUNT_PERCENT_FORMATED"];?>)<?endif;?>:</dt>
                    <dd><strong><?echo $arResult["DISCOUNT_PRICE_FORMATED"]?></strong></dd><?
                    }
                    if(!empty($arResult["TAX_LIST"]))
                    {
                        foreach($arResult["TAX_LIST"] as $val)
                        {
                        ?>
                        <dt><?=$val["NAME"]?> <?=$val["VALUE_FORMATED"]?>:</dt>
                        <dd><strong><?=$val["VALUE_MONEY_FORMATED"]?></strong></dd><?
                        }
                    }
                    if (doubleval($arResult["DELIVERY_PRICE"]) > 0)
                    {
                    ?>
                    <dt><?=GetMessage("SOA_TEMPL_SUM_DELIVERY")?></dt>
                    <dd><strong><?=$arResult["DELIVERY_PRICE_FORMATED"]?></strong></dd>
                    <?
                    }
                    if (strlen($arResult["PAYED_FROM_ACCOUNT_FORMATED"]) > 0)
                    {
                    ?>
                    <dt><?=GetMessage("SOA_TEMPL_SUM_PAYED")?></dt>
                    <dd><strong><?=$arResult["PAYED_FROM_ACCOUNT_FORMATED"]?></strong></dd><?
                    }

                    if ($bUseDiscount):
                    ?>
                    <dt class="total-price"><?=GetMessage("SOA_TEMPL_SUM_IT")?></dt>
                    <dd class="total-price"><strong><?=$arResult["ORDER_TOTAL_PRICE_FORMATED"]?> (<span style="text-decoration:line-through; color:#828282;"><?=$arResult["PRICE_WITHOUT_DISCOUNT"]?></span>)</strong></dd>
                    <?
                        else:
                    ?>
                    <dt class="total-price"><?=GetMessage("SOA_TEMPL_SUM_IT")?></dt>
                    <dd class="total-price"><strong><?=$arResult["ORDER_TOTAL_PRICE_FORMATED"]?></strong></dd><?
                        endif;?>
            </dl>
        </section>
    </div> 
    <div class="clearfix visible-xs space-30"></div>
<?endif?>