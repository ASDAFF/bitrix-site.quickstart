<?
$MESS["TP_BST_SHOW_INPUT"] = "Show Search Query Input Form";
$MESS["TP_BST_INPUT_ID"] = "Search Query Input Element ID";
$MESS["TP_BST_CONTAINER_ID"] = "Layout Container ID (to confine search results by width)";
?>