<?
$MESS['1CB_NO_FIO'] = "Не указано имя.";
$MESS['1CB_NO_PHONE'] = "Не указан или неправильно указан телефон.";
$MESS['1CB_BAD_EMAIL_FORMAT'] = "Указан неправильный e-mail";
$MESS['1CB_AUTH_FAIL'] = "Ошибка авторизации";
$MESS['1CB_TOO_MANY_USERS'] = "Найдено более 1 пользователя с указанным email.";
$MESS['1CB_ORDER_CREATE_FAIL'] = "Ошибка создания заказа.";
$MESS['1CB_PRODUCT_PRICE_NOT_FOUND'] = "Цена на товар не найдена.";
$MESS['1CB_ITEM_ADD_FAIL'] = "Ошибка добавления товара в заказ.";
$MESS['1CB_ORDER_CREATE_SUCCESS'] = "Заказ успешно оформлен.";
$MESS['1CB_PHONE'] = "Телефон для связи: ";
$MESS['1CB_EMPTY_BASKET'] = '<i id="cart-status"><a href="/personal/cart/">Ваша корзина пуста</a>';
?>
