<?
$MESS["WZD_OPTION_NEWS_1"] = "News Item";
$MESS["WZD_OPTION_NEWS_2"] = "Published";
$MESS["WZD_OPTION_NEWS_3"] = "News Date";
$MESS["WZD_OPTION_NEWS_5"] = "*Title";
$MESS["WZD_OPTION_NEWS_6"] = "Symbolic Code";
$MESS["WZD_OPTION_NEWS_8"] = "Short Description";
$MESS["WZD_OPTION_NEWS_10"] = "Full Description";
?>