<?
$MESS["STORE_NAME_1"] = "World of Furniture";
$MESS["STORE_DESCR_1"] = "Best furniture at best prices";
$MESS["STORE_ADR_1"] = "551 155th Ave";
$MESS["STORE_GPS_N_1"] = "40.7142";
$MESS["STORE_GPS_S_1"] = "-74.0064";
$MESS["STORE_PHONE_1"] = "689 555 8674";
$MESS["CAT_STORE_NAME"] = "Warehouse";
?>