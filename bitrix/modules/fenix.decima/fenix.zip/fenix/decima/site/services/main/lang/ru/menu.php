<?
$MESS["WIZ_MENU_TOP_DEFAULT"] = "Верхнее меню";
$MESS["WIZ_MENU_LIGHT_TOP"] = "Главное левое меню";
?>