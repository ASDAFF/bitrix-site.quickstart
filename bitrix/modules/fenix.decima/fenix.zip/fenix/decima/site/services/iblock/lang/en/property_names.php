<?
$MESS["UF_BROWSER_TITLE"] = "Browser window title";
$MESS["UF_KEYWORDS"] = "Keywords";
$MESS["UF_META_DESCRIPTION"] = "Meta description";
?>