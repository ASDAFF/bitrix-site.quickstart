<?
$MESS ['IDEA_CATEGORY_EDIT_FORM_TAB_TITLE'] = "Раздел"; 
$MESS ['IDEA_CATEGORY_EDIT_FORM_P_ACTIVE'] = "Раздел активен"; 
$MESS ['IDEA_CATEGORY_EDIT_FORM_P_NAME'] = "*Название"; 
$MESS ['IDEA_CATEGORY_EDIT_FORM_P_CODE'] = "*Символьный код"; 
$MESS ['IDEA_CATEGORY_EDIT_FORM_P_IBLOCK_SECTION_ID'] = "Родительский раздел";
$MESS ['IDEA_CATEGORY_EDIT_FORM_P_SORT'] = "Сортировка"; 
?>