<?
$MESS["WZD_OPTION_FAQ_1"] = "Вопрос";
$MESS["WZD_OPTION_FAQ_2"] = "Вопрос опубликован";
$MESS["WZD_OPTION_FAQ_3"] = "Индекс сортировки в списке";
$MESS["WZD_OPTION_FAQ_4"] = "*Вопрос";
$MESS["WZD_OPTION_FAQ_5"] = "Ответ";
$MESS["WZD_OPTION_FAQ_6"] = "Теги";
?>