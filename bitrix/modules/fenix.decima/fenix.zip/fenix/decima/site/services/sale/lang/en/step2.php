<?
$MESS["SALE_WIZARD_GROUP"] = "  ";
$MESS["SALE_WIZARD_MAIL_A"] = "Snail mail";
$MESS["SALE_WIZARD_MAIL_A_DESC"] = "Tariffs of mail and courier services depend on the order weight with an interval of 500 or 1000 gram.";
$MESS["SALE_WIZARD_COUR"] = "Courier";
$MESS["SALE_WIZARD_COUR_DESCR"] = "Delivery will be made within one day at a time convenient for you.";
$MESS["SALE_WIZARD_COUR1"] = "Pick-up by customer";
$MESS["SALE_WIZARD_COUR1_DESCR"] = "You can pick your order yourself at our local store.";
$MESS["SALE_WIZARD_SPSR"] = " ";
$MESS["SALE_WIZARD_SPSR_DESCR"] = " ";
$MESS["SALE_WIZARD_MAIL"] = " ";
$MESS["SALE_WIZARD_MAIL_DESC"] = " ";
$MESS["SALE_WIZARD_UPS"] = "International delivery";
$MESS["SALE_WIZARD_VAT"] = "VAT";
$MESS["SALE_WIZARD_ADMIN_SALE"] = "e-Store administrators";
$MESS["SALE_WIZARD_ADMIN_SALE_DESCR"] = "Full access to e-Store and Commercial Catalog management.";
$MESS["SALE_WIZARD_CONTENT_EDITOR"] = "Content Editors";
$MESS["SALE_WIZARD_CONTENT_EDITOR_DESCR"] = "Allowed to edit site content.";
$MESS["SUBSCR_1"] = "Store news";
$MESS["SUBSCR_2"] = "Daily newsletter";
$MESS["REGISTERED_USERS"] = "Registered users";
$MESS["TASK_WIZARD_CONTENT_EDITOR"] = "Edit personal profile. Cache control";
$MESS["TASK_WIZARD_CONTENT_EDITOR_DESC"] = "User can edit own profile and change cache parameters.";
?>