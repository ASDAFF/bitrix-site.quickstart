<?
$MESS["WIZ_PRICE_NAME"] = "Розничная цена";
$MESS["WIZ_DISCOUNT"] = "Скидка на нижнее белье";
$MESS["WIZ_PRECET"] = "Специальные товары";
?>