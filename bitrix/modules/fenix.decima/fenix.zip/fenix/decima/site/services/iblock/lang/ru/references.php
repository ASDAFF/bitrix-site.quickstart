<?
$MESS["WZD_OPTION_REF_edit1_TAB_TITLE"]="Цвет";
$MESS["WZD_OPTION_REF_NAME"]="*Название";
$MESS["WZD_OPTION_REF_CODE"]="*Символьный код";
$MESS["WZD_OPTION_REF_PREVIEW_PICTURE"]="Картинка";
$MESS["WZD_OPTION_REF_SORT"]="Сортировка";

$MESS["UF_NAME"] = "Название";
$MESS["UF_FILE"] = "Файл";
$MESS["UF_LINK"] = "Ссылка";
$MESS["UF_SORT"] = "Сортировка";
$MESS["UF_DEF"] = "По умолчанию";
$MESS["UF_XML_ID"] = "XML_ID";
$MESS["UF_DESCRIPTION"] = "Описание";
$MESS["UF_FULL_DESCRIPTION"] = "Полное описание";
$MESS["UF_EXTERNAL_CODE"] = "Внешний код";

$MESS["WZD_REF_COLOR_PURPLE"] = "Фиолетовый";
$MESS["WZD_REF_COLOR_BROWN"] = "Коричневый";
$MESS["WZD_REF_COLOR_SEE"] = "Морской Волны";
$MESS["WZD_REF_COLOR_BLUE"] = "Синий";
$MESS["WZD_REF_COLOR_ORANGERED"] = "Оранжевый с Красным";
$MESS["WZD_REF_COLOR_REDBLUE"] = "Красный с Синим";
$MESS["WZD_REF_COLOR_RED"] = "Красный";
$MESS["WZD_REF_COLOR_GREEN"] = "Зеленый";
$MESS["WZD_REF_COLOR_GREY"] = "Серый";
$MESS["WZD_REF_COLOR_WHITE"] = "Белый";
$MESS["WZD_REF_COLOR_BLACK"] = "Черный";
$MESS["WZD_REF_COLOR_PINK"] = "Розовый";
$MESS["WZD_REF_COLOR_AZURE"] = "Голубой";
$MESS["WZD_REF_COLOR_JEANS"] = "Синяя джинса";
$MESS["WZD_REF_COLOR_FLOWERS"] = "Черный с Белым и Цветочки";
$MESS["WZD_REF_COLOR_CORAL"] = "Коралловый";
$MESS["WZD_REF_COLOR_BORDO"] = "Бордовый";
$MESS["WZD_REF_COLOR_MINT"] = "Мятный";
$MESS["WZD_REF_COLOR_LIGHT_PINK"] = "Светлый розовый";
$MESS["WZD_REF_COLOR_YELLOW"] = "Желтый";


?>