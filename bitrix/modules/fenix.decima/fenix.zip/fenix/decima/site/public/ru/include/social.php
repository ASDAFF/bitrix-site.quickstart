<ul class="list-inline">
<li><a href="#" class="fb"><span class="sr-only">Facebook</span></a></li>
<li><a href="#" class="tw"><span class="sr-only">Twitter</span></a></li>
<li><a href="#" class="gp"><span class="sr-only">Google+</span></a></li>
<li><a href="#" class="pt"><span class="sr-only">Pinterest</span></a></li>
<li><a href="#" class="in"><span class="sr-only">LinkedIn</span></a></li>
</ul>