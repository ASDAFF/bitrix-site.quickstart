 <div class="full-width google-map"><?$APPLICATION->IncludeComponent("bitrix:map.google.view", ".default", array(
	"INIT_MAP_TYPE" => "ROADMAP",
	"MAP_DATA" => "a:4:{s:10:\"google_lat\";d:55.82000268648301;s:10:\"google_lon\";d:37.611272611236934;s:12:\"google_scale\";i:16;s:10:\"PLACEMARKS\";a:1:{i:0;a:3:{s:4:\"TEXT\";s:0:\"\";s:3:\"LON\";d:37.611737251282;s:3:\"LAT\";d:55.820066858604;}}}",
	"MAP_WIDTH" => "100%",
	"MAP_HEIGHT" => "350",
	"CONTROLS" => array(
		0 => "SMALL_ZOOM_CONTROL",
		1 => "TYPECONTROL",
		2 => "SCALELINE",
	),
	"OPTIONS" => array(
		0 => "ENABLE_DRAGGING",
	),
	"MAP_ID" => ""
	),
	false
);?></div>