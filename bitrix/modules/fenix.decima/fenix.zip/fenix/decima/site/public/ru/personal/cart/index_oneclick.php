<?$APPLICATION->IncludeComponent("fenixit:one.click", "", array(
    "IBLOCK_TYPE" => "catalog",
    "IBLOCK_ID" => "2",
    "ELEMENT_ID" => "",
    "USE_QUANTITY" => "N",
    "SEF_FOLDERIX" => "#SITE_DIR#catalog/",
    "ORDER_FIELDS" => array(
        0 => "FIO",
        1 => "PHONE",
        2 => "EMAIL",
    ),
    "REQUIRED_ORDER_FIELDS" => array(
        0 => "FIO",
        1 => "PHONE",
        2 => "EMAIL",
    ),
    "DEFAULT_PERSON_TYPE" => "",
    "DEFAULT_DELIVERY" => "0",
    "DEFAULT_PAYMENT" => "0",
    "DEFAULT_CURRENCY" => "RUB",
    "BUY_MODE" => "ALL",
    "PRICE_ID" => "1",
    "DUPLICATE_LETTER_TO_EMAILS" => array(
    ),
    "USE_DEBUG_MESSAGES" => "Y",
    "CACHE_TYPE" => "A",
    "CACHE_TIME" => "864000",
    "USE_JQUERY" => "N",
    "INSERT_ELEMENT" => "#ocb_intaro",
    "USE_ANTISPAM" => "N",
    "USE_SKU" => "N"
    ),
    false
);?>