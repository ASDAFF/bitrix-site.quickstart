<?
$aMenuLinks = Array(
	Array(
		"Как купить", 
		"about/howto/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Доставка", 
		"about/delivery/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Гарантия", 
		"about/guaranty/", 
		Array(), 
		Array(), 
		"" 
	)
);
?>