<?
$sSectionName = "О магазине";
$arDirProperties = array(
);
?>