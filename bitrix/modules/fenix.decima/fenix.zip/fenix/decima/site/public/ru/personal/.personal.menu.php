<?
$aMenuLinks = Array(
	Array(
		"Личные данные", 
		"profile/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Текущие заказы", 
		"order/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"История заказов", 
		"order/?filter_history=Y", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Корзина", 
		"cart/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Изменить подписку", 
		"subscribe/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Избранное", 
		"wishlist/", 
		Array(), 
		Array(), 
		"" 
	)
);
?>