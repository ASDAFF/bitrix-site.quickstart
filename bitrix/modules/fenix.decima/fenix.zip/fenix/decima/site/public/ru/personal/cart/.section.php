<?
$sSectionName = "Моя корзина";
$arDirProperties = array(

);
?>