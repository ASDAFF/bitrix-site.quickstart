<?
$sSectionName = "Настройки пользователя";
$arDirProperties = array(

);
?>