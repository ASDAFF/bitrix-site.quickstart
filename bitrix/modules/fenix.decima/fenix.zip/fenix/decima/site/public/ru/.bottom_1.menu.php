<?
$aMenuLinks = Array(
	Array(
		"О магазине", 
		"about/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Контакты", 
		"about/contacts/", 
		Array(), 
		Array(), 
		"" 
	)
);
?>