<?
$MESS['1CB_NO_FIO'] = 'Name not set.';
$MESS['1CB_NO_PHONE'] = 'Phone not set or bad phone format.';
$MESS['1CB_BAD_EMAIL_FORMAT'] = 'Bad e-mail format';
$MESS['1CB_CURRENCY_NOT_FOUND'] = 'Currency not found';
$MESS['1CB_AUTH_FAIL'] = 'Authorization error';
$MESS['1CB_TOO_MANY_USERS'] = 'More than one user with such email found in the datatbase.';
$MESS['1CB_USER_REGISTER_FAIL'] = 'User register error.';
$MESS['1CB_ORDER_CREATE_FAIL'] = 'Order create error.';
$MESS['1CB_PRODUCT_PRICE_NOT_FOUND'] = "Product's price is not found.";
$MESS['1CB_ITEM_ADD_FAIL'] = 'Error adding product to order.';
$MESS['1CB_ITEM_UPDATE_FAIL'] = 'Error applying order no to product.';
$MESS['1CB_ORDER_CREATE_SUCCESS'] = 'Order successfully.';
$MESS['1CB_PHONE'] = 'Contact phone: ';
$MESS['1CB_EMPTY_BASKET'] = '<i id="cart-status"><a href="/personal/cart/">Your cart is empty</a>';
$MESS['ITEM_NAME'] = "Name: ";
$MESS['ITEM_PRICE'] = ", price: ";
$MESS['ITEM_QTY'] = ", quantity: ";
$MESS['ITEM_TOTAL'] = ", total: ";
$MESS['1CB_ANTISPAM'] = 'Antispam test is not passed';
$MESS['1CB_ORDER_COMMENT'] = 'Order via one-click';
$MESS['1CB_NO_PROPER_DATA'] = 'Not enough input data';?>
