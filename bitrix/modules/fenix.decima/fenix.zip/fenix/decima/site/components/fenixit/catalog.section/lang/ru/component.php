<?
$MESS["IBLOCK_MODULE_NOT_INSTALLED"] = "Модуль Информационных блоков не установлен";
$MESS["CATALOG_SECTION_NOT_FOUND"] = "Раздел не найден.";
$MESS["CATALOG_ERROR2BASKET"] = "Ошибка добавления товара в корзину";
$MESS["CATALOG_PRODUCT_NOT_FOUND"] = "Товар не найден";
$MESS["CATALOG_SUCCESSFUL_ADD_TO_BASKET"] = "Товар успешно добавлен в корзину";
$MESS["CATALOG_PARTIAL_BASKET_PROPERTIES_ERROR"] = "Не все свойства товара, добавляемые в корзину, заполнены";
$MESS["CATALOG_EMPTY_BASKET_PROPERTIES_ERROR"] = "Не заполнены свойства товара, добавляемые в корзину";
?>