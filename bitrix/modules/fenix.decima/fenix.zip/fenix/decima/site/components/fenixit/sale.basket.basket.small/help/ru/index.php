<pre>
Array
(
    [DATE] => Ќ  16.01.2007 ­  ‚ иҐ¬ Ї®«м§®ў вҐ«мбЄ®¬ бзҐвҐ ­ е®¤пвбп б«Ґ¤гойЁҐ баҐ¤бвў :
    [ACCOUNT_LIST] => Array
        (
            [0] => Array
                (
                    [CURRENCY] => Array
                        (
                            [CURRENCY] => RUR
                            [LID] => ru
                            [FORMAT_STRING] => # а.
                            [FULL_NAME] => ђгЎ«м
                            [DEC_POINT] => .
                            [THOUSANDS_SEP] => \xA0
                            [DECIMALS] => 2
                        )

                    [ACCOUNT_LIST] => Array
                        (
                            [ID] => 3
                            [CURRENT_BUDGET] => 0.0000
                            [CURRENCY] => RUR
                            [TIMESTAMP_X] => 19.12.2006 18:56:56
                            [~ID] => 3
                            [~CURRENT_BUDGET] => 0.0000
                            [~CURRENCY] => RUR
                            [~TIMESTAMP_X] => 19.12.2006 18:56:56
                        )

                    [INFO] => ў ў «овҐ RUR (ђгЎ«м) - 0.00 а.
                )

            [1] => Array
                (
                    [CURRENCY] => Array
                        (
                            [CURRENCY] => USD
                            [LID] => ru
                            [FORMAT_STRING] => $#
                            [FULL_NAME] => „®«« а ‘?Ђ
                            [DEC_POINT] => .
                            [THOUSANDS_SEP] => ,
                            [DECIMALS] => 2
                        )

                    [ACCOUNT_LIST] => Array
                        (
                            [ID] => 2
                            [CURRENT_BUDGET] => 0.0000
                            [CURRENCY] => USD
                            [TIMESTAMP_X] => 08.12.2006 15:03:44
                            [~ID] => 2
                            [~CURRENT_BUDGET] => 0.0000
                            [~CURRENCY] => USD
                            [~TIMESTAMP_X] => 08.12.2006 15:03:44
                        )

                    [INFO] => ў ў «овҐ USD („®«« а ‘?Ђ) - $0.00
                )

        )

)
</pre>
