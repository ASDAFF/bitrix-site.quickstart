<?php 
$MESS['1CB_PARAMETER_USE_QUANTITY_TIP'] = 'Если товара на складе нет - кнопка выводиться не будет.';
$MESS['1CB_PARAMETER_USE_DEBUG_MESSAGES_TIP'] = 'Ошибки не видны на странице, выводятся в диве со свойством display:none';
$MESS['1CB_PARAMETER_SEF_FOLDERIX_TIP'] = 'Значение должно совпадать с аналогичным значением в компоненте bitrix:catalog';
$MESS['1CB_PARAMETER_BUY_MODE_TIP'] = 'При оформлении одного товара все остальные товары в корзине будут удалены';
$MESS['1CB_PARAMETER_USE_SKU_TIP'] = 'Отметьте флажок и укажите используемые для отображения свойства торговых предложений';
$MESS['1CB_PARAMETER_USE_ANTISPAM_TIP'] = 'Если приходит много писем с пустыми заказами - отметьте этот флажок.';
?>
