<?
$MESS ['1CB_NAME'] = 'Покупка в один клик';
$MESS ['1CB_DESCRIPTION'] = 'Компонент покупки в один клик';
$MESS ['1CB_MENU_CAPTION'] = 'fenixit';
?>
