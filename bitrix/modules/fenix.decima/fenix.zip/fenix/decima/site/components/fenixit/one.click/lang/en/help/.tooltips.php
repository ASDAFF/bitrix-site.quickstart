<?php 
$MESS['1CB_PARAMETER_USE_QUANTITY_TIP'] = 'Button will not be shown if product is not in stock.';
$MESS['1CB_PARAMETER_USE_DEBUG_MESSAGES_TIP'] = 'Errors will be shown in div with property display:none';
?>
