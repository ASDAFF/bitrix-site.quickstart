<?
$MESS['1CB_NO_FIO'] = 'Не указано имя.';
$MESS['1CB_NO_PHONE'] = 'Не указан или неправильно указан телефон.';
$MESS['1CB_BAD_EMAIL_FORMAT'] = 'Указан неправильный e-mail';
$MESS['1CB_CURRENCY_NOT_FOUND'] = 'Валюта не найдена';
$MESS['1CB_AUTH_FAIL'] = 'Ошибка авторизации';
$MESS['1CB_TOO_MANY_USERS'] = 'Найдено более 1 пользователя с указанным email.';
$MESS['1CB_USER_REGISTER_FAIL'] = 'Ошибка регистрации пользователя.';
$MESS['1CB_ORDER_CREATE_FAIL'] = 'Ошибка создания заказа.';
$MESS['1CB_PRODUCT_PRICE_NOT_FOUND'] = 'Цена на товар не найдена.';
$MESS['1CB_ITEM_ADD_FAIL'] = 'Ошибка добавления товара в заказ.';
$MESS['1CB_ITEM_UPDATE_FAIL'] = 'Ошибка присвоения номера заказа товару в корзине.';
$MESS['1CB_ORDER_CREATE_SUCCESS'] = 'Заказ успешно оформлен.';
$MESS['1CB_PHONE'] = 'Телефон для связи: ';
$MESS['1CB_EMPTY_BASKET'] = "<i id='cart-status'><a href='/personal/cart/'>Ваша корзина пуста</a>";
$MESS['ITEM_NAME'] = 'Название: ';
$MESS['ITEM_PRICE'] = ', цена за единицу: ';
$MESS['ITEM_QTY'] = ', количество: ';
$MESS['ITEM_TOTAL'] = ', стоимость: ';
$MESS['1CB_ANTISPAM'] = 'Проверка на антиспам не пройдена';
$MESS['1CB_ORDER_COMMENT'] = 'Заказ оформлен в 1 клик';
$MESS['1CB_NO_PROPER_DATA'] = 'Недостаточно данных';?>
