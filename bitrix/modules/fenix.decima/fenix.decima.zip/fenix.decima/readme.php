<?
header("Content-Type:text/html; charset=windows-1251");
include($_SERVER["DOCUMENT_ROOT"]."/readme.html");
?>