<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?><?
?> <h2 class="strong-header large-header"><?=GetMessage("LEGEND_PROFILE")?></h2>
<?=ShowError($arResult["strProfileError"]);?>
<?
    if ($arResult['DATA_SAVED'] == 'Y')
        echo ShowNote(GetMessage('PROFILE_DATA_SAVED'));
?>

<form role="form" method="post" name="form1" action="<?=$arResult["FORM_TARGET"]?>?" novalidate>
    <?=$arResult["BX_SESSION_CHECK"]?>
    <input type="hidden" name="lang" value="<?=LANG?>" />
    <input type="hidden" name="ID" value=<?=$arResult["ID"]?> />
    <input type="hidden" name="LOGIN" value=<?=$arResult["arUser"]["LOGIN"]?> />
    <input type="hidden" name="EMAIL" value=<?=$arResult["arUser"]["EMAIL"]?> />
    <div class="form-group">
        <label for="first-name"><?=GetMessage('NAME')?></label>
        <input type="text" class="form-control" id="first-name" required name="NAME" value="<?=$arResult["arUser"]["NAME"]?>">
    </div>
    <div class="form-group">
        <label for="last-name"><?=GetMessage('LAST_NAME')?></label>
        <input type="text" class="form-control" id="last-name" required name="LAST_NAME" value="<?=$arResult["arUser"]["LAST_NAME"]?>">
    </div> 
    <div class="form-group">
        <label for="last-name"><?=GetMessage('SECOND_NAME')?></label>
        <input type="text" class="form-control" id="last-name" required name="SECOND_NAME" value="<?=$arResult["arUser"]["SECOND_NAME"]?>">
    </div>
    <div class="form-group">
        <label for="password"><?=GetMessage("NEW_PASSWORD_REQ")?></label>
        <input type="password" name="NEW_PASSWORD"  value="" class="form-control" id="password" required>
    </div>
    <div class="form-group">
        <label for="password-repeat"><?=GetMessage('NEW_PASSWORD_CONFIRM')?></label>
        <input type="password" name="NEW_PASSWORD_CONFIRM"  value="" class="form-control" id="password-repeat" required>
    </div>
    <button name="save" value="Y" type="submit" class="btn btn-primary"><?=GetMessage("MAIN_SAVE")?></button>
</form>