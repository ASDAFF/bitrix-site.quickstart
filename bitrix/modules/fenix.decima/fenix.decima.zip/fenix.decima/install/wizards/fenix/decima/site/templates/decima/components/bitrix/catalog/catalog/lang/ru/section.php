<?
$MESS['CATALOG_SORT']='Сортировать';
$MESS['CATALOG_SHOW']='Показать';
$MESS['CATALOG_SORT_NAME_ASC']='Имя (возр.)';
$MESS['CATALOG_SORT_NAME_DESC']='Имя (убыв.)';
$MESS['CATALOG_SORT_PRICE_ASC']='Цена (возр.)';
$MESS['CATALOG_SORT_PRICE_DESC']='Цена (убыв.)';
$MESS['CATALOG_SORT_RATING_ASC']='Рейтинг (возр.)';
$MESS['CATALOG_SORT_RATING_DESC']='Рейтинг (убыв.)';
$MESS['CATALOG_SORT_DATE_ASC']='Дата (возр.)';
$MESS['CATALOG_SORT_DATE_DESC']='Дата (убыв.)';
$MESS['CATALOG_PER_PAGE']=' на стр.';
?>