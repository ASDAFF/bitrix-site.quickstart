<?
$MESS["SBBS_PATH_TO_WISHLIST"] = "Страница избранного";
$MESS["SBBS_PATH_TO_BASKET"] = "Страница корзины";
$MESS["SBBS_PATH_TO_ORDER"] = "Страница оформления заказа";
$MESS["SBBS_SHOW_DELAY"] = "Показывать отложенные товары";
$MESS["SBBS_SHOW_NOTAVAIL"] = "Показывать товары, недоступные для покупки";
$MESS["SBBS_SHOW_SUBSCRIBE"] = "Показывать товары, на которые подписан покупатель";
$MESS['LIST_PARAMETERS_IMG_WIDTH']='Ширина картинки в списке';
$MESS['LIST_PARAMETERS_IMG_HEIGHT']='Высота картинки в списке';
$MESS['LIST_PARAMETERS_IMG_PROP']='Соблюдать пропорции';
?>