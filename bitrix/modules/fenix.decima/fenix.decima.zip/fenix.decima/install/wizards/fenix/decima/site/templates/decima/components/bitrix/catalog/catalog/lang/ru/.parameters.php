<?
$MESS['LIST_PARAMETERS_IMG_WIDTH']='Ширина картинки в списке';
$MESS['LIST_PARAMETERS_IMG_HEIGHT']='Высота картинки в списке';
$MESS['LIST_PARAMETERS_PROPERTY_CODE']='Список требуемых свойств';
$MESS['LIST_PARAMETERS_IMG_PROP']='Соблюдать пропорции';
$MESS['LIST_PARAMETERS_TRUNCATE']='Обрезать описание до кол-ва символов:';
$MESS['PROPERTY_FILTER']='Фильтровать по свойству';
?>