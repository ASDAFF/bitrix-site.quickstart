<?
$MESS["PORTAL_WIZARD_NAME"] = "Интернет-магазин Decima";
$MESS["PORTAL_WIZARD_DESC"] = "Мастер создания интернет-магазина Decima";
?>