<?
$MESS ['nav_prev'] = "Prev.";
$MESS ['nav_paged'] = "Paged";
$MESS ['pages'] = "Pages:";
$MESS ['nav_next'] = "Next";
$MESS ['nav_all'] = "All";
?>