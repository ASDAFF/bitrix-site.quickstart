<?
$MESS ['subscr_form_email_title'] = "Enter your e-mail";
$MESS ['subscr_form_button'] = "Subscribe";
?>