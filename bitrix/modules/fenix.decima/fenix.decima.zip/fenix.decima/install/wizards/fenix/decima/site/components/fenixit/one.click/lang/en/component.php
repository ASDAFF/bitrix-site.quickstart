<? 
$MESS['ICRM_COMPONENT_ERROR_1'] = 'Element with code #CODE# not found in iblock with ID #IBLOCK_ID#';
$MESS['ICRM_COMPONENT_ERROR_2'] = 'No ELEMENT_CODE parameter in current page URL';
$MESS['ICRM_COMPONENT_ERROR_3'] = 'No ELEMENT_ID parameter in current page URL';
$MESS['ICRM_COMPONENT_ERROR_4'] = 'Product identifier not found in current page URL';
$MESS['ICRM_COMPONENT_ERROR_5'] = 'Product with ID #ID# is not in stock. ' 
	. 'Disable component parameter for not using product quantity';
$MESS['ICRM_COMPONENT_ERROR_6'] = 'SKU properties in stock not found. '
	. 'Disable component parameter for not using product quantity';
?>
