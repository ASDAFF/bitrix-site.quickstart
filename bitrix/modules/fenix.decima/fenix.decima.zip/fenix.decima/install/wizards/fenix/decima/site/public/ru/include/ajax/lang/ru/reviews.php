<?
$MESS['REVIEWS_IBLOCK_NAME']='Отзывы к товарам';
$MESS['REVIEWS_BLOG_IBLOCK_NAME']='Комментарии блога';
$MESS['REVIEWS_PRODUCT']='Товар';
$MESS['REVIEWS_USER']='Автор';
$MESS['REVIEWS_QUALITY_RATE']='Качество изготовления';
$MESS['REVIEWS_ADECVAT_RATE']='Адекватность цены';
$MESS['REVIEWS_SOFT_RATE']='Удобство эксплуатации';
$MESS['REVIEWS_RATE']='Средняя оценка';
$MESS['REVIEWS_TIME']='Опыт использования';
$MESS['REVIEWS_MONTH']='Менее месяца';
$MESS['REVIEWS_SOMEMONTH']='Несколько месяцев';
$MESS['REVIEWS_YEAR']='Более года';
$MESS['REVIEWS_ADVANTAGES']='Достоинства';
$MESS['REVIEWS_DISADVANTAGES']='Недостатки';
$MESS['REVIEWS_ADD']='Написать отзыв о товаре';
$MESS['REVIEWS_ADD_SHORT']='Отправить';
$MESS['REVIEWS_OPINION']='Ваше мнение';
$MESS['REVIEWS_NAME']='Ваше имя';
$MESS['REVIEWS_COMMENT']='Комментарий';
$MESS['REVIEWS_DETAIL_RATES']='Подробные оценки';
$MESS['REVIEWS_AVERAGE']='Средняя оценка ';
$MESS['REVIEWS_POINTS']=' баллов';
$MESS['REVIEWS_POINT']=' балл';
$MESS['REVIEWS_OFPOINT']=' балла';
$MESS['REVIEWS_ADD_REVIEW']='Написать отзыв';
$MESS['REVIEWS_CLOSE']='закрыть';
$MESS['REVIEWS_UP']='Плюсов';
$MESS['REVIEWS_DOWN']='Минусов';  
$MESS['REVIEWS_OK']='Отзыв успешно добавлен'; 
//---------------------------------------------- 
$MESS['REVIEWS_LIST_DATE']='Дата размещения';
$MESS['REVIEWS_LIST_YEAR']=' года.';
$MESS['REVIEWS_ERROR_NAME']='Введите имя';
$MESS['REVIEWS_ERROR_EMAIL']='Введите e-mail';
$MESS['REVIEWS_ERROR_RATE']='Оцените продукт';
$MESS['REVIEWS_ERROR_COMMENT']='Оставьте свой комментарий';
$MESS['REVIEWS_B_COMMENT']='комментарий';
$MESS['REVIEWS_B_COMMENTA']='комментария';
$MESS['REVIEWS_B_COMMENTOV']='комментариев';

$MESS["COMMENTS_TYPE_NAME"] = "Комментарии";
$MESS["COMMENTS_ELEMENT_NAME"] = "Записи";
$MESS["COMMENTS_SECTION_NAME"] = "Разделы";
?>