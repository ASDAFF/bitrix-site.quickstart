<div class="icon-box icon-box-short">
    <i class="fa fa-refresh"></i>
    <h4 class="strong-header">30 Days return</h4>
</div>

<div class="icon-box icon-box-short">
    <i class="fa fa-truck"></i>
    <h4 class="strong-header">Free shipping</h4>
</div>

<div class="icon-box icon-box-short">
    <i class="fa fa-lock"></i>
    <h4 class="strong-header">Secure payments</h4>
</div>

<div class="icon-box icon-box-short">
    <i class="fa fa-gift"></i>
    <h4 class="strong-header">New styles every day</h4>
</div>