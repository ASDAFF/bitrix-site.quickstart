<ul class="payment-methods list-inline pull-right">
<li><span class="payment-visa"><span class="sr-only">Visa</span></span></li>
<li><span class="payment-mastercard"><span class="sr-only">MasterCard</span></span></li>
<li><span class="payment-paypal"><span class="sr-only">PayPal</span></span></li>
<li><span class="payment-americanexpress"><span class="sr-only">American Express</span></span></li>
</ul>