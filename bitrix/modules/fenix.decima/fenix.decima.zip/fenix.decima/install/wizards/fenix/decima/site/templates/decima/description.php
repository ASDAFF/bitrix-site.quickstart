<?$arTemplate = array(
	"NAME" => "decima",
	"DESCRIPTION" => "",
	"SORT" => "",
);
?>