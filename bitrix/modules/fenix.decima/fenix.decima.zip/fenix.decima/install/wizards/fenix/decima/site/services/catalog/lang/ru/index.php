<?
$MESS["STORE_NAME_1"] = "Мир одежды";
$MESS["STORE_DESCR_1"] = "Здесь вы найдете одежду ведущих производителей мира";
$MESS["STORE_ADR_1"] = "пр. Московский д. 51";
$MESS["STORE_GPS_N_1"] = "54.71411";
$MESS["STORE_GPS_S_1"] = "20.56675";
$MESS["STORE_PHONE_1"] = "8 (495) 212 85 06";
$MESS["STORE_PHONE_SCHEDULE"] = "Пн.-Пт. с 9:00 до 20:00, Сб.-Вс. с 11:00 до 18:00";
$MESS["CAT_STORE_NAME"] = "Склад";
?>