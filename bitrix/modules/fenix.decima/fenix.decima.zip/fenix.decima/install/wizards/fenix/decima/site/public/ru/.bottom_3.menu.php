<?
$aMenuLinks = Array(
    Array(
        "Личные данные", 
        "personal/profile/", 
        Array(), 
        Array(), 
        "" 
    ),
    Array(
        "Текущие заказы", 
        "personal/order/", 
        Array(), 
        Array(), 
        "" 
    ),
    Array(
        "История заказов", 
        "personal/order/?filter_history=Y", 
        Array(), 
        Array(), 
        "" 
    ),
    Array(
        "Корзина", 
        "personal/cart/", 
        Array(), 
        Array(), 
        "" 
    ),
    Array(
        "Изменить подписку", 
        "personal/subscribe/", 
        Array(), 
        Array(), 
        "" 
    ),
    Array(
        "Избранное", 
        "personal/wishlist/", 
        Array(), 
        Array(), 
        "" 
    )
);
?>