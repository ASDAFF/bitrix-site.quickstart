<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>
<article class="post post-image">
    <a data-rel="prettyPhotoGallery[product]" href="<?=$arResult['PICTURE']['BIG_SRC']?>">
        <img src="<?=$arResult['PICTURE']['SRC']?>"  alt="<?=$arItem['NAME']?>">
    </a>
    <header class="post-info-name-date-comments">
        <span class="date"><?=$arResult["DISPLAY_ACTIVE_FROM"]?></span>&nbsp;&nbsp;<a href="#Comments" class="comments"><?=GetMessage('BLOG_REVIEW')?></a>
        <h1><?=$arItem['NAME']?></h1>
    </header>
<p><?if(strlen($arResult["DETAIL_TEXT"])>0):?>
        <?echo $arResult["DETAIL_TEXT"];?>
        <?else:?>
        <?echo $arResult["PREVIEW_TEXT"];?>
        <?endif?></p>
        <?if($arResult["DISPLAY_PROPERTIES"]):?>
        <?foreach($arResult["DISPLAY_PROPERTIES"] as $pid=>$arProperty):?>
        <li><?=$arProperty["NAME"]?>:&nbsp;
        <?if(is_array($arProperty["DISPLAY_VALUE"])):?>
            <?=implode("&nbsp;/&nbsp;", $arProperty["DISPLAY_VALUE"]);?>
            <?else:?>
            <?=$arProperty["DISPLAY_VALUE"];?>
            <?endif?>
          </li>
        <?endforeach;?>
        <?endif?>
</article>