<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
if($_REQUEST['q'])$GLOBALS[$arParams['FILTER_NAME']]['NAME']='%'.$_REQUEST['q'].'%';
$APPLICATION->SetTitle(GetMessage('SEARCH_TITLE'));
$APPLICATION->AddChainItem(GetMessage('SEARCH_TITLE'));     
include 'section.php';
?>