<?
$MESS["SALE_OFFER_PROPS"] = "SKU properties visible in shopping cart";
$MESS["SALE_PROPERTIES_RECALCULATE_BASKET"] = "SKU properties affecting cart refresh";
?>