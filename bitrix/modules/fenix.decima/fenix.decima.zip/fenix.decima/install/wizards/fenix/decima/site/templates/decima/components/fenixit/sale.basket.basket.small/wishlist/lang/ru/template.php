<?
$MESS['CART_BASKET'] = "Корзина";
$MESS['CART_INBASKET'] = "В корзину";
$MESS['CART_ORDER'] = "Заказать";
$MESS['CART_TOVAR'] = "товар";
$MESS['CART_TOVARA'] = "товара";
$MESS['CART_TOVAROV'] = "товаров";
$MESS['CART_TOTAL'] = "Товаров на:";
$MESS['TSBS_UNAVAIL'] = "Недоступны для покупки:";
$MESS['TSBS_SUBSCRIBE'] = "Подписка:";
?>