<?
    if(!defined("B_PROLOG_INCLUDED")||B_PROLOG_INCLUDED!==true)die();
    /**
    * Bitrix vars
    *
    * @var array $arParams
    * @var array $arResult
    * @var CBitrixComponentTemplate $this
    * @global CMain $APPLICATION
    * @global CUser $USER
    */
$this->setFrameMode(true);
?>
<div class="simpleForm">
<?if(strlen($arResult["OK_MESSAGE"]) > 0)
        {?>
    <div class="successMessage alert alert-success alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <div class="mf-ok-text"><?=$arResult["OK_MESSAGE"]?></div>
        </div>
        <?
        }
    ?>
        
    
    <?if(!empty($arResult["ERROR_MESSAGE"]))
        {?><div class="errorMessage alert alert-danger alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
           <?foreach($arResult["ERROR_MESSAGE"] as $v)
                ShowError($v);?>
    </div>
    <? }?>
    <form role="form" action="<?=POST_FORM_ACTION_URI?>" method="POST" class="validateIt" data-email-subject="Contact Form" data-show-errors="true" data-hide-form="false">
       <?=bitrix_sessid_post()?>
        <fieldset>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="field1"> <?=GetMessage("MFT_NAME")?></label>
                        <input type="text" required name="user_name" value="<?=$arResult["AUTHOR_NAME"]?>" class="form-control" id="field1" >
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="field2"><?=GetMessage("MFT_EMAIL")?></label>
                        <input type="email" required name="user_email" value="<?=$arResult["AUTHOR_EMAIL"]?>" class="form-control" id="field2" >
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label for="field3"><?=GetMessage("MFT_MESSAGE")?></label>
                <textarea name="MESSAGE" class="form-control" id="field3" rows="10" ><?=$arResult["MESSAGE"]?></textarea>
            </div>
            <?if($arParams["USE_CAPTCHA"] == "Y"):?>
            <div class="form-group">
                <label class="mf-text"><?=GetMessage("MFT_CAPTCHA")?>
                <input type="hidden" name="captcha_sid" value="<?=$arResult["capCode"]?>">
                <img src="/bitrix/tools/captcha.php?captcha_sid=<?=$arResult["capCode"]?>" width="180" height="40" alt="CAPTCHA"></label>
                <div class="mf-text"><?=GetMessage("MFT_CAPTCHA_CODE")?><span class="mf-req">*</span></div>
                <input type="text" name="captcha_word" class="form-control" size="30" maxlength="50" value="">
            </div>
            <?endif;?>
              <input type="hidden" name="PARAMS_HASH" value="<?=$arResult["PARAMS_HASH"]?>">
            <input type="submit" class="btn btn-primary" name="submit" value="<?=GetMessage("MFT_SUBMIT")?>">
        </fieldset>
    </form>
</div>