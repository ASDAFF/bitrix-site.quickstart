<?
$MESS['BASKET_ADD']='Товар добавлен в корзину';
$MESS['BASKET_CLOSE']='Закрыть';
$MESS['BASKET_CONTINUE']='Продолжить покупки';
$MESS['BASKET_ORDER']='Оформить заказ';
?>