<?
$sSectionName = "Избранное";
$arDirProperties = Array(

);
?>