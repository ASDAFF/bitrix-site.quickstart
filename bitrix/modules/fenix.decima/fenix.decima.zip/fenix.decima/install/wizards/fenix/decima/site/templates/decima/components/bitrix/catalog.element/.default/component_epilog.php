<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();__IncludeLang($_SERVER["DOCUMENT_ROOT"].$templateFolder."/lang/".LANGUAGE_ID."/template.php");?>

<section class="tab-pane fade" id="reviews"> 
    <?include $_SERVER['DOCUMENT_ROOT'].SITE_DIR.'include/ajax/reviews.php'?>
</section> 
<script>
    <?  
        $db_props = CIBlockElement::GetProperty($arParams['IBLOCK_ID'], $arResult['ID'], "sort", "asc", Array("CODE"=>"RATE"));
        if($ar_props = $db_props->Fetch()){?>
        document.getElementById("rate<?=$arResult['ID']?>").setAttribute("data-score", "<?=$ar_props['VALUE']?$ar_props['VALUE']:0?>");
        <?}
        $db_props = CIBlockElement::GetProperty($arParams['IBLOCK_ID'], $arResult['ID'], "sort", "asc", Array("CODE"=>"COMMENTS"));
        if($ar_props = $db_props->Fetch()){        
        ?>
        document.getElementById("rews<?=$arResult['ID']?>").innerHTML = "<?=$ar_props['VALUE']?$ar_props['VALUE']:0; echo ' '.digital($ar_props['VALUE']?$ar_props['VALUE']:0, GetMessage('ELEMENT_COMMENT'), GetMessage('ELEMENT_COMMENTA'), GetMessage('ELEMENT_COMMENTOV'))?>";
        document.getElementById("revcnt<?=$arResult['ID']?>").innerHTML = "<?=$ar_props['VALUE']?$ar_props['VALUE']:0;?>";
        <?}
    ?>
</script>
</div>
</div>
</div>