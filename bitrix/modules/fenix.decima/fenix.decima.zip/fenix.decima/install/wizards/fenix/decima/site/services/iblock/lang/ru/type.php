<?
$MESS["INFO_TYPE_NAME"] = "Информация";
$MESS["INFO_ELEMENT_NAME"] = "Записи";
$MESS["INFO_SECTION_NAME"] = "Разделы";
$MESS["SERVICES_TYPE_NAME"] = "Сервисы";
$MESS["SERVICES_ELEMENT_NAME"] = "Элементы";
$MESS["SERVICES_SECTION_NAME"] = "Разделы";
$MESS["CATALOG_TYPE_NAME"] = "Каталоги";
$MESS["CATALOG_ELEMENT_NAME"] = "Товары";
$MESS["CATALOG_SECTION_NAME"] = "Разделы";
$MESS["OFFERS_TYPE_NAME"] = "Торговые предложения";
$MESS["OFFERS_ELEMENT_NAME"] = "Предложения";
$MESS["OFFERS_SECTION_NAME"] = "Разделы";
$MESS["BLOG_TYPE_NAME"] = "Блог";
$MESS["BLOG_ELEMENT_NAME"] = "Записи";
$MESS["BLOG_SECTION_NAME"] = "Разделы";
?>