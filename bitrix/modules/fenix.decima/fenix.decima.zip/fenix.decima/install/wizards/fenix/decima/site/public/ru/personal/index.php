<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Персональный раздел");
?>
 <h2 class="strong-header large-header">Личный кабинет</h2>
      <p>
          В личном кабинете Вы можете проверить текущее состояние корзины,
          ход выполнения Ваших заказов, просмотреть или изменить личную информацию, а также подписаться на новости и другие информационные рассылки. 

      </p>
      <hr>
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>
