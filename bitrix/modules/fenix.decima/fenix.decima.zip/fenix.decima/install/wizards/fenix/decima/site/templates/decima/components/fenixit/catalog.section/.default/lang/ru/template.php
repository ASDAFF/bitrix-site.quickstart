<?
$MESS["CT_BCS_TPL_ELEMENT_DELETE_CONFIRM"] = "Будет удалена вся информация, связанная с этой записью. Продолжить?";
$MESS["LIST_FLAG_NEWPRODUCT"] = "Новинки";
$MESS["LIST_FLAG_SALELEADER"] = "Лидеры продаж";
$MESS["LIST_FLAG_SPECIALOFFER"] = "Специальные предложения";
$MESS["LIST_FLAG_RECOMMENDS"] = "Рекомендуем";
$MESS["LIST_TOCART"] = "В корзину";
$MESS["LIST_BUY"] = "Купить";
$MESS["LIST_DETAIL"] = "Подробнее";
$MESS["CT_BCS_TPL_MESS_BTN_DETAIL"] = "Подробнее";
$MESS["CT_BCS_TPL_MESS_BTN_SUBSCRIBE"] = "Подписаться";
$MESS["CT_BCS_CATALOG_BTN_MESSAGE_BASKET_REDIRECT"] = "Перейти в корзину";
$MESS["ADD_TO_BASKET_OK"] = "Товар добавлен в корзину";
$MESS["CT_BCS_TPL_MESS_PRICE_SIMPLE_MODE"] = "от #PRICE# за #MEASURE#";
$MESS["CT_BCS_TPL_MESS_MEASURE_SIMPLE_MODE"] = "#VALUE# #UNIT#";
$MESS["CT_BCS_TPL_MESS_BTN_COMPARE"] = "Сравнить";
$MESS["CT_BCS_CATALOG_TITLE_ERROR"] = "Ошибка";
$MESS["CT_BCS_CATALOG_TITLE_BASKET_PROPS"] = "Свойства товара, добавляемые в корзину";
$MESS["CT_BCS_CATALOG_BASKET_UNKNOWN_ERROR"] = "Неизвестная ошибка при добавлении товара в корзину";
$MESS["CT_BCS_CATALOG_BTN_MESSAGE_SEND_PROPS"] = "Выбрать";
$MESS["CT_BCS_CATALOG_BTN_MESSAGE_CLOSE"] = "Закрыть";
?>