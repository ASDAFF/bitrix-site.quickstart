<?
$MESS["SALE_PROPERTIES_RECALCULATE_BASKET"] = "Свойства, влияющие на пересчет корзины";
?>