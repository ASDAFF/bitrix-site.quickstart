<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
$arTemplateParameters = array(
    "MENU_TITLE" => array(
        "NAME" => GetMessage("MENU_TITLE"),
        "TYPE" => "STRING",
        "DEFAULT" => "",
    ),
);
?>
