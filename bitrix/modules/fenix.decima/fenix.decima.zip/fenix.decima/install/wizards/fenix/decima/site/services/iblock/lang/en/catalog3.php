<?
$MESS["WIZ_PRICE_NAME"] = "Retail price";
$MESS["WIZ_DISCOUNT"] = "Sofa offer";
$MESS["WIZ_PRECET"] = "Specials";
?>