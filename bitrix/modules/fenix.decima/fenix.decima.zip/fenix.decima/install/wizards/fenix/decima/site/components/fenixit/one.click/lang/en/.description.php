<?
$MESS ['1CB_NAME'] = 'One click purchase';
$MESS ['1CB_DESCRIPTION'] = 'One click purchase component';
$MESS ['1CB_MENU_CAPTION'] = 'Intaro solutions for online commerce';
?>
