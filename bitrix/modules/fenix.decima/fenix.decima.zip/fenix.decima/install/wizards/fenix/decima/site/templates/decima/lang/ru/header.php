<?
$MESS['HEADER_LOGIN']='Войти';
?>