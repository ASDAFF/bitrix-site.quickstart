<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();CModule::IncludeModule('iblock');
    $IBLOCK_ID = $arCurrentValues['IBLOCK_ID'];
    $rsProp = CIBlockProperty::GetList(Array("sort"=>"asc", "name"=>"asc"), Array("ACTIVE"=>"Y", "IBLOCK_ID"=>$IBLOCK_ID));
    while($arr=$rsProp->Fetch())
    {
        $arProperty[$arr["CODE"]] = "[".$arr["CODE"]."] ".$arr["NAME"];
    }
    $arTemplateParameters = array(
     
        "TYPE" => Array(
            "NAME" => 'TYPE',
            "TYPE" => "LIST",
            "MULTIPLE" => "N",
            "VALUES" => array('SLIDER_FADE'=>'SLIDER_FADE', 'SLIDER_DOUBLE'=>'SLIDER_DOUBLE', 'SLIDER_SIMPLE'=>'SLIDER_SIMPLE', 'SIMPLE'=>'SIMPLE', 'default'=>'default'),
            "ADDITIONAL_VALUES" => "N",
        ), 
        
        "DISPLAY_IMG_WIDTH" => Array(
            "NAME" => GetMessage("LIST_PARAMETERS_IMG_WIDTH"),
            "TYPE" => "TEXT",
            "DEFAULT" => "262",
        ),
        "DISPLAY_IMG_HEIGHT" => Array(
            "NAME" => GetMessage("LIST_PARAMETERS_IMG_HEIGHT"),
            "TYPE" => "TEXT",
            "DEFAULT" => "261",
        ),
        "DISPLAY_IMG_PROP" => Array(
            "NAME" => GetMessage("LIST_PARAMETERS_IMG_PROP"),
            "TYPE" => "CHECKBOX",
            "DEFAULT" => "N",
        ),
        "DATABASE_PROPERTY_CODE" => array(
            "NAME" => GetMessage("LIST_PARAMETERS_PROPERTY_CODE"),
            "TYPE" => "LIST",
            "MULTIPLE" => "Y",
            "VALUES" => $arProperty,
            "ADDITIONAL_VALUES" => "Y",
        ),  
       
        "PROPERTY_FILTER" => array(
            "NAME" => GetMessage("PROPERTY_FILTER"),
            "TYPE" => "LIST",
            "MULTIPLE" => "N",
            "VALUES" => $arProperty,
            "ADDITIONAL_VALUES" => "Y",
        ) 
        );
?>
