<?
$MESS["WZD_OPTION_FAQ_1"] = "Question";
$MESS["WZD_OPTION_FAQ_2"] = "Publish Question";
$MESS["WZD_OPTION_FAQ_3"] = "List Sort Index";
$MESS["WZD_OPTION_FAQ_4"] = "* Question";
$MESS["WZD_OPTION_FAQ_5"] = "Answer";
$MESS["WZD_OPTION_FAQ_6"] = "Tags";
?>