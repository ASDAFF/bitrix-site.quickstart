<?
$MESS["nav_prev"]="Пред.";
$MESS["nav_paged"]="По стр.";
$MESS["pages"]="Страницы:";
$MESS["nav_next"]="След.";
$MESS["nav_all"]="Все";
?>