<?
$MESS["IBLOCK_MODULE_NOT_INSTALLED"] = "Information blocks module is not installed";
$MESS["CATALOG_SECTION_NOT_FOUND"] = "Section has not been found.";
$MESS["CATALOG_ERROR2BASKET"] = "Could not add product to cart";
$MESS["CATALOG_PRODUCT_NOT_FOUND"] = "The product was not found.";
$MESS["CATALOG_SUCCESSFUL_ADD_TO_BASKET"] = "Product successfully added to cart";
$MESS["CATALOG_PARTIAL_BASKET_PROPERTIES_ERROR"] = "Not all properties of products added to the cart are filled in";
$MESS["CATALOG_EMPTY_BASKET_PROPERTIES_ERROR"] = "Properties of products added to cart are not filled in";
?>