<?
$MESS["WZD_OPTION_NEWS_1"] = "Новость";
$MESS["WZD_OPTION_NEWS_2"] = "Публикуется на сайте";
$MESS["WZD_OPTION_NEWS_3"] = "Дата новости";
$MESS["WZD_OPTION_NEWS_5"] = "*Заголовок";
$MESS["WZD_OPTION_NEWS_6"] = "*Символьный код";
$MESS["WZD_OPTION_NEWS_8"] = "Краткое описание";
$MESS["WZD_OPTION_NEWS_10"] = "Полное описание";
?>