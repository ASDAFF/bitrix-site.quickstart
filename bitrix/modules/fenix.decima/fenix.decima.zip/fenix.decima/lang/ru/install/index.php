<?
$MESS["SCOM_INSTALL_NAME"] = "Адаптивный интернет-магазин Decima";
$MESS["SCOM_INSTALL_DESCRIPTION"] = "Мастер создания интернет-магазина";
$MESS["SCOM_INSTALL_TITLE"] = "Установка модуля";
$MESS["SCOM_UNINSTALL_TITLE"] = "Удаление модуля";
$MESS["SPER_PARTNER"] = "Fenix Inc.";
$MESS["PARTNER_URI"] = "http://www.fenix-media.by";
?>